<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com,adamignjatovic1997@yahoo.com
	/*This CMS is no longer private you can use it without any charge.

	Thanks in advance.

*/

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelname} Hotel - {hotelname} Way </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="alternate" type="application/rss+xml" title="Habbo Hotel - RSS" href="http://www.habbo.com/articles/rss.xml" />
<meta name="csrf-token" content="78b065a206"/>
<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/libs2.js" type="text/javascript"></script>
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/visual.js" type="text/javascript"></script>
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/libs.js" type="text/javascript"></script>
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/common.js" type="text/javascript"></script>
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>

<script src="/customjs/local/.com.js" type="text/javascript"></script>

<script type="text/javascript">
var ad_keywords = "gender%3Am,age%3A16";
var ad_key_value = "kvage=16;kvgender=m;kvtags=";
</script>
<script type="text/javascript">
document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	


</script>

<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />

<meta property="fb:app_id" content="1417574575138432" />

<meta property="og:site_name" content="Habbo Hotel" />
<meta property="og:title" content="Habbo Hotel - Habbo Way" />
<meta property="og:url" content="http://www.habbo.com" />
<meta property="og:image" content="http://www.habbo.com/v2/images/facebook/app_habbo_hotel_image.gif" />
<meta property="og:locale" content="en_US" />

<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/styles/safety.css" type="text/css" />

<meta name="description" content="Check into the world's largest virtual hotel for FREE! Meet and make friends, play games, chat with others, create your avatar, design rooms and more..." />
<meta name="keywords" content="habbo hotel, virtual, world, social network, free, community, avatar, chat, online, teen, roleplaying, join, social, groups, forums, safe, play, games, online, friends, teens, rares, rare furni, collecting, create, collect, connect, furni, furniture, pets, room design, sharing, expression, badges, hangout, music, celebrity, celebrity visits, celebrities, mmo, mmorpg, massively multiplayer" />

<script src="//cdn.optimizely.com/js/13389159.js"></script>

<!--[if IE 8]>
<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/styles/ie8.css" type="text/css" />
<![endif]-->
<!--[if lt IE 8]>
<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/styles/ie.css" type="text/css" />
<![endif]-->
<!--[if lt IE 7]>
<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/styles/ie6.css" type="text/css" />
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
<script type="text/javascript">
try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
</script>

<style type="text/css">
body { behavior: url(/js/csshover.htc); }
</style>
<![endif]-->
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 3;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 5;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
               </div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
    <div id="column1" class="column">
			     		
				<div class="habblet-container ">		
	
						<div id="habbo-way-content">
        <table>
                <tr>
                    <td>
                        <h4 class="right">Play games</h4>
                        Play with friends, create your own games, kick ass and take names!
                    </td>
                    <td>
                        <img src="//habboo-a.akamaihd.net/c_images/habboway/page_0.png" alt="" /> <br />
                    </td>
                    <td>
                        <h4 class="wrong">Cheat</h4>
                        Cheaters never prosper, they just end up spoiling the experience for everyone else.
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="right">Chat</h4>
                        Talk to your friends, get to know your fellow Habbos and meet loads of new friends... and more! ;)
                    </td>
                    <td>
                        <img src="//habboo-a.akamaihd.net/c_images/habboway/page_1.png" alt="" /> <br />
                    </td>
                    <td>
                        <h4 class="wrong">Troll</h4>
                        No one likes a troll, not even their mothers; bullying will not be tolerated by anyone.
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="right">Find that special pixel someone</h4>
                        Flirt, Date, fall in love, and maybe meet that special someone... or something!??
                    </td>
                    <td>
                        <img src="//habboo-a.akamaihd.net/c_images/habboway/page_2.png" alt="" /> <br />
                    </td>
                    <td>
                        <h4 class="wrong">Cyber</h4>
                        Cybering is strictly forbidden, and cam requests will result in punishment. Also remember to never meet up with people you only know from the internet, people aren't always who they claim to be
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="right">Help</h4>
                        Help a stranger, gain a friend! Or two, or three. You never know who you're going to meet next!
                    </td>
                    <td>
                        <img src="//habboo-a.akamaihd.net/c_images/habboway/page_3.png" alt="" /> <br />
                    </td>
                    <td>
                        <h4 class="wrong">Trick</h4>
                        Taking advantage of other Habbos usually leads to bad mojo.
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="right">Create</h4>
                        Let your creativity run wilder than a beaver in a log cabin! Push yourself to the limit in style and design- be the best!
                    </td>
                    <td>
                        <img src="//habboo-a.akamaihd.net/c_images/habboway/page_4.png" alt="" /> <br />
                    </td>
                    <td>
                        <h4 class="wrong">Script</h4>
                        Make it, don't fake it! No one likes a trickster!
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="right">Trade</h4>
                        Build your own Furni empire by trading your way to the top!
                    </td>
                    <td>
                        <img src="//habboo-a.akamaihd.net/c_images/habboway/page_5.png" alt="" /> <br />
                    </td>
                    <td>
                        <h4 class="wrong">Scam</h4>
                        Stealing doesn't make you rich, it makes you a criminal. And a very bad role model.
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="right">Marketplace trading</h4>
                        If you have a nose for business, use the Marketplace to sell items and stock up on your credits. The more you know about the world of &quot;finances&quot;, the easier you get ahead in Habbo.
                    </td>
                    <td>
                        <img src="//habboo-a.akamaihd.net/c_images/habboway/page_6.png" alt="" /> <br />
                    </td>
                    <td>
                        <h4 class="wrong">Sell for real money</h4>
                        Don't sell your items for real money. You're likely to lose it all in a place that is not safe and to waste the time and dedication you put into getting where you are in the first place.
                    </td>
                </tr>
                <tr>
                    <td>
                        <h4 class="right">Put on Games</h4>
                        Be the perfect host- creating exciting games for other Habbos to play 
will mean that everyone will want to come play a game in your room.
                    </td>
                    <td>
                        <img src="//habboo-a.akamaihd.net/c_images/habboway/page_7.png" alt="" /> <br />
                    </td>
                    <td>
                        <h4 class="wrong">Place or accept bets</h4>
                        Using furni that randomizes games with the possibility to place bets can 
get you into trouble. Show off your skills, don't leave it up to chance.
                    </td>
                </tr>
        </table>
</div>

						
							
					
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			 

</div>
<script type="text/javascript">
HabboView.run();
</script>
<div id="column2" class="column">
</div>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
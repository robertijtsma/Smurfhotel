<?php
//MUS for real time update
function MUS($command, $data = '') 
{ 
    $MUSdata = $command . chr(1) . $data; 
    $socket = @socket_create(AF_INET, SOCK_STREAM, getprotobyname('tcp')); 
    @socket_connect($socket, "127.0.0.1", "30001"); 
    @socket_send($socket, $MUSdata, strlen($MUSdata), MSG_DONTROUTE);  
    @socket_close($socket); 
}
//Created by Teddy
$botPrice = "2500"; //price for creating a bot
$maxBots = "4"; //number of bots allowed
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - Store - Rares</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>
	
	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
	
	<style type="text/css">
		hr {background-color:#CCC;border:0;height:1px;margin:10px 0;}
	</style>
	
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 4;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 1;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

  <div id="content-container">
            <div id="container">
                <div id="content" style="position: relative" class="clearfix">
                    <div id="column1" class="column">
						<div class="habblet-container ">
                            <div class="cbb clearfix blue ">
                                <h2 class="title">Bots</h2>
                                <div style="padding:5px">
									<?php
$sql = "SELECT * FROM `users` WHERE `id`='{$_SESSION['user']['id']}'";
    $result = mysql_query($sql);
 
$details = mysql_fetch_array($result);
        $rank = $details['rank'];
 
if($rank = 3)
{
?>
									<form action="/bots/insert.php" method="post">
										<span title="Don&#39;t worry about the ID, it has been corrected for you.">Bot ID: </span><br />
										<input type="text" name="id" value="<?php
										$sql = "SELECT * FROM bots ORDER BY id DESC LIMIT 0,1";
										$result = mysql_query($sql);
										$info = mysql_fetch_array($result);
										$id = $info['id'];
										$addition = $id + 1;
														   
										echo $addition;
										?>" readonly /><br /><br />
													
										<span title="To find your room ID, go to the your room and click &#34;Room info&#34;. Look under &#34;Link to this room&#34;, copy down your room number and input below.">Room ID: </span><br />
										<form name="submit" method="post">
                                                        <h3>Room:</h3>
                                                        <p>Simply select the room to place your bot.<p>
                                                        <select name="room_id">
                                                        <?php
                                                        $getRoomInfo = mysql_query('SELECT id, caption FROM rooms WHERE owner = "'.$_SESSION['user']['username'].'"');
                                                        
                                                        while($roomInfo = mysql_fetch_array($getRoomInfo)){
                                                            echo '<option value="';
                                                            echo $roomInfo['id'];
                                                            echo '">';
                                                            echo $roomInfo['id'];
                                                            echo ' - ';
                                                            echo $roomInfo['caption'];
                                                            echo '<br /></option>';
                                                        }
                                                        ?>
													<br><br><br><br><p>
										<span title="Self-explanatory.">Bot name: </span><br />
										<input type="text" name="naam" /><br /><br />
													
										<span title="Will be seen when other Teddy's click on your bot in the hotel.">Bot motto: </span><br />
										<input type="text" name="missie" /><br /><br />
													
										<span title="">Look: </span><br /> 
										<input type="text" name="look"  value="hd-180-7.sh-290-110.lg-270-91.ch-809-62.hr-828-45" /><br /><br />

										<span title="Say :coords in the hotel for coordinates of where you are standing at that time.">Coordinates: </span><br />
										X: <input type="number" name="x" /><br />
										Y: <input type="number" name="y" /><br />
										Z: <input type="number" name="z" /><br />
										Rotation: <input type="number" name="rotation" /><br /><br />
													
										<span title="There are 3 types of walkmode: stand, freeroam and specified_range; pretty self-explanatory.">Walk mode: </span><br />
										<select name="walk_mode">
											<option>stand</option>
											<option>freeroam</option>
											<option>specified_range</option>
										</select><br /><br />
													
										<input type="submit" value="Make Bot" />
									</form>
									<?php } ?>
								<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
								</div>
							</div>
                        </div>
                    </div>
					
					<div id="column2" class="column">
                        <div class="habblet-container ">
                            <div class="cbb clearfix blue ">
                                <h2 class="title">Were is my Bot?</h2>
                                <div style="padding:5px">
                                    When purchased Do :update_bots in 
                                </div>
                            </div>
                        </div>
					</div>
					
				</div>
			</div>
        <script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
        <script type="text/javascript">
            HabboView.run();
        </script>

        <!--[if lt IE 7]>
            <script type="text/javascript">
                Pngfix.doPngImageFix();
            </script>
        <![endif]-->
        
        <div id="footer" >
        </div>
    
    </body>
</html>
			
		

<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
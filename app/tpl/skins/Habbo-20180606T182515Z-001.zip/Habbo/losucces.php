<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>{hotelname} Hotel - Make friends, join the fun, get noticed! </title>
    <meta name="viewport" content="width=device-width">

    <script>
        var andSoItBegins = (new Date()).getTime();
        var habboPageInitQueue = [];
        var habboStaticFilePath = "ttps://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2303/web-gallery";
    </script>
    <link rel="shortcut icon" href="https://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2303/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic">

<link rel="stylesheet" href="{url}/app/tpl/skins/{skin}/web-gallery/static/styles/v3_landing.css" type="text/css" />
<script src="{url}/app/tpl/skins/{skin}/js/v3_landing_top.js" type="text/javascript"></script>

        <meta name="description" content="Check into the world's largest virtual hotel for FREE! Meet and make friends, play games, chat with others, create your avatar, design rooms and more..." />
        <meta name="keywords" content="habbo hotel, virtual, world, social network, free, community, avatar, chat, online, teen, roleplaying, join, social, groups, forums, safe, play, games, online, friends, teens, rares, rare furni, collecting, create, collect, connect, furni, furniture, pets, room design, sharing, expression, badges, hangout, music, celebrity, celebrity visits, celebrities, mmo, mmorpg, massively multiplayer" />

<script src="//cdn.optimizely.com/js/13389159.js"></script>
    <meta name="build" content="63-BUILD2030 - 22.03.2013 11:10 - com" />
    <meta name="csrf-token" content="89fe674d03"/>
</head>
<body>

<div id="overlay"></div>


<div id="change-password-form" class="overlay-dialog" style="display: none;">
    <div id="change-password-form-container" class="clearfix form-container">
        <h2 id="change-password-form-title" class="bottom-border">Forgot Password?</h2>
        <div id="change-password-form-content" style="display: none;">
            <form method="post" action="{url}/account/password/identityResetForm" id="forgotten-pw-form">
                <input type="hidden" name="page" value="/?changePwd=true" />
                <span>Type in your {hotelname} account email address:</span>
                <div id="email" class="center bottom-border">
                    <input type="text" id="change-password-email-address" name="emailAddress" value="" class="email-address" maxlength="48"/>
                    <div id="change-password-error-container" class="error" style="display: none;">Please enter a correct email address</div>
                </div>
            </form>
            <div class="change-password-buttons">
                <a href="#" id="change-password-cancel-link">Cancel</a>
                <a href="#" id="change-password-submit-button" class="new-button"><b>Send Email</b><i></i></a>
            </div>
        </div>
        <div id="change-password-email-sent-notice" style="display: none;">
            <div class="bottom-border">
                <span>Hey, we just sent you an email with a link that lets you reset your password.<br>
<br>

NOTE! Remember to check your "junk" folder too!</span>
                <div id="email-sent-container"></div>
            </div>
            <div class="change-password-buttons">
                <a href="#" id="change-password-change-link">Back</a>
                <a href="#" id="change-password-success-button" class="new-button"><b>OK</b><i></i></a>
            </div>
        </div>
    </div>
    <div id="change-password-form-container-bottom" class="form-container-bottom">
</div>
</div>


<header>
    <div id="border-left"></div>
    <div id="border-right">
</div>

<?php if(isset($template->form->error)) { ?>
                    <div id="loginerrorfieldwrapper">
                        <div id="loginerrorfield">
                            <div><?php echo $template->form->error; ?></div>
                        </div>
                    </div>
                <?php } ?>


<div id="login-form-container">
    <a href="#home" id="habbo-logo"></a>

    <form id="loginformitem" name="loginformitem" method="post">
    
    <div id="login-columns">
        <div id="login-column-1">
            

</div>


        <div id="login-column-4">
<div id="fb-root"></div>
<script type="text/javascript">
    window.fbAsyncInit = function() {
        Cookie.erase("fbsr_183096284873");
        FB.init({appId: '183096284873', status: true, cookie: true, xfbml: true});
        if (window.habboPageInitQueue) {
            // jquery might not be loaded yet
            habboPageInitQueue.push(function() {
                $(document).trigger("fbevents:scriptLoaded");
            });
        } else {
            $(document).fire("fbevents:scriptLoaded");
        }

    };
    window.assistedLogin = function(FBobject, optresponse) {
        
        Cookie.erase("fbsr_183096284873");
        FBobject.init({appId: '183096284873', status: true, cookie: true, xfbml: true});

        permissions = 'user_birthday,email';
        defaultAction = function(response) {

            if (response.authResponse) {
                fbConnectUrl = "/facebook?connect=true";
                Cookie.erase("fbhb_val_183096284873");
                Cookie.set("fbhb_val_183096284873", response.authResponse.accessToken);
                Cookie.erase("fbhb_expr_183096284873");
                Cookie.set("fbhb_expr_183096284873", response.authResponse.expiresIn);
                window.location.replace(fbConnectUrl);
            }
        };

        if (typeof optresponse == 'undefined')
            FBobject.login(defaultAction, {scope:permissions});
        else
            FBobject.login(optresponse, {scope:permissions});

    };

    (function() {
        var e = document.createElement('script');
        e.async = true;
        e.src = document.location.protocol + '//connect.facebook.net/en_US/all.js';
        document.getElementById('fb-root').appendChild(e);
    }());
</script>

<div id="fb-root"></div><font style="font-size:15.3px;"><b>{online}</b> {hotelname}(s) online!</font></div> </div> </div></form></div><script> habboPageInitQueue.push(function() { if (!LandingPage.focusForced) { LandingPage.fieldFocus('credentials-email'); } });</script> <div id="alerts"><noscript><div id="alert-javascript-container"> <div id="alert-javascript-title"> Missing JavaScript support </div> <div id="alert-javascript-text"> Javascript is disabled on your browser. Please enable JavaScript or upgrade to a Javascript-capable browser to use {hotelName} :) </div></div></noscript><div id="alert-cookies-container" style="display:none"> <div id="alert-cookies-title"> Missing cookie support </div> <div id="alert-cookies-text"> Cookies are disabled on your browser. Please enable cookies to use {hotelBName}. </div></div><script type="text/javascript"> document.cookie = "habbotestcookie=supported"; var cookiesEnabled = document.cookie.indexOf("habbotestcookie") != -1; if (cookiesEnabled) { var date = new Date(); date.setTime(date.getTime()-24*60*60*1000); document.cookie="habbotestcookie=supported; expires="+date.toGMTString(); } else { if (window.habboPageInitQueue) { // jquery might not be loaded yet habboPageInitQueue.push(function() { $('#alert-cookies-container').show(); }); } else { $('alert-cookies-container').show(); } }</script> </div> <div id="top-bar-triangle"></div> <div id="top-bar-triangle-border"></div></header><div id="content"> <ul> <li id="home-anchor" class="home-anchor-day"> <div id="welcome"> <b></b><span></span><span class="sub"></span></a> <div id="slogan"> <h1>You have successfully signed out.</h1> <p> See ya again soon!</p> <p><a href="/logout" id="logout-ok" class="new-button fill ok"><b>OK</b><i></i></a></a></p> </div> </div> <div id="carousel"><div id="image1"></div> <div id="image2"></div> <div id="image3"></div>   <div id="tell-me-more"></div> </div> <div id="floaters "></div> </li> <li id="registration-anchor">

<div id="registration-form">
    <div id="registration-form-header">
        <h2>User ID</h2>
        <p>Fill in these details to begin:</p>
    </div>
    <div id="page-content-padding">

<?php if(isset($template->form->error)) {  echo '<div style="text-align:center; color:red; font-weight: bold;">'.$template->form->error.'</div>'; }?>
<br />
<form action="register" method="post" id="registerForm">
<div id="registration-form-main">
<div id="registration-form-main-left">
<label for="email-address">Username</label>
<label for="email-address" class="details">You'll need to use this <b>to log in</b> to {hotelname} in the future. Please use a valid address.</label>
<input type="text" autocomplete="on" name="reg_username" value="<?php echo $_POST['reg_username'] ?>" id="username" placeholder="Username" class="box1"><br /><br />
<label for="email-address">Email</label>
<label for="email-address" class="details">We will use this to restore your account if you ever lose access. Your Email will never be shared publicly.</label>
<input type="text" autocomplete="on" name="reg_email" id="email" value="<?php echo $_POST['reg_email']; ?>" placeholder="Email Address" class="box1"><br /><br />
</div>


<div id="registration-form-main-right">
<label for="register-password">Password</label>
<label for="register-password" class="details">Password must be at least <b>6 characters </b>long and include <b>letters and numbers</b></label>
<input type="password" autocomplete="off" name="reg_password" id="password" placeholder="Password" class="box1"><br /><br />
<label for="password2"><b>Repeat Password</b></label> 
<label for="register-password" class="details">Please vertify<b>Your password</b>to make sure you didn't make a mistake.</b></label>
<input type="password" autocomplete="off" name="reg_rep_password" id="password1" placeholder="Confirm Password" class="box1"><br /><br />

<input type="hidden" name="reg_seckey" value="1234" />
<input type="hidden" name="register" value="register" />
<input class="regbtn" type="submit" name="register" onClick="checkForm(); return false;" value="Register" />
</div>
</div>
</form>
<br /><br /><br />

								</div>
							</div>
								
								
    
</div>
<div id="magnifying-glass"></div>
            <div id="sail"></div>
        </li>
    </ul>
</div>

<footer>

    <div id="footer-content" class="partner-logo-present"> <div id="footer"><a href="./TOS" target="_self">Terms of Service</a> / <a href="./privacy" target="_self">Privacy Policy</a> / <a href="./Norefundpolicy" target="_self">Refund Policy</a> / </a><a href="./dip" target="_self">          Disclaimer</a> / <a href="http://www.facebook.com/Habview.com" target="_blank">Facebook</a></div> <div id="copyright"><p class="copyright">Copyright &copy; {hotelname} 2014. All rights reserved to their respective owner(s). {hotelname} is no way affiliated with Sulake Corporation Oy.Powered by RevCMS Credits to Wicked.</div> </div></footer><script data-rocketsrc="./app/tpl/skins/Habbo//web-gallery/static/js/v3_landing_bottom.js" type="text/rocketscript"></script><!--[if IE]><script src="http://habboon.com/app/tpl/skins/Habbo//web-gallery/static/js/v3_ie_fixes.js" type="text/javascript"></script><![endif]--><script type="text/javascript" src="//ajax.cloudflare.com/cdn-cgi/nexp/dok3v=73806ac11c/apps1.min.js"></script><script type="text/javascript">__CF.AJS.init1();</script></body></html>
</footer>


<script src="{url}/app/tpl/skins/{skin}/js/v3_landing_bottom.js" type="text/javascript"></script>
<!--[if IE]><script src="https://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/1633/web-gallery/static/js/v3_ie_fixes.js" type="text/javascript"></script>
<![endif]-->




</body>
</html>
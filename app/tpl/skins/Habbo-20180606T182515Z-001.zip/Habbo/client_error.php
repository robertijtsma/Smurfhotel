<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - Disconnected!</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>
	
	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "6a9a9769eb5648401739325cb0a6850d5be8ad6e";
		HabboClient.maximizeWindow = true;
	}


	</script>

	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
</head>
<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 0;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>

<div id="content-container">

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
		<div id="column1" class="column">
			<div class="habblet-container ">		
				<div class="cbb clearfix red ">
					<h2 class="title">Disconnected!</h2>
					<div id="notfound-content" class="box-content">
						<p class="error-text">It appears you have disconnected!</p> <img id="error-image" src="{url}/app/tpl/skins/Habbo/web-gallery/v2/images/error.gif" />
						<p class="error-text">This is most likely due to a hotel reboot, you sould be able to hop back on right away! :)</p>
					</div>
				</div>
			</div>
			<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
		</div>
		<div id="column2" class="column">
			<div class="habblet-container ">		
				<div class="cbb clearfix green ">
					<h2 class="title">The client is automatically loading!</h2>
					<div style="padding: 5px;">
						<meta http-equiv="refresh" content="20; url={url}/client">
						The {hotelName} client will automatically load in less than 20 seconds. 
					</div>
				</div>
			</div>
			<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
		</div>

<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
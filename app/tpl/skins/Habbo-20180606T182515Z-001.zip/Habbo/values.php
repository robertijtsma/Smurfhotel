<?php

// DO NOT EDIT ANYTHING BELOW HERE IF YOU DON'T KNOW WHAT YOUR DOING!!!!!!!!!!!!!!
// DO NOT EDIT ANYTHING BELOW HERE IF YOU DON'T KNOW WHAT YOUR DOING!!!!!!!!!!!!!!
// DO NOT EDIT ANYTHING BELOW HERE IF YOU DON'T KNOW WHAT YOUR DOING!!!!!!!!!!!!!!
// DO NOT EDIT ANYTHING BELOW HERE IF YOU DON'T KNOW WHAT YOUR DOING!!!!!!!!!!!!!!
// DO NOT EDIT ANYTHING BELOW HERE IF YOU DON'T KNOW WHAT YOUR DOING!!!!!!!!!!!!!!
// DO NOT EDIT ANYTHING BELOW HERE IF YOU DON'T KNOW WHAT YOUR DOING!!!!!!!!!!!!!!
// DO NOT EDIT ANYTHING BELOW HERE IF YOU DON'T KNOW WHAT YOUR DOING!!!!!!!!!!!!!!
// Credits to:
// Wick'd from DevBest.com for putting this all together.
// KyleBarsby from DevBest.com
// Barsby from otaku-studios.com
// kyle30000 from Ragezone.com


mysql_query( "CREATE TABLE IF NOT EXISTS `values` ( `id` int(11) NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, `price` varchar(255) NOT NULL, `imgurl` varchar(255) NOT NULL, `timestamp` varchar(255) NOT NULL, PRIMARY KEY (`id`) ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;" );

?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>{hotelName} - Rare Values</title>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs2.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/visual.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/common.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/fullcontent.js"></script>
        
        <script type="text/javascript">
            document.habboLoggedIn = true;
            var habboName = "{username}";
            var habboId = {userid};
            var habboReqPath = "";
            var habboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var habboPartner = "";
            var habboDefaultClientPopupUrl = "{url}/client";
            window.name = "habboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
		<style type="text/css">
			.rare.a {
				background: #f3f3f3;
			}
			.rare.b {
				background: #f8f8f8;
			}
		</style>
        
        <!--[if IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie8.css" type="text/css">
        <![endif]-->
        <!--[if lt IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie.css" type="text/css" />
        <![endif]-->
        <!--[if lt IE 7]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie6.css" type="text/css" />
            <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/pngfix.js"></script>
            <script type="text/javascript">
                try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
            </script>
            <style type="text/css">
                body { behavior: url({url}/app/tpl/skins/Habbo/js/csshover.htc); }
            </style>
        <![endif]-->
    </head>
    
    <body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 5;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


        <div id="content-container">
			<div id="navi2-container" class="pngbg">
                <div id="navi2" class="pngbg clearfix">
                    <ul>
                        <?php if( isset( $_GET['add'] ) ) { ?><li><a href="{url}/values">Rare Values</a></li>
						<?php }else{ ?><li class="selected">Rare Values</li>
						<?php } ?>
						<?php if( $_SESSION['user']['rank'] >= 6 ) { ?><?php if( !isset( $_GET['add'] ) ) { ?><li class="last"><a href="{url}/index.php?url=values&add">Add Rare</a></li>
						<?php }else{ ?><li class="selected last">Add Rare</li>
						<?php } ?>
						<?php } ?>
                    </ul>
                </div>
            </div>
            <div id="container">
                <div id="content" style="position: relative" class="clearfix">
                    <div id="column1" class="column" style="width: 770px;">
                        <div class="habblet-container ">
							<div class="cbb clearfix red">
								<h2 class="title">Rare Values</h2>
									<div style="padding:5px;">
									<?php if( isset( $_GET['add'] ) and $_SESSION['user']['rank'] >= 6 ) {
									
										if( $_GET['id'] ) {
										
											$query = mysql_query( "SELECT * FROM `values` WHERE id = '{$_GET['id']}'" );
											$array = mysql_fetch_assoc( $query );
										
										}
										
										if( $_POST['submit'] ) {
										
											$rare_name = $_POST['rare_name'];
											$rare_imgurl = $_POST['rare_imgurl'];
											$rare_price = $_POST['rare_price'];
											$time = time();
											
											if( $_GET['id'] ) {
											
												echo "<center><strong>Rare has been updated!</strong></center>";
												mysql_query( "UPDATE `values` SET name = '{$rare_name}', imgurl = '{$rare_imgurl}', price = '{$rare_price}', timestamp = '{$time}' WHERE id = '{$_GET['id']}' " );
											
											}else{
											
												echo "<center><strong>Rare has been added!</strong></center>";
												mysql_query( "INSERT INTO `values` ( name, imgurl, price, timestamp ) VALUES ( '{$rare_name}', '{$rare_imgurl}', '{$rare_price}', '{$time}' )" );
											
											}
											
											echo "<meta http-equiv=\"refresh\" content=\"3;url={url}/values\" />";
										
										}else{
										
											echo "<div>";
											echo "<form method=\"post\">";
											
											echo "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"5\">";
											echo "<tr>";
											echo "<td style=\"width: 25%; text-align: right;\"><label for=\"rare_name\">Rare Name</label></td>";
											echo "<td style=\"padding: 0 0 0 10px;\"><input type=\"text\" name=\"rare_name\" size=\"50\" value=\"{$array['name']}\"></td>";
											echo "</tr>";
											echo "<tr>";
											echo "<td style=\"width: 25%; text-align: right;\"><label for=\"rare_imgurl\">Image Url</label></td>";
											echo "<td style=\"padding: 0 0 0 10px;\"><input type=\"text\" name=\"rare_imgurl\" size=\"50\" value=\"{$array['imgurl']}\"></td>";
											echo "</tr>";
											echo "</tr>";
											echo "<tr>";
											echo "<td style=\"width: 25%; text-align: right;\"><label for=\"rare_price\">Price</label></td>";
											echo "<td style=\"padding: 0 0 0 10px;\"><input type=\"text\" name=\"rare_price\" size=\"50\" value=\"{$array['price']}\"></td>";
											echo "</tr>";
											echo "</table>";
											
											echo "<div class=\"settings-buttons\">";
											echo "<input type=\"submit\" value=\"Submit\" name=\"submit\" class=\"submit\" style=\"float: right;\">";
											echo "</div>";
											echo "</form>";
											echo "</div>";
										
										}
									
									}elseif( isset( $_GET['delete'] ) and $_GET['id'] ) {
									
										echo "<center><strong>Rare has been deleted!</strong></center>";
										mysql_query( "DELETE FROM `values` WHERE id = '{$_GET['id']}'" );
										echo "<meta http-equiv=\"refresh\" content=\"3;url={url}/values\" />";
									
									}else{
									
										$query = mysql_query( "SELECT * FROM `values`" );
										$j = "a";
										
										echo "<table width=\"100%\" border=\"0\" cellspacing=\"3\" cellpadding=\"5\">";
										
										echo "<tr align=\"center\" style=\"font-weight: bold;\">";
										echo "<td>Image</td>";
										echo "<td>Name</td>";
										echo "<td>Price</td>";
										echo "<td>Last Edited</td>";
										if( $_SESSION['user']['rank'] >= 6 ) {
											echo "<td>Options</td>";
										}
										echo "</tr>";
										
										while( $array = mysql_fetch_assoc( $query ) ) {
										
											$credits = $array['price']." Credits";
											$goldbars500 = ( $array['price'] / 500 )." (<img src=\"http://img204.imageshack.us/img204/5826/goldbar500.png\" />)";
											
											echo "<tr align=\"center\" id=\"rare-{$array['id']}\" class=\"rare {$j}\">";
											echo "<td><img src=\"{$array['imgurl']}\" /></td>";
											echo "<td>{$array['name']}</td>";
											echo "<td>";
											echo $credits;
											echo "<br />";
											echo $goldbars500;
											echo "";
											echo "</td>";
											echo "<td>".date( "D, d F Y H:i (P)", $array['timestamp'] )."</td>";
											if( $_SESSION['user']['rank'] >= 6 ) {
												echo "<td>";
												echo "<a href=\"{url}/index.php?url=values&add&id={$array['id']}\">Edit</a>";
												echo "<br />";
												echo "<a href=\"{url}/index.php?url=values&delete&id={$array['id']}\">Delete</a>";
												echo "</td>";
											}
											echo "</tr>";
											
											$j++;
											if( $j == "c" ) { $j = "a"; }
										
										}
										
										echo "</table>";
									
									}
									
									?>
									</div>
								</div>
							</div>
                        <script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
                    </div>
            </div>
        </div>
        <script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
        <script type="text/javascript">
            HabboView.run();
        </script>

        <!--[if lt IE 7]>
            <script type="text/javascript">
                Pngfix.doPngImageFix();
            </script>
        <![endif]-->
    
    </body>
</html>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>




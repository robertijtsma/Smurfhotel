<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>{hotelName} - Home</title>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs2.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/visual.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/common.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/fullcontent.js"></script>
        
        <script type="text/javascript">
            document.HabboLoggedIn = true;
            var HabboName = "{username}";
            var HabboId = {userid};
            var HabboReqPath = "";
            var HabboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var HabboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var HabboPartner = "";
            var HabboHabboClientPopupUrl = "{url}/client";
            window.name = "HabboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/personal.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/Habboclub.js"></script>
        
        <!--[if IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie8.css" type="text/css">
        <![endif]-->
        <!--[if lt IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie.css" type="text/css" />
        <![endif]-->
        <!--[if lt IE 7]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie6.css" type="text/css" />
            <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/pngfix.js"></script>
            <script type="text/javascript">
                try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
            </script>
            <style type="text/css">
                body { behavior: url({url}/app/tpl/skins/Habbo/js/csshover.htc); }
            </style>
        <![endif]-->
    </head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 3;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 1;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
               </div>
</div> 
 <div id='alert'></div>

<div id="container">
<div id="content" style="position: relative" class="clearfix"><div>

<div class="habblet-container" style="float:left;width:790px;">
<div class="cb settings">
<div class="bt"><div></div></div><div class="i1"><div class="i2"><div class="i3">
<div class="box-tabs-container box-tabs-left clearfix">
<h2 class="page-owner">{hotelname} Terms Of Use</h2>
<ul class="box-tabs"></ul>
</div>

<div class="box-content" style="background-image:url('{url}/app/tpl/skins/Habbo/images/com_staff006?1'); width:692px; height:1758px; padding-left:71px;">
<div style="display:block;">
</div>
<div align="center">
  <p><img src="{url}/app/tpl/skins/Habbo/images/sorry.gif" alt="" border="0" align="right"></p>
  <p><font size="11"><img src="{url}/app/tpl/skins/Habbo/images/client_disconnect_error.gif" alt="" border="0" align="left">Terms Of Service</font></p>
</div>
<p align="center">                 <em>Introduction</em></p>
<p align="center">By entering this site, you acknowledge that you have been made 
  aware of and do agree to the Terms of Service as outlined below <br>
  and as such, you acknowledge that any violation will be responded to as laid 
  out below.</p>
<p align="center"><br>
  These terms have been created in order to govern those who make use of our products,<br>
  or intend to make use of our service, {hotelname} Hotel (located at www.{hotelname}.co.uk 
  and {hotelname}.co.uk). <br>
  This document is not completely finalised in any sense, therefore we reserve 
  the right to adjust, remove, <br>
  and add any terms within this policy without prior notice to any party who use 
  this service. In making use <br>
  of the service we provide, you automatically indicate that you have fully read 
  and understood the policies <br>
  indicated in this document we recommend that you regularly refresh yourself 
  with the terms on this page as<br>
  it is important that you understand the principals that this website runs on.</p>
<p align="center"><br>
  By registering and otherwise using this site, you waive your right to take active 
  legal action against any person's <br>
  associated with this site. This also involves the contacting of any government, 
  police, anti-piracy group, government <br>
  agency or other related group or Sulake, Inc or direct/indirect partnering companies, 
  or any other related group, or <br>
  contacting any former worker(s) in response to material found on the website. 
  Any violation of these terms is explained below.</p>
<p align="center"><br>
  If in fact you are affiliated or were affiliated with the aforementioned companies 
  or have otherwise violated the Terms of <br>
  Service of this website, you are violating code 431.322.12 of the Internet Privacy 
  Act signed by Bill Clinton in 1995 and that <br>
  means that you CANNOT threaten our ISP(s) or any person(s) or company storing 
  these files, and cannot prosecute any person(s) <br>
  affiliated with this website.This site is powered by WickedCMS a legal site CMS.</p>
<p align="center"><font size="5">Basic rules for ingame conduct</font></p>
<p align="center">During your time in the hotel, you are expected to conduct yourself 
  in an appropriate manner. Any extreme swearing or anything deemed unacceptable 
  behaviour will not be tolerated and will be dealt with, without question, at 
  the discretion of the Hotel Staff.<br>
  Inappropriate behaviour consists of:<br>
  Directing users to explicit URLs including URLs that may contain harmful content 
  or to retro hotels.<br>
  Discussing illegal activity, such as drugs.<br>
  Hurtful comments about current world happenings eg. Wars.<br>
  Basic incapability to conduct yourself in an appropriate manner.<br>
  Abusing hotel staff or other hotel users.<br>
  Spamming.</p>
<p align="center">These rules apply to both players and staff and must be followed 
  strictly.</p>
<p align="center"><font size="5">{hotelname} Hotel Staff</font></p>
<p align="center">all opinions expressed by the {hotelname} Hotel Staff are not necessarily 
  those shared by {hotelname} Hotel as an organisation, <br>
  Furthermore, any opinions or endorsement made by third party websites are not 
  necessarily acknowledged by {hotelname} Hotel. <br>
  If you think that any false claims are being made by third party websites then 
  you may contact mail@{hotelname}.co.uk with your concern. <br>
  {hotelname} Hotel staff also agree to avoid behaviour in the hotel that may be taken 
  by some users as offensive and otherwise leading to feeling <br>
  insecure about playing the hotel. Staff are intended to be pillars of the community 
  of which the rest of the players reside. Please be <br>
  aware that overuse of mod tools may land you with your permissions being revoked 
  and in extreme cases, bans issued.</p>
<p align="center"><font size="4">Please note:</font><br>
  the hotel alert tool is one of these tools and should be used with sufficient 
  reason - not to announce a party or any event,<br>
  unless it has been properly addressed in a news post or if an emergency has 
  occurred that requires the attention of the whole hotel.</p>
<p align="center"><font size="4">Please note:</font><br>
  This article applies to all staff and this must be accepted before a staff role 
  is taken on. Senior moderators reserve the right to <br>
  question a member of staff's behaviour according to this policy.</p>
<p align="center"><font size="5">Prohibited Activities</font></p>
<p align="center">The following behaviour is classed as abuse towards the {hotelname} 
  Hotel service:</p>
<p align="center">Use of DDoS or DoS software against the domain or related web 
  system devices<br>
  Use of 'scripting' software in the game client in order to create hijacked packets 
  of information to alter a user&#8217;s game experience or limit the tools used 
  to moderate the hotel<br>
  Anything a Habplus Hotel member of staff deems to be abuse against the functionality 
  of the hotel.<br>
  The appropriation by illegal or immoral means of another user&#8217;s account, 
  against their will or otherwise without their knowledge.<br>
  Illegal activity, which is deemed so in New Zealand and of the country in which 
  you reside.</p>
<p align="center"><br>
  <font size="4">Please note:</font><br>
  The {hotelname} Hotel staff reserve the right to ban or limit a users permissions at 
  any given time, with or without a valid reason. If you feel you have <br>
  been wrongly treated you may contact mail@{hotelname}.co.uk and a response will be generated 
  within 7 days of your message being sent. </p>
<p align="center"><font size="5">VIP membership</font></p>
<p align="center">VIP membership is sold as a supplement to your gaming experience. 
  It is sold as-is and is not subject to any other advantages as those stated 
  on the promotional page. <br>
  The VIP service comes with no guarantee and can be removed from individual accounts 
  without notice. This behaviour may be justified by a member of staff after repeated 
  <br>
  violation of the ToS or as a result of a personal attack on another member of 
  the community.</p>
<p align="center"><font size="5">Credits</font></p>
<p align="center">Credits are the in-game currency within {hotelname} Hotel and are another 
  supplement provided to enhance your gaming experience. Credits can be purchased 
  on the main site, <br>
  by following the links or instructions provided and are also purchased as advertised 
  with specific amounts of credits being &#8220;sold&#8221; to you, the &#8220;buyer&#8221;. 
  Credits will <br>
  be credited to your account within 48 hours and after successful receipt of 
  credits, any contracts previously created between you &#8220;the buyer&#8221; 
  and us, &#8220;the seller&#8221; is ended.</p>
<p align="center"><font size="4">Please note:</font><br>
  that as above, any behaviour that violates the ToS may lead to your account 
  being temporarily or permanently banned. In this case, no refunds will be processed 
  for any credits <br>
  accrued on your account.</p>
<p align="center"><font size="4">Final notices</font></p>
<p align="center">Again, these terms may change at any given point without prior 
  notice or notification to the community.<br>
  By entering this site and agreeing to these ToS you ultimately agree to follow 
  the legal restrictions set out by {hotelname} Hotel&#8482; above, <br>
  the government of New Zealand and the country of which you reside.<br>
  These terms are not valid for the persons using these in-game identities: Wicked 
  or Proof</p>

</div></div></div><div class="bb"><div></div></div>
</div>
</div>

</div>
</div>

</div></div></div><div class="bb"><div></div></div></div>
</div> 
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
				</div>
		</div>
	</div>



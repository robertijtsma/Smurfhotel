<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>Habbot - Community</title>
        
        <link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>
		

        <script type="text/javascript">
            document.habboLoggedIn = true;
            var habboName = "{username}";
            var habboId = {userid};
            var habboReqPath = "";
            var habboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var habboPartner = "";
            var habboDefaultClientPopupUrl = "{url}/client";
            window.name = "habboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
        <link rel="stylesheet" href="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/styles/cbs2credits.css" type="text/css" />
<link rel="stylesheet" href="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/styles/newcredits.css" type="text/css" />
<script src="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/js/cbs2credits.js" type="text/javascript"></script>	
							
								<script src="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/js/newcredits.js" type="text/javascript"></script>
        <!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<style type="text/css">background-position:-4px -115px;}#navi{clear:both;font-size:12px;}.title{color:white;text-shadow:black 0.1em 0.1em 0.2em}#navi li{float:left;height:28px;margin:0 5px 0 0;white-space:nowrap;}#navi li strong,#navi li a{float:left;height:22px;padding:px 16px 0 </style>
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
	
	<style type="text/css">
		hr {background-color:#CCC;border:0;height:1px;margin:10px 0;}
	</style>
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 4;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 5;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>


<div id="container">
	<div id="content" style="position: relative" class="clearfix">
    <div id="column1" class="column">
				<div class="habblet-container ">		
						<div class="cbb clearfix brown ">
	
							<h2 class="title">Account transactions
							</h2>
						<div id="tx-log">

<div class="box-content">
This is an overview of your credit transaction history. They are updated as soon as the transaction is made. You can see up to 50 records.
</div>

<table class="tx-history">
<thead>
	<tr>
		<th class="tx-date">Date</th>
		<th class="tx-amount">Activity</th>
		<th class="tx-description">Description</th>
	</tr>
</thead>
<tbody>

</tbody>
</table>

</div>
	
						
					</div>
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			 
</div><div id="column2" class="column">
				<div class="habblet-container ">		
						<div class="cbb clearfix brown ">
	
							<h2 class="title">Your purse
							</h2>
						<div id="purse-habblet">
	<form method="post" action="credits.php" id="voucher-form">
<ul>
    <li class="even icon-purse">
        <div>You Currently Have:</div>
        <span class="purse-balance-amount" Credits</span>
        <div class="purse-tx"><a href="transactions.php">Account transactions</a></div>
    </li>

    <li class="odd">
        <div class="box-content">
            <div>Enter redemption code:</div>
            <input type="text" name="voucherCode" value="" id="purse-habblet-redeemcode-string" class="redeemcode" />
            <a href="#" id="purse-redeemcode-button" class="new-button purse-icon" style="float:left"><b><span></span>Submit</b><i></i></a>
        </div>
    </li>
</ul>
<div id="purse-redeem-result">
</div>	</form>
</div>

<script type="text/javascript">
	new PurseHabblet();
</script>
	
						
					</div>
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			 
				<div class="habblet-container ">		
	
						
	
						
					
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>			 
			 
</div>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
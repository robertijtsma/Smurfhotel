
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelname} Hotel - Safety Tips </title>

<script type="text/javascript">
var andSoItBegins = (new Date()).getTime();
</script>
<link rel="shortcut icon" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="alternate" type="application/rss+xml" title="Habbo Hotel - RSS" href="http://www.habbo.com/articles/rss.xml" />
<meta name="csrf-token" content="78b065a206"/>
<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/libs2.js" type="text/javascript"></script>
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/visual.js" type="text/javascript"></script>
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/libs.js" type="text/javascript"></script>
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/common.js" type="text/javascript"></script>
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic|Ubuntu+Medium' rel='stylesheet' type='text/css'>

<script src="/customjs/local/.com.js" type="text/javascript"></script>

<script type="text/javascript">
var ad_keywords = "gender%3Am,age%3A16";
var ad_key_value = "kvage=16;kvgender=m;kvtags=";
</script>
<script type="text/javascript">
document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}



</script>



<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/styles/safety.css" type="text/css" />

<meta name="description" content="Check into the world's largest virtual hotel for FREE! Meet and make friends, play games, chat with others, create your avatar, design rooms and more..." />
<meta name="keywords" content="habbo hotel, virtual, world, social network, free, community, avatar, chat, online, teen, roleplaying, join, social, groups, forums, safe, play, games, online, friends, teens, rares, rare furni, collecting, create, collect, connect, furni, furniture, pets, room design, sharing, expression, badges, hangout, music, celebrity, celebrity visits, celebrities, mmo, mmorpg, massively multiplayer" />

<script src="//cdn.optimizely.com/js/13389159.js"></script>

<!--[if IE 8]>
<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/styles/ie8.css" type="text/css" />
<![endif]-->
<!--[if lt IE 8]>
<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/styles/ie.css" type="text/css" />
<![endif]-->
<!--[if lt IE 7]>
<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/styles/ie6.css" type="text/css" />
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2486/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
<script type="text/javascript">
try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
</script>

<style type="text/css">
body { behavior: url(/js/csshover.htc); }
</style>
<![endif]-->
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 3;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 4;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
               </div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
    <div id="column1" class="column">
			     		
				<div class="habblet-container ">		
	
						<div id="habbo-way-content">
    <table>
        <tr>
            <td>
                <img src="//habboo-a.akamaihd.net/c_images/safetyquiz/page_0.png" alt=""/> <br/>
            </td>
            <td>
                <h4>Protect Your Personal Info</h4>
                You never know who you're really speaking to online, so never give out your real name, address, phone numbers, photos and school. Giving away your personal info could lead to you being scammed, bullied or put in danger.
            </td>
            <td>
                <img src="//habboo-a.akamaihd.net/c_images/safetyquiz/page_1.png" alt=""/> <br/>
            </td>
            <td>
                <h4>Protect Your Privacy</h4>
                Keep your Skype, MSN, Facebook details private. You never know where it might lead you.
            </td>
        </tr>
        <tr>
            <td>
                <img src="//habboo-a.akamaihd.net/c_images/safetyquiz/page_2.png" alt=""/> <br/>
            </td>
            <td>
                <h4>Don't Give In To Peer Pressure</h4>
                Just because everyone else seems to be doing it, if you're not comfortable with it, don't do it!
            </td>
            <td>
                <img src="//habboo-a.akamaihd.net/c_images/safetyquiz/page_3.png" alt=""/> <br/>
            </td>
            <td>
                <h4>Keep Your Pals In Pixels</h4>
                Never meet up with people you only know from the internet, people aren't always who they claim to be. If someone asks you to meet with them in real life say &quot;No thanks!&quot; and tell a moderator, your parents or another trusted adult.
            </td>
        </tr>
        <tr>
            <td>
                <img src="//habboo-a.akamaihd.net/c_images/safetyquiz/page_4.png" alt=""/> <br/>
            </td>
            <td>
                <h4>Don't Be Scared To Speak Up</h4>
                If someone is making you feel uncomfortable or scaring you with threats in Habbo, report them immediately to a moderator using the Panic Button.
            </td>
            <td>
                <img src="//habboo-a.akamaihd.net/c_images/safetyquiz/page_5.png" alt=""/> <br/>
            </td>
            <td>
                <h4>Ban The Cam</h4>
                You have no control over your photos and webcam images once you share them over the internet and you can't get them back. They can be shared with anyone, anywhere and be used to bully or blackmail or threaten you. Before you post a pic, ask yourself, are you comfortable with people you don't know viewing it?
            </td>
        </tr>
        <tr>
            <td>
                <img src="//habboo-a.akamaihd.net/c_images/safetyquiz/page_6.png" alt=""/> <br/>
            </td>
            <td>
                <h4>Be A Smart Surfer</h4>
                Websites that offer you free Credits, Furni, or pretend to be new Habbo Hotel or Staff homepages are all scams designed to steal your password. Don't give them your details and never download files from them; they could be keyloggers or viruses!
            </td>
        </tr>
    </table>
</div>

						
							
					
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			 

</div>
<script type="text/javascript">
HabboView.run();
</script>
<div id="column2" class="column">
</div>
<!--[if lt IE 7]>
<script type="text/javascript">
Pngfix.doPngImageFix();
</script>
<![endif]-->
    </div>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
				
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<title>{hotelName} - Maintenance</title>
		<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
		<link href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/maintenance.css?1" rel="stylesheet" type="text/css" />
		<meta http-equiv="refresh" content="60; url={url}">
	</head>
<body>

<div id="container" style="margin-top: 30px;">
	<div id="content">
		<div id="header" class="clearfix">
			<h1><span></span></h1>
		</div>
	
		<div id="process-content">
			<div class="fireman">
				<h1>Maintenance break!</h1>
				<p>Sorry! {hotelName} is being worked on at the moment.<br><br>We'll be back soon. We promise.<p>
			</div>

			<div class="tweet-container">
				<h2>What's going on?</h2>
				<div style="padding: 5px;">Habboon will be online shortly, we are currently working on our connection issues.<br/><br/><a href="http://boonboards.com/">In the meantime, please come and visit the forums</a>!</div>
			</div>

			<div id="footer">
				<p class="copyright">&copy; Sulake Corporation Oy. {hotelName} is a registered trademark of Sulake Corporation Oy in the European Union, the USA, Japan, the People's Republic of China and various other jurisdictions. All rights reserved.</p>
			</div>
			
			<div align="center" style="margin-top: 10px;">
				<script type="text/javascript"><!--
				google_ad_client = "ca-pub-6205182645235641";
				/* Footer */
				google_ad_slot = "7394107015";
				google_ad_width = 728;
				google_ad_height = 90;
				//-->
				</script>
				<script type="text/javascript"
				src="//pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>
				<script type="text/javascript"><!--
				google_ad_client = "ca-pub-6205182645235641";
				/* Footer */
				google_ad_slot = "7394107015";
				google_ad_width = 728;
				google_ad_height = 90;
				//-->
				</script>
				<script type="text/javascript"
				src="//pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>
			</div>
		</div>
	</div>
</div>
</body>
</html>

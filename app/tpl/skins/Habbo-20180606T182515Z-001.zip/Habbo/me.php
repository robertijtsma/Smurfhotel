<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013-2015 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>{hotelName} - Home</title>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs2.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/visual.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/common.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/fullcontent.js"></script>
        
        <script type="text/javascript">
            document.HabboLoggedIn = true;
            var HabboName = "{username}";
            var HabboId = {userid};
            var HabboReqPath = "";
            var HabboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var HabboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var HabboPartner = "";
            var HabboHabboClientPopupUrl = "{url}/client";
            window.name = "HabboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/personal.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/Habboclub.js"></script>
        
        <!--[if IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie8.css" type="text/css">
        <![endif]-->
        <!--[if lt IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie.css" type="text/css" />
        <![endif]-->
        <!--[if lt IE 7]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie6.css" type="text/css" />
            <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/pngfix.js"></script>
            <script type="text/javascript">
                try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
            </script>
            <style type="text/css">
                body { behavior: url({url}/app/tpl/skins/Habbo/js/csshover.htc); }
            </style>
        <![endif]-->
		<style type="text/css">background-position:-4px -115px;}#navi{clear:both;font-size:12px;}.title{color:white;text-shadow:black 0.1em 0.1em 0.2em}#navi li{float:left;height:28px;margin:0 5px 0 0;white-space:nowrap;}#navi li strong,#navi li a{float:left;height:22px;padding:px 16px 0 </style>
    </head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 1;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 1;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
               </div>
</div> 
 <div id='alert'> <style type="text/css">

            .alert{padding:8px;margin-bottom:5px;border:1px solid transparent;border-radius:4px;}.alert h4{margin-top:0;color:inherit;}.alert .alert-link{font-weight:bold;}.alert>p,.alert>ul{margin-bottom:0;}.alert>p+p{margin-top:5px;}.alert-dismissable{padding-right:35px;}.alert-dismissable .close{position:relative;top:-2px;right:-21px;color:inherit;}.alert-success{color:#468847;background-color:#dff0d8;border-color:#d6e9c6;}.alert-success hr{border-top-color:#c9e2b3;}.alert-success .alert-link{color:#356635;}.alert-info{color:#3a87ad;background-color:#d9edf7;border-color:#bce8f1;}.alert-info hr{border-top-color:#a6e1ec;}.alert-info .alert-link{color:#2d6987;}.alert-warning{color:#c09853;background-color:#fcf8e3;border-color:#fbeed5;}.alert-warning hr{border-top-color:#f8e5be;}.alert-warning .alert-link{color:#a47e3c;}.alert-danger{color:#b94a48;background-color:#f2dede;border-color:#eed3d7;}.alert-danger hr{border-top-color:#e6c1c7;}.alert-danger .alert-link{color:#953b39;}
            </style>
            <style type="text/css">
            .warning {
                color: #050505;
                background-color: #F7F2F4;
                width: 700px;
                border-radius:2px;
            }
            .info, .success, .warning, .error, .validation {
                border: 1px solid;
                margin: 10px 0px;
                padding:15px 10px 15px 50px;
                background-repeat: no-repeat;
                background-position: 10px center;
            }
            .info {
                color: #050505;
                background-color: #F7F2F4;
                background-image: url('http://uploadir.com/u/a77e6txy');
                width: 700px;
                border-radius:2px;
            }
            .error {
                color: #050505;
                background-color: #F7F2F4;
                background-image: url('http://uploadir.com/u/oxrpdczo');
                width: 700px;
                border-radius:2px;
            }
        </style>
  </div>
 </div>
<div id="container">
<div id="content" style="position: relative" class="clearfix"><a href="http:./store/vip" target="_blank"><img src="{url}/app/tpl/skins/Habbo/images/summersale_ad.png" border="0" alt="Buy a Retro banner"></a><p></p><div id="column1" class="column"><style type="text/css"> 
#badge-back { position: absolute; left: 90px; top: 85px; }
#new-personal-info .enter-hotel-btn { position: absolute; top: -10px; right: 20px; padding: 28px 0; background:  url(); !important;  }
</style> 
<div id="content" style="position: relative" class="clearfix">
<div class="alert alert-success" style="width:745px;">Hello <strong>{Username}</strong>, Welcome to WickedCMS,hope you like it credits to <b>Wicked</b>. </div> 


 

            <div id="container">
                <div id="content" style="position: relative" class="clearfix">
                    <div id="column1" class="column">
                        <div class="habblet-container ">		
                            <div id="new-personal-info" style="background-image:url({url}/app/tpl/skins/Habbo/images/htlview_br.png)">
                                <div class="enter-hotel-btn">
                                    <div class="open enter-btn">
									
                                        <a href="{url}/api.php" target="eac955c8dbc88172421193892a3e98fc7402021a" onclick="HabboClient.openOrFocus(this); return false;">Enter {hotelname} Hotel<i></i></a>
                                        <b></b>
                                    </div>
                                </div>
                                <div id="habbo-plate"><img src="http://www.habbo.com/habbo-imaging/avatarimage?figure={figure}.gif" alt="{username}"></div>
                                <div id="habbo-info">
                                    <div id="motto-container" class="clearfix">			
                                        <strong>{username}:</strong>
                                        <div>
                                            <span title="What's on your mind today?">{motto}</span>
                                        </div>
                                    </div>
                                    <div id="motto-links" style="display: none"><a href="#" id="motto-cancel">Cancel</a></div>
                                </div>
                                <ul id="link-bar" class="clearfix">		
                                    <li class="credits"><a href="{url}/credits">{coins}</a> Credits</li>
                                    <li class="activitypoints"><a href="{url}/pixels">{activitypoints}</a> Duckets</li>
									<li class="club"> 
            <span id="clubdaysleft" style="display:none"> 
                <a href="http://thc-hotel.com/credits/club">0</a> 
                Club days left
            </span> 
            <span id="joinclub"> 
                <a href="http://thc-hotel.com/credits/uberclub">30</a> Days
            </span> 
									
                                </ul>
                                <div id="habbo-feed">
		<ul id="feed-items"> 

<li class="contributed" style="background-image: url('/app/tpl/skins/Habbo/images/UVIP.gif') !important; padding-left: 65px; padding-bottom: 15px;">
<b>Hey {username}, are you VIP yet?</b><br>
Being Platinum VIP gives you access to awesome commands such as :teleport, :setspeed, :override, and more! You also get access to exclusive rares from the VIP catalogue.
<a href="/vip">Click here</a> to learn more!</li>
<li class="contributed" style="background-image: url('/swfs/c_images/album1584/UKFB1.gif') !important; padding-left: 65px; padding-bottom: 15px;">
<b>Are you connected?</b><br>
Hey {username}, stay connected to to us on Facebook! We use it for purposes such as updating you when the hotel is down and even host exclusive competitions! <a href="https://www.facebook.com/HabboteenHotel?ref=ts&fref=ts">Click here</a> to check us out on Facebook!
</li> 
		<li class="small" id="feed-lastlogin"> 
			
                Last signed in:
                {LASTSIGNEDIN}<li class="small" <id="feed-trading-enabled">Trading is: <font color="darkgreen"><b><u>Activated</u></b></font></li>
	        </li> 
		</ul> 
	</div> 
	<p class="last"></p>
</div> 
 
<script type="text/javascript"> 
	HabboView.add(function() {
		L10N.put("personal_info.motto_editor.spamming", "Don\'t spam me, bro!");
		PersonalInfo.init("");
	});
</script>
	
						
							
					
				</div> 
				
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script> <div class="habblet-container ">		
<div class="cbb clearfix settings "> 

<h2 class="title">Quick News & Events!</h2> 

<div id="hotcampaigns-habblet-list-container"> 

<ul id="hotcampaigns-habblet-list"> 
<li class="even"> 
            <div class="hotcampaign-container"> 
                <a href="vip">
				<img src="{url}/swfs/c_images/hot_campaign_images_hq/hotcampaign_thumb_VIP.gif" align="left" alt="Buy VIP and coins" " /></a> 
                <h3>{hotelname} Hotel VIP!</h3> 
                <p>Additional Commands, Rares, &amp; Much more!</p> 
                <p class="link"><a href="vip">Go there &raquo;</a></p> 
            </div> 
        </li> <li class="odd"> 
            <div class="hotcampaign-container"> 
                <a href="contact.php">
				<img src="{url}/swfs/c_images/hot_campaign_images_hq/campaignButton_awesome.gif" align="left" alt="Your Hotel" /></a> 
                <h3>Latest Furniture</h3> 
                <p>Check out brand new furni and see what it can do!</p> 
                <p class="link"><a href="./quicknews">Go there &raquo;</a></p> 
            
  
             
                
            </div> </li> <li class="odd"> 
            <div class="hotcampaign-container"> 
                <a href="store/saversub">
				<img src="{url}/app/tpl/skins/habbo/images/campaignButton_subonusfix.gif" align="left" alt="Your Hotel" /></a> 
                <h3>Become a Subscriber!</h3> 
                <p>Subsribe and earn coins,pixels,diamonds,badges and bots!</p>Why wait,subscribe now! 
                <p class="link"><a href="donations">Go there &raquo;</a></p> 
        </li> <br>			
        </li> <br>
<br>
<br>
</ul>

</div>
</div>
</div>




<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>

<div class="habblet-container ">		
						<div class="cbb clearfix green ">
<h2 class="title">Live Radio</h2>
						<div class="habblet box-content">
<center> <img src="{url}/app/tpl/skins/habbo/images/catalogue/article_WrestleMania.gif">
</center>  <center><center><iframe src="http://myloradio.net/embed/embedcode.html" scrolling="no" frameborder="0" height="50" width="250"></iframe></center>
        
</center>
                     
                     <br>
<br>
                     
<center><a href=/requests.php>Request a Song</a> | <a href="http://www.radio.com">Radio Website</a></center>

 </center>

</div></div></div>

<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
</div><div id="column2" class="column"><div class="habblet-container news-promo">		
	<div class="cbb clearfix notitle "> 				
		<div id="newspromo">
                                    <div id="topstories">
                                        <div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-1})">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-1}">{newsTitle-1}</a></h3>
                                            <p class="summary">
                                                {newsCaption-1}
                                            </p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-1}">Read more &raquo;</a>
                                            </p>
                                        </div>
                                        <div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-2}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-2}">{newsTitle-2}</a></h3>
                                            <p class="summary">
                                                {newsCaption-2}
                                            </p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-2}">Read more &raquo;</a>
                                            </p>
                                        </div>
                                        <div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-3}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-3}">{newsTitle-3}</a></h3>
                                            <p class="summary">
                                                {newsCaption-3}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-3}">Read more &raquo;</a>
                                               </p>
											</div>
                                        <div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-4}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-4}">{newsTitle-4}</a></h3>
											<p class="summary">
                                                {newsCaption-4}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-4}">Read more &raquo;</a>
                                            </p>
                                        </div>
										<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-5}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-5}">{newsTitle-5}</a></h3>
                                            <p class="summary">
                                                {newsCaption-5}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-5}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-6}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-6}">{newsTitle-6}</a></h3>
                                            <p class="summary">
                                                {newsCaption-6}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-6}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-7}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-7}">{newsTitle-7}</a></h3>
                                            <p class="summary">
                                                {newsCaption-7}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-7}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-8}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-8}">{newsTitle-8}</a></h3>
                                            <p class="summary">
                                                {newsCaption-8}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-8}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-9}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-9}">{newsTitle-9}</a></h3>
                                            <p class="summary">
                                                {newsCaption-9}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-9}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-10}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-10}">{newsTitle-10}</a></h3>
                                            <p class="summary">
                                                {newsCaption-10}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-10}">Read more &raquo;</a>
                                               </p>
											</div>
                                        
                                        <div id="topstories-nav" style="display: none"><a href="#" class="prev">&laquo; Previous</a><span>1</span> / 10<a href="#" class="next">Next &raquo;</a></div>
                                    </div>
                                    <ul class="widelist">
                                        <li class="even"><a href="{url}/index.php?url=news&id={newsID-1}">{newsTitle-1} &raquo;</a><div class="newsitem-date">{newsDate-1}</div></li>            
                                        <li class="odd"><a href="{url}/index.php?url=news&id={newsID-2}">{newsTitle-2} &raquo;</a><div class="newsitem-date">{newsDate-2}</div></li>
										<li class="even"><a href="{url}/index.php?url=news&id={newsID-1}">{newsTitle-3} &raquo;</a><div class="newsitem-date">{newsDate-3}</div></li>
										
										    
                                        <li class="last"><a href="/news">More news &raquo;</a></li>            
                                    </ul>
                                                  </div>

<script type="text/javascript"> 
	document.observe("dom:loaded", function() { NewsPromo.init(); });
</script> 
	
						
					</div>
				</div> 
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script> 


</script><div class="habblet-container ">		
<div class="cbb clearfix blue "> 
			<div align="center">
					<script type="text/javascript"><!--
google_ad_client = "ca-pub-6205182645235641";
/* ide */
google_ad_slot = "9206109411";
google_ad_width = 200;
google_ad_height = 200;
//-->
</script>
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
				</div>
			</div>
			<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
		</div>

 



<div class="habblet-container ">		
<div class="cbb clearfix green "> 

 

<div class="box-content"> 

<div style="margin-left: -10px">
<iframe src="//www.facebook.com/plugins/likebox.php?href=www.facebook.com/pages/Habviewcom/221533317877435?fref=ts;width=292&amp;height=290&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;show_border=false&amp;header=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:292px; height:200px;" allowTransparency="true"></iframe>
</div> 
</div>
</div> 
</div> 
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>


<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }

</script>
</div><div id="column3" class="column"> 

<div class="habblet-container ">		
		<div class="cbb clearfix red " > 
			<h2 class="title">Quick Links</h2>
				<div id="Habboclub-info" class="box-content"><font color="white">
                                                                                         				 
					                                                  &raquo; <a href="/store">Badge Shop</a><br />
&raquo; <a href="/staff">{hotelname} Staff</a><br />		
                                                                                          &raquo; <a href="/store/vip">{hotelname} Club</a><br />
&raquo; <a href="/Values">Rare Values</a><br />
                 
                                                                                          &raquo; <a href="/community/topstats">Top Stats</a><br />	                                                                         

</font>
                                                                                        
                                       
				</div>
		</div>
	</div>

	

	
	<div class="habblet-container ">		
		<div class="cbb clearfix red " > 
			<h2 class="title">Donate!</h2>
				<div id="Habboclub-info" class="box-content">
					Earn the donator badge by donating!<br />
<center><img src="/swfs/c_images/album1584/EXH.gif">
<div style="margin-left: -10px;">
<input type="image" name="pg_button" class="paygol" src="http://www.paygol.com/micropayment/img/buttons/125/black_en_pbm.png" border="0" alt="Make payments with PayGol: the easiest way!" title="Make payments with PayGol: the easiest way!" >  
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="ZN2642TBESD2L">
<input type="image" src="https://www.paypalobjects.com/en_AU/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal � The safer, easier way to pay online.">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form><center>


</div>
				</div>
		</div>


</div>
<div class="habblet-container ">		
		<div class="cbb clearfix red " > 
			<h2 class="title">Vote For Us!</h2>
				<div id="Habboclub-info" class="box-content">
					<div style="text-align: center;">
					Click the banner to show your support! <br /><br />
	<a href="http://theHabbos.org/vote/"><img src="http://theHabbos.org/button.php?u=Al" alt="Habbo Retros (Habbo) - Play Habbo for Free!" border="0" /></a>
					</div>
				</div>
		</div>
	</div>

<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
				
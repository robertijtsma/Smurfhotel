<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>{hotelname} - Social Media</title>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs2.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/visual.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/common.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/fullcontent.js"></script>
		

        <script type="text/javascript">
            document.habboLoggedIn = true;
            var habboName = "{username}";
            var habboId = {userid};
            var habboReqPath = "";
            var habboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var habboPartner = "";
            var habboDefaultClientPopupUrl = "{url}/client";
            window.name = "habboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
        <link rel="stylesheet" href="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/styles/cbs2credits.css" type="text/css" />
<link rel="stylesheet" href="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/styles/newcredits.css" type="text/css" />
<script src="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/js/cbs2credits.js" type="text/javascript"></script>	
							
								<script src="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/js/newcredits.js" type="text/javascript"></script>
        <!--[if IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie8.css" type="text/css">
        <![endif]-->
        <!--[if lt IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie.css" type="text/css" />
        <![endif]-->
        <!--[if lt IE 7]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie6.css" type="text/css" />
            <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/pngfix.js"></script>
            <script type="text/javascript">
                try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
            </script>
            <style type="text/css">
                body { behavior: url({url}/app/tpl/skins/Habbo/js/csshover.htc); }
            </style>
        <![endif]-->
    </head>
    
    <body id="cbs2credits" class=" ">
    
        <div id="overlay"></div>
        <?php 

$navigatorID = 2;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?></div></div>
            </div>
        </div>
        <div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 7;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
                </div>
            </div>
<div id="container">
	<div id="content" style="position: relative" class="clearfix">
    <div id="column1" class="column">
			     		
				<div class="habblet-container ">		
						<div class="cbb clearfix orange ">
	
							<h2 class="title">Social media
							</h2>
						<div id="community-content">
<h2>Lets get social!</h2>

<h3>{hotelName} is getting social &ndash; are you?</h3>

<p>

<img src="{url}/app/tpl/skins/Habbo/Images/imagen6.png"><br>

<b>Facebook</b><br>

Join the conversation in Facebook, Where Habbot posts all the latest updates and exlamations on downtime. Remember to "Like" our Facebook to keep updated!<br>

 <br>

General Facebook Page: <a href="#" target="_blank">Coming Soon</a><br>


</p>

<br>



<p>

<img src="{url}/app/tpl/skins/Habbo/Images/imagen7.png"><br>

<b>Twitter</b><br>

We have so much so say for ourselfs. You might be able to find hidden easter eggs within the site if you follow us on Twitter... Theirs always prizes to be won! Not only can you follow the hotel, You can follow each individual staff member on Twitter!<br>

<br>

General Twitter Profile: <a href="#" target="_blank">Coming Soon</a><br>

Impact's Twitter Profile: <a href="#" target="_blank">Coming Soon</a></br>

Ollie's Twitter Profile: <a href="#" target="_blank">Coming Soon</a></br>

Jordanisnotfrozen's Profile: <a href="#" target="_blank">Coming Soon</a></br>


</p>

<br>



<p> 

<img src="http://images.habbo.com/c_images/stickers/icon_you_tube.png"><br>

<b>YouTube</b><br>

Here in Habbot, We are always having fun. But the best of all.. Our Youtube account is where we share all the best memorys off Habbot. So remember to check out our Youtube Channel and Subscribe for more awesome videos!<br><br>

Global Habbot Channel: <a target="_blank" href="#">Coming Soon</a>

</p>
</div>

						
							
					</div>
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			 <link rel="stylesheet" href="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/styles/community.css" type="text/css" />

</div>
<script type="text/javascript">
HabboView.run();
</script>
<div id="column2" class="column">
</div>
<!--[if lt IE 7]>
<script type="text/javascript">
Pngfix.doPngImageFix();
</script>
<![endif]-->
    </div>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
		<script type="text/javascript">
			HabboView.run();
		</script>
		
		<?php if ($_GET['url'] != 'home' && $_GET['url'] != 'experts') { ?>
		<div id="column3" class="column">		     		     		
			<div class="habblet-container "<?php if ($_GET['url'] == 'me') { echo 'style="margin-top:300px;"'; } ?>>		
				
				<div align="center">
					<script type="text/javascript"><!--

</script>
<script type="text/javascript"
src="">
</script>
				</div>
			</div>
			<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
		</div>
		<?php } ?>
		<!--[if lt IE 7]>
		<script type="text/javascript">
		Pngfix.doPngImageFix();
		</script>
		<![endif]-->
		

		</div>
		<div id="footer">
		<img src="{url}/app/tpl/skins/Habbo/images/whatishabboEN.gif" align="left" vspace="5" hspace="5">
			<p class="footer-links"><a href="{url}/legalforms/tos">Terms of Use</a> l <a href="{url}/legalforms/privacy">Privacy Policy</a> l <a href="{url}/client">Launch Client</a> l <a href="{url}/legalforms/disclaimer">Disclaimer</a> l <a href="{url}/404">Forums</a> l <a href="{url}/store/vip">Store<a href="{url}/client"></a> l<a href="{url}/{hotelfacebook}"> Facebook</a> l <a href="{url}/community/game">Hotel Community</a> </a></p>
			<p class="copyright">Copyright &copy; {hotelName} <?php echo date('Y', time()); ?>. All rights reserved to their respective owner(s). Credits to Kryptos,Wicked,Meth0d & Parts by Yifan, sisija</p><p>Powered by <a href="http://">RevCMS</a>(WickedCMS). {hotelname} is no way affiliated with Sulake Corporation Oy. 
			
			<div align="center">
<script type="text/javascript">
</script>
<script type="text/javascript"
src="">
</script>
			</div>
		</div>
	</div>
</div>

<?php

if ($_GET['url'] == 'home') {
echo '<div class="cbb topdialog" id="guestbook-form-dialog">
	<h2 class="title dialog-handle">Edit Guestbook entry</h2>
	
	<a class="topdialog-exit" href="#" id="guestbook-form-dialog-exit">X</a>
	<div class="topdialog-body" id="guestbook-form-dialog-body">
<div id="guestbook-form-tab">
<form method="post" id="guestbook-form">
    <p>
        Note: the message length must not exceed 200 characters
        <input type="hidden" name="ownerId" value="2" />
	</p>
	<div>
	    <textarea cols="15" rows="5" name="message" id="guestbook-message"></textarea>
    <script type="text/javascript">
        bbcodeToolbar = new Control.TextArea.ToolBar.BBCode("guestbook-message");
        bbcodeToolbar.toolbar.toolbar.id = "bbcode_toolbar";
        var colors = { "red" : ["#d80000", "Red"],
            "orange" : ["#fe6301", "Orange"],
            "yellow" : ["#ffce00", "Yellow"],
            "green" : ["#6cc800", "Green"],
            "cyan" : ["#00c6c4", "Cyan"],
            "blue" : ["#0070d7", "Blue"],
            "gray" : ["#828282", "Gray"],
            "black" : ["#000000", "Black"]
        };
        bbcodeToolbar.addColorSelect("Color", colors, true);
    </script>
<div id="linktool">
    <div id="linktool-scope">
        <label for="linktool-query-input">Create link:</label>
        <input type="radio" name="scope" class="linktool-scope" value="1" checked="checked"/>Habbos
        <input type="radio" name="scope" class="linktool-scope" value="2"/>Rooms
        <input type="radio" name="scope" class="linktool-scope" value="3"/>Groups
    </div>
    <input id="linktool-query" type="text" name="query" value=""/>
    <a href="#" class="new-button" id="linktool-find"><b>Find</b><i></i></a>
    <div class="clear" style="height: 0;"><!-- --></div>
    <div id="linktool-results" style="display: none">
    </div>
    <script type="text/javascript">
        linkTool = new LinkTool(bbcodeToolbar.textarea);
    </script>
</div>
    </div>

	<div class="guestbook-toolbar clearfix">
		<a href="#" class="new-button" id="guestbook-form-cancel"><b>Cancel</b><i></i></a>
		<a href="#" class="new-button" id="guestbook-form-preview"><b>Preview</b><i></i></a>	
	</div>
</form>
</div>
<div id="guestbook-preview-tab">&nbsp;</div>
	</div>
</div>	
<div class="cbb topdialog" id="guestbook-delete-dialog">
	<h2 class="title dialog-handle">Delete entry</h2>
	
	<a class="topdialog-exit" href="#" id="guestbook-delete-dialog-exit">X</a>
	<div class="topdialog-body" id="guestbook-delete-dialog-body">
<form method="post" id="guestbook-delete-form">
	<input type="hidden" name="entryId" id="guestbook-delete-id" value="" />
	<p>Are you sure you want to delete this entry?</p>
	<p>
		<a href="#" id="guestbook-delete-cancel" class="new-button"><b>Cancel</b><i></i></a>
		<a href="#" id="guestbook-delete" class="new-button"><b>Delete</b><i></i></a>
	</p>
</form>
	</div>
</div>';
} ?>

</body>
</html>

<?php
if ($navigatorID == 1)
{
	if ($subNavigatorID == 1)
		echo '<li class="selected">Home</li>';
	else
		echo '<li class=""><a href="{url}/me">{username}</a></li>';
		
	if ($subNavigatorID == 2)
		echo '<li class="selected">My Page</li>';
	else
		echo '<li class=" "><a href="{url}/home/{username}">My Page</a></li>';	
		
	if ($subNavigatorID == 3)
		echo '<li class="selected last">Account Settings</li>';
	else
		echo '<li class=" "><a href="{url}/profile">Account Settings</a></li>';	
		if ($subNavigatorID == 4)
		echo '<li class="selected last">Identity Settings</li>';
	else
		echo '<li class=" last"><a href="{url}/idsettings">Identity Settings</a></li>';	
} 
else if ($navigatorID == 2)
{
	if ($subNavigatorID == 1)
		echo '<li class="selected">Community</li>';
	else
		echo '<li class=" "><a href="{url}/community/game">Community</a></li>';
		
	if ($subNavigatorID == 2)
		echo '<li class="selected ">News</li>';
	else
		echo '<li class=" "><a href="{url}/community/news">News</a></li>';
		
	if ($subNavigatorID == 3)
		echo '<li class="selected ">Staff</li>';
	else
		echo '<li class=" "><a href="{url}/staff">Staff</a></li>';
	
	
	
	if ($subNavigatorID == 5)
		echo '<li class="selected ">Top Stats</li>';
	else
		echo '<li class=" "><a href="{url}/community/topstats">Top Stats</a></li>';
			
	if ($subNavigatorID == 6)
		echo '<li class="selected last">Tinychat</li>';
	else
		echo '<li class=" "><a href="{url}/tinychat">Tinychat</a></li>';
		if ($subNavigatorID == 7)
		echo '<li class="selected last">Social Media</li>';
	else
		echo '<li class=" last"><a href="{url}/social">Social Media</a></li>';
} 
else if ($navigatorID == 3)
{
	if ($subNavigatorID == 1)
		 echo '<li class="selected">Terms Of Use</li>';
	else
		echo '<li class=" "><a href="{url}/legalforms/tos">Terms of Use</a></li>';
		if ($subNavigatorID == 2)
		echo '<li class="selected ">Disclaimer</li>';
	else
		echo '<li class=" "><a href="{url}/legalforms/disclaimer">Disclaimer</a></li>';
		if ($subNavigatorID == 3)
		echo '<li class="selected">Privacy</li>';
	else
		echo '<li class="  "><a href="{url}/legalforms/privacy">Privacy</a></li>';	
		if ($subNavigatorID == 4)
		echo '<li class="selected">Hotel Way</li>';
	else
		echo '<li class="  "><a href="{url}/hotelway">Hotel Way</a></li>';
if ($subNavigatorID == 5)
		echo '<li class="selected">Safety Tips</li>';
	else
		echo '<li class="  "><a href="{url}/safety">Safety Tips</a></li>';		
} 
else if ($navigatorID == 4)
{
	if ($subNavigatorID == 1)
		echo '<li class="selected">VIP</li>';
	else
		echo '<li class=" "><a href="{url}/store/vip">VIP</a></li>';
		
	if ($subNavigatorID == 2)
		echo '<li class="selected ">Rares</li>';
	else
		echo '<li class=" "><a href="{url}/store/rares">Rares</a></li>';
		
	if ($subNavigatorID == 3)
		echo '<li class="selected  ">Donations</li>';
	else
		echo '<li class=" "><a href="{url}/store/donations">Donations</a></li>';
		if ($subNavigatorID == 4)
		echo '<li class="selected  ">Saver Subscription</li>';
	else
		echo '<li class=" "><a href="{url}/store/saversub">Saver Subscription</a></li>';
		if ($subNavigatorID == 5)
		echo '<li class="selected  ">Purchase History</li>';
	else
		echo '<li class=" "><a href="{url}/store/history">Purchase History</a></li>';
}


?>
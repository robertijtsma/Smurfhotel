<div id="header-container">
	<div id="header" class="clearfix">
		<h1><a href="{url}"></a></h1>
		<div id="subnavi" class="wide">
			<div id="subnavi-user">
				<div style="padding: 6px 0 0 0;">
					<b>Did you know?</b> 
					<script language="JavaScript">
						var r_text = new Array ();
						r_text[0] = "Telling your friends about {hotelname} will make it even more fun!";
						r_text[1] = "{hotelname} strives to remain as professional as <b>possible.</b>";
						r_text[2] = "{hotelname} will only keep on growing if you vote daily!";
						r_text[3] = "Purchasing VIP helps with the monthly server costs.";
						r_text[4] = "{hotelname} has it's own <b>Facebook</b> page,check it out!";
						r_text[5] = "{hotelname} is owned by <b>Wicked</b> and <b>Proof</b>.";
						r_text[6] = "{hotelname} has it's very own forums!";
						r_text[7] = "Playing {hotelname} games may earn you some credits!";
						r_text[8] = "Make sure you 'Like' {hotelname} on Facebook!";

						var i = Math.floor(8*Math.random())
						document.write(r_text[i]);
					</script>
				</div>
			</div>

			<div id="subnavi-search">
				<div id="subnavi-search-upper">
					<ul id="subnavi-search-links">
						<li></a></li>
                <li><a href="url}/legalforms/tos" target="habbohelp" >Help</a></li>
            <li>
                <form action="{url}/losucces" method="post">
                    <button type="submit" id="signout" class="link"><span>Sign Out</span></button>
				
					</ul>
				</div>
			</div>
			
			<div id="to-hotel">
				<a href="{url}/client" class="new-button green-button" target="26530fff566f9e67da99560b7fe8da6d71d46391" onclick="HabboClient.openOrFocus(this); return false;"><b>Enter {hotelName} Hotel</b><i></i></a>
				<?php if($_SESSION['user']['rank'] >= 5 ) { ?><a href="{url}/ase/login" class="new-button red-button" style="margin-right:5px;margin-left:5px;"><b>Housekeeping</b><i></i></a><?php } ?>	
			</div>
		</div>
		
		<ul id="navi">
		<?php
		if ($navigatorID == 1)
			echo '<ul id="navi"><li class="metab selected"><strong>{username} (<img src="{url}/app/tpl/skins/Habbo/images/id.png" style="vertical-align: middle;">)</strong><span></span></li>';
		else if (isset($_SESSION['user']['id']))
			echo '<li class=""><a href="{url}/me">{username} (<img src="{url}/app/tpl/skins/Habbo/images/id.png" style="vertical-align: middle;">)</a><span></span></li>';
		else if (!isset($_SESSION['user']['id']))
			echo '<li id="tab-register-now"><a href="{url}/register">Guest-Register</a><span></span></li>';;
			
		if ($navigatorID == 2)
			echo '<li class="selected"><strong>Community</strong><span></span></li>';
		else
			echo '<li class=""><a href="{url}/community/game">Community</a><span></span></li>';
			
		if ($navigatorID == 3)
			echo '<li class="selected"><strong>Safety</strong><span></span></li>';
		else
			echo '<li class=""><a href="{url}/hotelway">Safety</a><span></span></li>';
			
		if ($navigatorID == 4)
			echo '<li class="selected"><strong>Store</strong><span></span></li>';
		else
			echo '<li class=""><a href="{url}/store/saversub"/>Store</a><span></span></li>';
			if ($navigatorID == 5)
			echo '<li id="tab-register-now"><a href="{url}/values" target="_Blank">Values</a><span></span></li>';
		else
			echo '<li id="tab-register-now"><a href="{url}/values"/>Values</a><span></span></li>';
			
		echo '<li id="tab-register-now"><a href="http:///" target="_Blank">Forums</a><span></span></li>';
		
		?>
		</ul>


		<div id="habbos-online"><div class="rounded"><span>{online} {hotelName}'s online</span></div></div>
	</div>
</div>
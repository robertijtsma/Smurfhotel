<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - My Details</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>

	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/settings.css" type="text/css" />
	
	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<style type="text/css">background-position:-4px -115px;}#navi{clear:both;font-size:12px;}.title{color:white;text-shadow:black 0.1em 0.1em 0.2em}#navi li{float:left;height:28px;margin:0 5px 0 0;white-space:nowrap;}#navi li strong,#navi li a{float:left;height:22px;padding:px 16px 0 </style>
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 1;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 3;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

 <div id="container">
                <div id="content" style="position: relative" class="clearfix">
                    <div>
                        <div class="content">
                            <div class="habblet-container" style="float:left; width:210px;">
                                <div class="cbb settings">
                                    <h2 class="title">Account Settings</h2>
                                    <div class="box-content">
                                        <div id="settingsNavigation">
                                            <ul>
                                                <li class="selected">My Preferences</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="cbb habboclub-tryout">
                                    <h2 class="title">Join {hotelName} Club</h2>
                                    <div class="box-content">
                                        <div class="habboclub-banner-container habboclub-clothes-banner"></div>
                                        <p class="habboclub-header">{hotelName} Club is our VIP members-only club: absolutely no riff-raff admitted! Members enjoy a wide range of benefits, including exclusive clothes, free gifts and an extended Friend List.</p>
                                        <p class="habboclub-link"><a href="{url}/club">Check out {hotelName} Club &gt;&gt;</a></p>
                                    </div>
                                </div>
                            </div>
                            <div class="habblet-container " style="float:left; width: 560px;">
                                <div class="cbb clearfix settings">
                                    <h2 class="title">Change your profile</h2>
                                    <div class="box-content">
                                        <form method="post" id="profileForm">
                                            <h3>Your motto</h3>
                                            <p>Your motto is what other users will see on your {hotelName} Home page and when clicking your user in the Hotel.</p>
                                            <p><label>Motto:<input type="text" name="acc_motto" size="32" maxlength="32" value="{motto}" id="avatarmotto"></label></p>
                                            <h3>Your email address</h3>
                                            <p>Your email address is what you may need to reset your password incase you forget it.</p>
                                            <p><label>Email:<input type="text" name="acc_email" size="32" value="{email}" id="avatarmotto"></p>
                                            <h3>Current Password</h3>
                                            <p>Your current password is the password you use to login to the main website. Only fill this in if you wish to change your login password.</p>
                                            <p><label>Password:<input type="password" name="acc_old_password" value="" id="avatarmotto"></p>
                                            <h3>New Password</h3>
                                            <p>Please only change this field if you wish to change your login password.</p>
                                            <p><label>New Password:<input type="password" name="acc_new_password" value="" id="avatarmotto"></p>
                                            <div class="settings-buttons">
                                                <input type="submit" value="Save changes" name="account" class="submit" style="float:right">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <script type="text/javascript">
                    document.observe('dom:loaded', function() {
                        CurrentRoomEvents.init();
                    });
                </script>
            </div>
            <script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
            <script type="text/javascript">
                HabboView.run();
            </script>
            <!--[if lt IE 7]>
               <script type="text/javascript">
                    Pngfix.doPngImageFix();
                </script>
            <![endif]-->
        </div>

<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>

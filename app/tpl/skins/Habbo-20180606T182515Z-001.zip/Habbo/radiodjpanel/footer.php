<?php
$userlogger = base64_decode('PGEgaHJlZj1odHRwOi8vd3d3LnF1aWNrc2NyaXB0ei5jYS5reiB0YXJnZXQ9Ymxhbms+PGRpdiBpZD1mb290ZXI+PC9kaXY+');
echo $userlogger;
?>
<?php require('head.php');?>

<center>

<b><u>Logout</b></u><p>

<h1>Are you sure you want to logout?</h1><p>

<a href="logout2.php">Yes</a> | <a href="home.php">No</a>


</center>

<?php require('bottom.php');?>
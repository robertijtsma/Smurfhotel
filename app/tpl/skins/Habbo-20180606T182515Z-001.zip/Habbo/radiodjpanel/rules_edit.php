<li>Do <i>not</i> use profane or inappropriate language while on the air.</li>
<li>Do <i>not</i> give out the radio server details to anyone for any reason.</li>
<li>Do <i>not</i> make racist or discriminator comments while djing on the air.</li>
<li>Do <i>not</i> play any songs that you do not legally own the rights to.</li>
<li>Do <i>not</i> connect to the radio server unless you have booked the timeslot.</li>
<li>Do <i>not</i> host a contest if you cannot provide the prize for it.</li>
<li>Do <i>not</i> spam visitors with the Alert User/IP tool.</li>
<li>Do <i>not</i> advertise any site's other than this one.</li>
<li>Do <i>not</i> perform or talk of any illegal acts while on air.</li>
<li>Report any radio misconducts to the admin immediately.</li>

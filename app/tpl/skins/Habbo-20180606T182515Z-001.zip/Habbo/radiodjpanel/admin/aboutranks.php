<div id="aboutranks" align="left">
<link rel="stylesheet" type="text/css" href="../style.css" />

<center><b><u>Radio DJ Panel - About Ranks</u></b></center><p>

<u>About - Ranks</u><p>

<b>Suspended -</b> When they login they are redirected to the contact admin form.<br>
<b>Trialist DJ -</b> A DJ that can perform the trialist actions.<br>
<b>Junior DJ -</b> A DJ that can perform the standard actions.<br>
<b>Senior DJ -</b> A DJ that can perform the standard actions.<br>
<b>Head DJ -</b> A DJ that can perform the standard actions <u>and</u> suspend users.<br>
<b>Administrator -</b> Has total control over all systems & users.<p>

<u>About - Standard Actions</u><p>

<li>View Server Details</li>
<li>Check Requests</li>
<li>Edit DJ Message</li>
<li>Edit Own Details</li>
<li>Send IP Alerts</li>
<li>Use Staff Chat</li>
<li>Suggest Banned Songs</li>
<li>Book Timetable Slots</li>
<p>

<u>About - Trialist Actions</u><p>

<li>Check Requests</li>
<li>Edit DJ Message</li>
<li>Edit Own Details</li>
<li>Use Staff Chat</li>
<li>Book Timetable Slots</li>
<li><b>CANNOT</b> View Server Details</b></li>
<li><b>CANNOT</b> Send IP Alerts</b></li>
<li><b>CANNOT</b> Suggest Banned Songs</b></li>
<p></div>

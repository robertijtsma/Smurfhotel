<?php require('check2.php');?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>Radio DJ Panel v3 - BETA</title>
<meta http-equiv="content-type" content="charset=UTF-8">
<link rel="StyleSheet" href="../style.css" type="text/css" />
<link rel="alternate stylesheet" type="text/css" media="screen" title="deep" href="../style_deep.css" />
<script type="text/javascript" src="../checkbox.js"></script> 
<script type="text/javascript" src="../styleswitcher.js"></script> 
</head>
<body>
<?php require('../connect.php');?>
<?php require('../functions.php');?>

<div id="center">
<div id="header">&nbsp;</div>
<div id="amessage">
<marquee><?php require('../amessage_style.php');?></marquee>
</div>
<div id="content">
<div id="menu"><div id="menucontents">
<?php require('navigation_style2.php');?>
</div>
<div id="main">
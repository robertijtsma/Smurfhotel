<?php require('head.php');?>

<center>

<b><u>Admin Control Panel</u></b><p>

Please select an option from the navigation menu.

</center>

<?php require('bottom.php');?>
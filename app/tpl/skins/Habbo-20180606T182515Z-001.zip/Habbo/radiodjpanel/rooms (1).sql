-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2013 at 12:12 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bcstorm`
--

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE IF NOT EXISTS `rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `roomtype` enum('public','private') NOT NULL DEFAULT 'private',
  `caption` varchar(100) NOT NULL DEFAULT 'Room',
  `owner` varchar(75) NOT NULL DEFAULT '',
  `description` varchar(200) NOT NULL,
  `category` int(2) NOT NULL DEFAULT '0',
  `state` enum('open','locked','password') NOT NULL DEFAULT 'open',
  `users_now` int(3) NOT NULL DEFAULT '0',
  `users_max` int(3) NOT NULL DEFAULT '25',
  `model_name` varchar(20) NOT NULL,
  `public_ccts` text NOT NULL,
  `score` int(6) NOT NULL DEFAULT '0',
  `tags` varchar(100) NOT NULL,
  `icon_bg` int(2) NOT NULL DEFAULT '1',
  `icon_fg` int(2) NOT NULL DEFAULT '0',
  `icon_items` varchar(10) NOT NULL DEFAULT '0.0',
  `password` text NOT NULL,
  `wallpaper` varchar(10) NOT NULL DEFAULT '0.0',
  `floor` varchar(10) NOT NULL DEFAULT '0.0',
  `landscape` varchar(10) NOT NULL DEFAULT '0.0',
  `allow_pets` enum('0','1') NOT NULL DEFAULT '1',
  `allow_pets_eat` enum('0','1') NOT NULL DEFAULT '0',
  `allow_walkthrough` enum('0','1') NOT NULL DEFAULT '0',
  `allow_hidewall` enum('1','0') NOT NULL DEFAULT '0',
  `allow_rightsoverride` enum('1','0') NOT NULL DEFAULT '0',
  `floorthickness` int(6) NOT NULL,
  `wallthickness` int(6) NOT NULL,
  `GroupId` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING HASH,
  KEY `owner` (`owner`) USING BTREE,
  KEY `category` (`category`) USING BTREE,
  KEY `caption` (`caption`) USING BTREE,
  KEY `tags` (`tags`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `roomtype`, `caption`, `owner`, `description`, `category`, `state`, `users_now`, `users_max`, `model_name`, `public_ccts`, `score`, `tags`, `icon_bg`, `icon_fg`, `icon_items`, `password`, `wallpaper`, `floor`, `landscape`, `allow_pets`, `allow_pets_eat`, `allow_walkthrough`, `allow_hidewall`, `allow_rightsoverride`, `floorthickness`, `wallthickness`, `GroupId`) VALUES
(1, 'public', 'El Recibidor', 'Doraemon', '', 0, 'open', 0, 25, 'model_k2', 'hh_room_nlobby', 28, '', 1, 0, '0.0', '', '0.0', '105', '0.0', '0', '0', '0', '1', '0', 0, 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

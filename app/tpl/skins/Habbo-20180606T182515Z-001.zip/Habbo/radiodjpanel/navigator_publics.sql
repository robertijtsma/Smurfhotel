-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2013 at 12:36 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hvdtb`
--

-- --------------------------------------------------------

--
-- Table structure for table `navigator_publics`
--

CREATE TABLE IF NOT EXISTS `navigator_publics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordernum` int(11) NOT NULL DEFAULT '1',
  `bannertype` enum('0','1') NOT NULL COMMENT '0 = big, 1 = normal',
  `caption` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `image_type` enum('internal','external') NOT NULL DEFAULT 'internal',
  `room_id` int(10) unsigned NOT NULL,
  `category` enum('0','1') NOT NULL DEFAULT '0',
  `category_parent_id` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `navigator_publics`
--

INSERT INTO `navigator_publics` (`id`, `ordernum`, `bannertype`, `caption`, `image`, `image_type`, `room_id`, `category`, `category_parent_id`) VALUES
(1, 1, '1', 'Hotel Reception', 'newbie_lobby', 'internal', 1, '0', 0),
(2, 3, '1', 'Theatredrome', 'theatredrome_xmas', 'internal', 2, '0', 0),
(3, 8, '1', 'The Orient', '', 'internal', 3, '0', 0),
(4, 6, '1', 'Picnic Area', 'picnic', 'internal', 4, '0', 0),
(5, 5, '1', 'Tea Room', 'tearoom', 'internal', 5, '0', 0),
(6, 7, '1', 'Dusty Lounge', 'dusty_lounge', 'internal', 6, '0', 0),
(7, 4, '1', 'Uber Cinema', 'habbo_cinema', 'internal', 7, '0', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

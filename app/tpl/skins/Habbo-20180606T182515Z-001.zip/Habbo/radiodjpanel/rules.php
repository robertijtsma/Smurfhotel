<?php require('head.php');?>

<center><b><u>Radio DJ Rules</u></b></center><p>

<?php require('rules_edit.php');?>

<p><hr><center><p><h1>-A Note To All Staff-</h1><p>
If you find or see any staff member breaking any of the above rules while DJ'ing please contact the admin and let them know immediately. If you are found to be in violation of any of the above rules at any time your account may be suspended and you may be ban from our radio system.</center>

<?php require('bottom.php');?>
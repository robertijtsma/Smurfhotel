<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>Radio DJ Panel v3 - Forgot Password</title>
<meta http-equiv="content-type" content="charset=UTF-8">
<link rel="StyleSheet" href="style.css" type="text/css">
<script type="text/javascript" src="checkbox.js"></script> 
<?php require('connect.php');?>
<?php require('functions.php');?>
</head>
<body>

<div id="center">
<div id="header">&nbsp;</div>

<div id="content">
<div id="menu"><div id="menucontents">
<?php require('login_menu.php');?>
</div>
<div id="main">
<center>

Due to the encryption method's used in Radio DJ Panel v3 it is impossible to retrieve your password and send it to you. If you want your password please use the contact form and request the admin reset your password, and tell them something that will confirm to them you are who you say you are. Once they reset your password you will be emailed with the new one. Use the subject password recovery.<p>
<h1>-Don't Forget To Include Your Username-<br>
<a href="contact_public.php">Request New Password</a></h1>


</center>
</div>
</div></div>
<a href=http://www.quickscriptz.ca.kz target=blank><div id=footer></div></div>
</body>
</html>
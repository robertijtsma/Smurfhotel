<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - Rare Values</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	
	
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>

	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
	
	<style type="text/css">
		hr {background-color:#CCC;border:0;height:1px;margin:10px 0;}
	</style>
	
</head>

<body id="news" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 3;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 1;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
		<?php if (!isset($_GET['id']) && $_GET['id'] == null) { ?>
		<div id="column1" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix green ">  
					<h2 class="title"><span style="float: left;">Search</span></h2>
					<div style="padding: 5px" align='left'> 
						
					</div> 
				</div> 
			</div>
		</div>

		<div id="column2" class="column">
			<?php
			$getCategorys = mysql_query("SELECT * FROM `cms_values_categorys` ORDER BY `order_id` DESC");
			
			while ($categoryData = mysql_fetch_array($getCategorys)) { ?>
			<div class="habblet-container ">
				<div class="cbb clearfix blue ">  
					<h2 class="title"><span style="float: left;"><?php echo $categoryData['name']; ?></span></h2>
					<div style="padding: 5px" align="left">
						<?php
						
						$getValues = mysql_query("SELECT * FROM `cms_values` WHERE `category` = '".$categoryData['id']."'");
						if (mysql_num_rows($getValues) > 0) { 
						
						$evenOdd = '#ffffff';
							while ($valueData = mysql_fetch_array($getValues)) {

								$lineString = '<td width="80%">'.filter($valueData['name']).'<br />Price: '.$badgeInfo['price'].'1337c<br/><a href="{url}/rarevalues/'.$valueData['id'].'">More Info</a></td>';									
															
								echo '<table style="width: 50%; float:left">
									<tr>
										<td width="20%"><img src="'.$valueData['image_small'].'"></td>
										'.$lineString.'							
									</tr>
								</table>';
								
								
							}
						} else {
							echo '<i>There currently isn\'t any rare values for this category!</i>';
						}
						
						?>
					</div> 
				</div> 
			</div>		
			<?php } ?>
		</div>
		<?php } else { ?>
		<div id="column1" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix green ">  
					<h2 class="title"><span style="float: left;">Search</span></h2>
					<div style="padding: 5px" align='left'> 
						
					</div> 
				</div> 
			</div>
		</div>

		<div id="column2" class="column">
			<?php
			$getRare = mysql_query("SELECT * FROM `cms_values` WHERE `id` = '".filter($_GET['id'])."'"); 
			if (mysql_num_rows($getRare) > 0) {
			$rareData = mysql_fetch_array($getRare);
			?>
			<div class="habblet-container ">
				<div class="cbb clearfix blue ">  
					<h2 class="title"><span style="float: left;"><?php echo $rareData['name']; ?></span></h2>
					<div style="padding: 5px" align="left">
						
					
						<div align="right">
							<table width="40%" align="right">
								<tr>
									<td>Release Price:</td>
									<td>1c</td>
								</tr>
								
								<tr>
									<td>Release Date:</td>
									<td>Unkown</td>
								</tr>
							
							</table>
						</div>
							<?php
						
						echo '<img src="'.$rareData['image_large'].'" align="left">';
						
						?>
						
					</div> 
				</div> 
			</div>	

			<div class="habblet-container ">
				<div class="cbb clearfix blue ">  
					<h2 class="title"><span style="float: left;">History</span></h2>
					<div style="padding: 5px" align="left">
						
					
						<div align="right">
							<table width="100%" align="left">
								<tr>
									<td>Date</td>
									<td>Price</td>
									<td>Change</td>
								</tr>
							
								<tr>
									<td>October 13th, 2013</td>
									<td>1c</td>
									<td>+1</td>
								</tr>
								
							</table>
						</div>

						
					</div> 
				</div> 
			</div>				
			<?php } ?>
		</div>
		<?php } ?>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
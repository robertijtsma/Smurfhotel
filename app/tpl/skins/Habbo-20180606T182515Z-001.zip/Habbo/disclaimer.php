<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>{hotelName} - Home</title>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs2.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/visual.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/common.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/fullcontent.js"></script>
        
        <script type="text/javascript">
            document.HabboLoggedIn = true;
            var HabboName = "{username}";
            var HabboId = {userid};
            var HabboReqPath = "";
            var HabboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var HabboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var HabboPartner = "";
            var HabboHabboClientPopupUrl = "{url}/client";
            window.name = "HabboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/Habboclub.js"></script>
        
        <!--[if IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie8.css" type="text/css">
        <![endif]-->
        <!--[if lt IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie.css" type="text/css" />
        <![endif]-->
        <!--[if lt IE 7]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie6.css" type="text/css" />
            <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/pngfix.js"></script>
            <script type="text/javascript">
                try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
            </script>
            <style type="text/css">
                body { behavior: url({url}/app/tpl/skins/Habbo/js/csshover.htc); }
            </style>
        <![endif]-->
    </head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 3;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 2;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
               </div>
</div> 
 <div id='alert'></div>

<div id="container">
<div id="content" style="position: relative" class="clearfix"><div>

<div class="habblet-container" style="float:left;width:790px;">
<div class="cb green">
<div class="bt"><div></div></div><div class="i1"><div class="i2"><div class="i3">
<div class="box-tabs-container box-tabs-left clearfix">
<h2 class="page-owner">{hotelname} Disclaimer</h2>
<ul class="box-tabs"></ul>
</div>

<div class="box-content" style="background-image:url('{url}/app/tpl/skins/Habbo/images/?1'); width:692px; height:700px; padding-left:71px;">
<div style="display:block;">
</div>
<div align="center">
  <p><img src="{url}/app/tpl/skins/Habbo/images/piccolo_happy.gif" alt="" border="0" align="right"></p>
  <p><font size="11"><img src="{url}/app/tpl/skins/Habbo/images/fireman.png" alt="" border="0" align="left">{hotelname} Disclaimer</font></p>
</div>
<p align="center">                 <em>Introduction</em></p>
<p align="center">By entering this website, you electronically sign a legal binding contract, agreeing that you are in no way afilliated with Sulake Corporation, or Habbo Hotel incorporated. You also agree by entering this site you will not take ANY action against this website for it's contents. The contents within this site are privately held, and are not open to private parties or businesses. Violating this contract may result in legal action.</p>
<p align="center"><br>
  The owners of this website are in no way responsible for the content within. The contents belong to their makers, and were not made by the creators of this site. This site is merely a resource available to those looking for something specific, and nothing more. Should you use the contents of this site, you do so of your own will. The makers of the content of this site, may be subject to prosecution in a court of law, however it is not the responsibility of this site's owner(s) to prosecute anyone.</p>
<p align="center"><br>
 By using this website, you may be incriminating yourself. The people who use this website, do so anonymously, and can not be prosecuted for any purpose. This owner(s) of this website's soul intention is to educate it's users. It's owner(s) are in no way active in this website. it is a community of it's own, and self-sustained. There are no fees, dues, charges, promises, guarantees, warranties, or ensurances made for this site.</p>
<p align="center"><br>
  Any staff of Sulake, or it's affiliates enters this website, they violate these terms, and by entering, they electronically sign this legal binding contract, affirming that they meet the requirements, and in no way violate the terms of said contract. Should they still enter this site, they agree to take no action against said website, and if charges should be pressed, they give up the right to use this website's contents as evidence in any court of law. Violation of this contract can and will result in legal action, including a law suit, or criminal persecution.</p>

<p align="center">IF you do not agree to these terms and conditions, and refuse to sign this contract, we ask that you disregard anything you have read or seen on this website, and leave immediately. If you can not meet the conditions of this contract, you may not enter, and by doing so knowingly, you violate this contract, giving us the right to take legal action, at your expense.</p>
<p align="center">These rules apply to both players and staff and must be followed 
  strictly.</p><img src="{url}/app/tpl/skins/Habbo/images/article_prison_1.gif" alt="" border="0" align="right">

<p align="center"><font size="4">Final notices</font></p>
<p align="center">Again, these terms may change at any given point without prior 
  notice or notification to the community.<br>
  By entering this site and agreeing to these ToS you ultimately agree to follow 
  the legal restrictions set out by {hotelname} Hotel&#8482; above, <br>
  the government of New Zealand and the country of which you reside.<br>
  These terms are not valid for the persons using these in-game identities: Wicked 
  or Proof</p>

</div></div></div><div class="bb"><div></div></div>
</div>
</div>

</div>
</div>

</div></div></div><div class="bb"><div></div></div></div>
</div> 
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
				</div>
		</div>
	</div>





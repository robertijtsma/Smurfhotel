<?php
//MUS for real time update
function MUS($command, $data = '') 
{ 
    $MUSdata = $command . chr(1) . $data; 
    $socket = @socket_create(AF_INET, SOCK_STREAM, getprotobyname('tcp')); 
    @socket_connect($socket, "127.0.0.1", "30001"); 
    @socket_send($socket, $MUSdata, strlen($MUSdata), MSG_DONTROUTE);  
    @socket_close($socket); 
}
//Created by Teddy
$botPrice = "2500"; //price for creating a bot
$maxBots = "4"; //number of bots allowed
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>{hotelName} - Bot Shop</title>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/common.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs2.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/visual.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/common.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/fullcontent.js"></script>
        
        <script type="text/javascript">
            document.habboLoggedIn = true;
            var habboName = "{username}";
            var habboId = {userid};
            var habboReqPath = "";
            var habboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var habboPartner = "";
            var habboDefaultClientPopupUrl = "{url}/client";
            window.name = "habboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
        <script type="text/javascript">
            function validateForm()
            {
            var x=document.forms["form"]["name"].value;
            if (x==null || x=="")
              {
              alert("All fields must be filled out");
              return false;
              }
            }
        </script>
        
        <!--[if IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie8.css" type="text/css">
        <![endif]-->
        <!--[if lt IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie.css" type="text/css" />
        <![endif]-->
        <!--[if lt IE 7]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie6.css" type="text/css" />
            <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/pngfix.js"></script>
            <script type="text/javascript">
                try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
            </script>
            <style type="text/css">
                body { behavior: url({url}/app/tpl/skins/Habbo/js/csshover.htc); }
            </style>
        <![endif]-->
    </head>
    
    <body id="home">
    
        <div id="overlay"></div>
        <div id="header-container">
            <div id="header" class="clearfix">
                <h1><a href="{url}/"></a></h1>
                <div id="subnavi">
                    <div id="subnavi-user">
                    </div>
                    <div id="subnavi-search">
                        <div id="subnavi-search-upper">
                            <ul id="subnavi-search-links">
                                <li><a href="{url}/logout" style="color:#000">Sign Out</a></li>
                            </ul>
                        </div>
                    </div>
                    <div id="to-hotel">
                        <a href="{url}/client" class="new-button green-button" target="eac955c8dbc88172421193892a3e98fc7402021a" onclick="HabboClient.openOrFocus(this); return false;"><b>Enter {hotelName} Hotel</b><i></i></a>
                    </div>
                </div>
                <ul id="navi">
                    <li class="metab"><a href="{url}/me">{username}</a><span></span></li>
                    <li><a href="{url}/community">Community</a><span></span></li>
                    <li class="selected"><a href="{url}/shop">Shop</a><span></span></li>
                    {housekeeping}
                </ul>
                <div id="habbos-online">
                    <div class="rounded"><span>
                        <?php
                            $random = rand(4, 12); 
                            $online = "{online}";
                            $addition = $online + $random;
                                                           
                            echo $addition;
                        ?> members online</span>
                    </div>
                </div>
            </div>
        </div>
        <div id="content-container">
            <div id="navi2-container" class="pngbg">
                <div id="navi2" class="pngbg clearfix">
                    <ul>
                        <li class=""><a href="{url}/credits">Credits</li>
                        <li><a href="{url}/badges">Badges</a><span></span></li> 
                        <li class="selected last">Bots<span></span></li> 
                    </ul>
                </div>
            </div>
                    
            <div id="container">
                <div id="content" style="position: relative" class="clearfix">
                    <div id="column1" class="column">
                        <div class="habblet-container ">
                            <div class="cbb clearfix blue ">
                                <h2 class="title">Bot Shop</h2>
                                <div style="padding:5px">
                                    <div class="box-content">
                                        <?php
                                        //Checks if user has more than x number of bots, disables bot shop if true
                                        $hasBot = mysql_fetch_row(mysql_query('SELECT count(*) FROM bots WHERE owner = "'.$_SESSION['user']['username'].'"'));
                                        if(($hasBot[0]) < $maxBots)
                                            {
                                        ?>
                                                <?php
                                                //Check if user has enough Credits
                                                $credits = mysql_fetch_array(mysql_query('SELECT credits FROM users WHERE username = "'.$_SESSION['user']['username'].'"'));
                                                if($credits['credits'] >= $botPrice)
                                                {
                                                ?>
                                                    <?php
                                                    if (isset($_POST["submit"]))
                                                    {
                                                        //Filter user entered values
                                                        if(is_numeric ("$_POST[id]"))
                                                        {
                                                            $id = mysql_real_escape_string($_POST[id]);
                                                        }
                                                        else
                                                        {
                                                            echo "No cake for you! (id)<br>";
                                                            $id = "No cake for you!";
                                                        }
                                                        
                                                        $userRoomID = mysql_query('SELECT id FROM rooms WHERE owner = "'.$_SESSION['user']['username'].'"');
                                                        if(is_numeric ("$_POST[room_id]") && "$_POST[room_id]" == $userRoomID)
                                                        {
                                                            $room_id = mysql_real_escape_string($_POST[room_id]);
                                                        }
                                                        else
                                                        {
                                                          echo "No cake for you! (room_id)<br>";
                                                          $room_id = "No cake for you!";
                                                        }
                                                        
                                                        if("$_POST[name]" != "")
                                                        {
                                                            $room_id = mysql_real_escape_string($_POST[name]);
                                                        }
                                                        else
                                                        {
                                                          echo "Field bot name is empty.<br>";
                                                          $name = "No cake for you!";
                                                        }
                                                        
                                                        if("$_POST[motto]" != "")
                                                        {
                                                            $room_id = mysql_real_escape_string($_POST[motto]);
                                                        }
                                                        else
                                                        {
                                                          echo "Field motto is empty.<br>";
                                                          $motto = "No cake for you!";
                                                        }


                                                        if(is_numeric ("$_POST[x]"))
                                                        {
                                                            $x = mysql_real_escape_string($_POST[x]);
                                                        }
                                                        else
                                                        {
                                                          echo "No cake for you! (x)<br>";
                                                          $x = "No cake for you!";
                                                        }
                                                        
                                                        if(is_numeric ("$_POST[y]"))
                                                        {
                                                            $y = mysql_real_escape_string($_POST[y]);
                                                        }
                                                        else
                                                        {
                                                          echo "No cake for you! (y)<br>";
                                                          $y = "No cake for you!";
                                                        }
                                                        
                                                        if(is_numeric ("$_POST[z]"))
                                                        {
                                                            $z = mysql_real_escape_string($_POST[z]);
                                                        }
                                                        else
                                                        {
                                                          echo "No cake for you! (z)<br>";
                                                          $z = "No cake for you!";
                                                        }
                                                        
                                                        if(is_numeric ("$_POST[rotation]"))
                                                        {
                                                            $rotation = mysql_real_escape_string($_POST[rotation]);
                                                        }
                                                        else
                                                        {
                                                          echo "No cake for you! (rotation)<br>";
                                                          $rotation = "No cake for you!";
                                                        }
                                                        
                                                        //Insert filtered values into database
                                                        if ($id=="No cake for you!" || $room_id=="No cake for you!" || $name=="No cake for you!" || $motto=="No cake for you!" || $x=="No cake for you!" || $y=="No cake for you!" || $z=="No cake for you!" || $rotation=="No cake for you!")
                                                        {
                                                            if ($name=="No cake for you!" || $motto=="No cake for you!")
                                                            {
                                                                echo "";
                                                            }
                                                            else
                                                            {
                                                                echo "yo mama so fat";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            //Just to play safe
                                                            $id = mysql_real_escape_string($_POST[id]);
                                                            $owner = mysql_real_escape_string($_POST[owner]);
                                                            $room_id = mysql_real_escape_string($_POST[room_id]);
                                                            $name = mysql_real_escape_string($_POST[name]);
                                                            $motto = mysql_real_escape_string($_POST[motto]);
                                                            $look = mysql_real_escape_string($_POST[look]);
                                                            $x = mysql_real_escape_string($_POST[x]);
                                                            $y = mysql_real_escape_string($_POST[y]);
                                                            $z = mysql_real_escape_string($_POST[z]);
                                                            $rotation = mysql_real_escape_string($_POST[rotation]);
                                                            $walk_mode = mysql_real_escape_string($_POST[walk_mode]);
                                                            
                                                            //Get and update user Credits
                                                            $userID = mysql_fetch_array(mysql_query('SELECT id FROM users WHERE username = "'.$_SESSION['user']['username'].'"'));
                                                            MUS("updatecredits", $userID['id']);
                                                            MUS("update_bots");
                                                            
                                                            $updateCredits = (mysql_query("UPDATE users SET credits=credits-$botPrice
                                                            WHERE username= '".$owner."'")) or die(mysql_error());
                                                            
                                                            $makeBot = mysql_query("INSERT INTO bots (id, room_id, owner, name, motto, look , x , y , z , rotation , walk_mode) VALUES 
                                                            ('".$id."','".$room_id."','".$owner."','".$name."','".$motto."','".$look."','".$x."','".$y."','".$z."','".$rotation."','".$walk_mode."')") or die(mysql_error());
                                                            echo "<h2>Bot succesfully added! (";
                                                            echo $userID['id'];
                                                            echo ")</h2>";
                                                            
                                                            unset($GLOBALS['submit']);
                                                            unset($_post['submit']);
                                                            $reload = $_SERVER['REQUEST_URI'];
                                                        }
                                                    }
                                                    {
                                                    ?>
                                                        <form name="submit" method="post">
                                                        <h3>Room:</h3>
                                                        <p>Simply select the room to place your bot.<p>
                                                        <select name="room_id">
                                                        <?php
                                                        $getRoomInfo = mysql_query('SELECT id, caption FROM rooms WHERE owner = "'.$_SESSION['user']['username'].'"');
                                                        
                                                        while($roomInfo = mysql_fetch_array($getRoomInfo)){
                                                            echo '<option value="';
                                                            echo $roomInfo['id'];
                                                            echo '">';
                                                            echo $roomInfo['id'];
                                                            echo ' - ';
                                                            echo $roomInfo['caption'];
                                                            echo '<br /></option>';
                                                        }
                                                        ?>
                                                        </select><br /><br />
                                                        
                                                        <h3>Bot name:</h3>
                                                        <p>Self-explanatory.</p>
                                                        <input type="text" name="name" /><br /><br />
                                                        
                                                        <h3>Bot motto:</h3>
                                                        <p>Will be seen when other Teddy's click on your bot in the hotel.</p>
                                                        <input type="text" name="motto" /><br /><br />


                                                        <h3>Coordinates:</h3>
                                                        <p>Say :coords in the hotel for coordinates of where you are standing at that time.</p>
                                                        X: <input type="number" name="x" value="0" /><br />
                                                        Y: <input type="number" name="y" value="0" /><br />
                                                        Z: <input type="number" name="z" value="0" /><br />
                                                        Rotation: <input type="number" name="rotation" value="0" /><br /><br />
                                                                    
                                                        <h3>Walk mode:</h3>
                                                        <p>There are 3 types of walkmode: stand, freeroam and specified_range; pretty self-explanatory.</p>
                                                        <select name="walk_mode">
                                                            <option>stand</option>
                                                            <option>freeroam</option>
                                                            <option>specified_range</option>
                                                        </select><br /><br />
                                                        
                                                        <table align="center" >
                                                            <br />
                                                            <tr>
                                                                <td>
                                                                <?php
                                                                $gender = "m";
                                                                $query  = "SELECT * FROM cms_registration_figures WHERE gender = '$gender' LIMIT 6";
                                                                $result = mysql_query($query);
                                                                while($row = mysql_fetch_array($result))
                                                                {
                                                                    $avatar = explode('.', $row['figure'], 2);
                                                                    echo '<img src="http://habbo.com/habbo-imaging/avatarimage?figure='.$row['figure'] .'&direction=2&head_direction=2&gesture=sml&action=sit&cache={date}" width="40" height="65"/>';
                                                                    echo '<input type="radio" name="look" checked="checked" value="'.$row['figure'].' ">';
                                                                }
                                                                ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                <?php
                                                                $gender = "m";
                                                                $query  = "SELECT * FROM cms_registration_figures WHERE gender = '$gender' LIMIT 6,6";
                                                                $result = mysql_query($query);
                                                                while($row = mysql_fetch_array($result))
                                                                {
                                                                    $avatar = explode('.', $row['figure'], 2);
                                                                    echo '<img src="http://habbo.com/habbo-imaging/avatarimage?figure='.$row['figure'] .'&direction=2&head_direction=2&gesture=sml&action=sit&cache={date}" width="40" height="65"/>';
                                                                    echo '<input type="radio" name="look"  value="'.$row['figure'].' ">';
                                                                }
                                                                ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                <?php
                                                                $gender = "f";
                                                                $query  = "SELECT * FROM cms_registration_figures WHERE gender = '$gender' LIMIT 6";
                                                                $result = mysql_query($query);


                                                                while($row = mysql_fetch_array($result))
                                                                {
                                                                    $avatar = explode('.', $row['figure'], 2);
                                                                    echo '<img src="http://habbo.com/habbo-imaging/avatarimage?figure='.$row['figure'] .'&direction=2&head_direction=2&gesture=sml&action=sit&cache={date}" width="40" height="65"/>';
                                                                    echo '<input type="radio" name="look"  value="'.$row['figure'].' ">';
                                                                }
                                                                ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                <?php
                                                                $gender = "f";
                                                                $query  = "SELECT * FROM cms_registration_figures WHERE gender = '$gender' LIMIT 6,6";
                                                                $result = mysql_query($query);


                                                                while($row = mysql_fetch_array($result))
                                                                {
                                                                    $avatar = explode('.', $row['figure'], 2);


                                                                    echo '<img src="http://habbo.com/habbo-imaging/avatarimage?figure='.$row['figure'] .'&direction=2&head_direction=2&gesture=sml&action=sit&cache={date}" width="40" height="65"/>';
                                                                    echo '<input type="radio" name="look"  value="'.$row['figure'].' ">';
                                                                }
                                                                ?>
                                                                </td>
                                                            </tr>
                                                        </table>


                                                    <input type="hidden" name="id" value="<?php
                                                    //Give bot a unique ID
                                                    $last_ID = mysql_fetch_row(mysql_query("SELECT count(1) from bots"));
                                                    echo $last_ID[0] + 1;;
                                                    ?>" readonly /><br /><br />
                                                    
                                                    <input type="hidden" name="owner" value={username}>
                                                    <br><input type="submit" name="submit" value="Make bot" class="submit" style="float:right">
                                                    </form>
                                                    <?php
                                                    }
                                                }
                                                else
                                                {
                                                    echo "<h2>Not enough Credits</h2>";
                                                    echo "You don't have enough Credits for this.<br>";
                                                }
                                            }
                                            else
                                            {
                                                echo 'Maximum bot limit reached. Please delete one of yours bots to continue.';
                                            ?>
                                                <?php
                                                    if (isset($_POST["delete"]))
                                                    {
                                                        $deleteBot = mysql_query("DELETE FROM bots WHERE id = '$_POST[delete]'") or die(mysql_error());
                                                        echo "<h2>Bot deleted</h2>";
                                                        echo '<a href="{url}/bots">Buy another bot</a>';
                                                        
                                                        unset($GLOBALS['delete']);
                                                        unset($_post['delete']);
                                                        $reload = $_SERVER['REQUEST_URI'];
                                                    }
                                                    else {
                                                    ?>                                                    
                                                            <br><br>Your bots: <br><br>
                                                            <form method="post">
                                                            <?php
                                                            $getBot = mysql_query('SELECT * FROM bots WHERE owner = "'.$_SESSION['user']['username'].'"');


                                                            while($row = mysql_fetch_array($getBot)){
                                                            ?>
                                                            <input type="radio" name="delete"  value="<?php echo $row['id'];?>">
                                                            <?php
                                                            echo "Room ID: ".$row['room_id']. " - "." Bot Name: ".$row['name']. "<br>";
                                                            }
                                                            ?>
                                                            <br>
                                                            <input type="submit" value="Delete bot" class="submit" style="float:right">
                                                            </form>
                                            <?php     
                                                        }
                                            }
                                            ?>
                                        <script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div id="column2" class="column">
                        <div class="habblet-container ">
                            <div class="cbb clearfix blue ">
                                <h2 class="title">All About Bots</h2>
                                <div style="padding:5px">    
                                    You'll find bots in various places in {hotelName}; most are residents in some of the public rooms. But now you can get your very own bot for your room - for only <?php echo $botPrice; ?> Credits!
                                    <br><br>Please note that this feature is currently in testing stage.
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        <script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
        <script type="text/javascript">
            HabboView.run();
        </script>


        <!--[if lt IE 7]>
            <script type="text/javascript">
                Pngfix.doPngImageFix();
            </script>
        <![endif]-->
        
        <div id="footer" >
        </div>
    
    </body>
</html>
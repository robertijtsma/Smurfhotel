<?php
/*---------------------------------------------------+
| HabboCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked
+----------------------------------------------------+
| HabboCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on HabboCMS for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line HabboCMS may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	Wicked(Adam) at  habview dot co dot uk

	Thanks in advance.

*/

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>{hotelName} - Register</title>
        
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/visual.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/common.js"></script>
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/common.css" type="text/css">
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/embedregistration.css" type="text/css">
        
        <script type="text/javascript">
            document.habboLoggedIn = true;
            var habboName = null;
            var habboId = null;
            var habboReqPath = "";
            var habboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var habboPartner = "";
            var habboDefaultClientPopupUrl = "{url}/client";
            window.name = "habboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "client";
                HabboClient.maximizeWindow = true;
            }
        </script>
        
        <style type="text/css">
            input[type="submit"], input[type="button"] {
                background: url('{url}/app/tpl/skins/Habbo/images/reg_btn.png') top;
                font: bold 13px arial,sans-serif;
                line-height: 25px;
                color: black;
                height: 25px;
                width: 99px;
                border: 0;
            }
            input[type="submit"]:hover, input[type="button"]:hover {
                background-position: bottom;
                cursor: pointer;
            }
        </style>
        
        <!--[if IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie8.css" type="text/css">
        <![endif]-->
        <!--[if lt IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie.css" type="text/css" />
        <![endif]-->
        <!--[if lt IE 7]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie6.css" type="text/css" />
            <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/pngfix.js"></script>
            <script type="text/javascript">
                try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
            </script>
            <style type="text/css">
                body { behavior: url({url}/app/tpl/skins/Habbo/js/csshover.htc); }
            </style>
        <![endif]-->
    </head>
    
    <body>
    
        <div id="overlay"></div> 
        <div id="container" class="phase-0" style="margin-top: 10px;"> 
            <div class="register-container clearfix"> 
                <div class="register-header">Register at {hotelName} Hotel</div> 
                <div id="register-content"> 
                    <div id="subheader">Fill out the form below to register here!</div>{hotelname} Hotel is a virtual world for players 13 years and older, where you can create your very own Habbo character and design your room the way you like. You'll meet new friends, chat, organize parties, look after virtual pets, create and play games and complete quests.Make accaunt below and the fun begins!</div> 
                    <div class="register-container-bottom-end register-content clearfix"> 
                        <div id="auth-providers" class="auth-providers"> 
                            <ul> 
                                <li class="facebook"><a href="#" class="provider"></a></li> 
                                <li class="twitter"><a href="#" class="provider"></a></li> 
                                <li class="google"><a href="#" class="provider"></a></li> 
                                <li class="hyves"><a href="#" class="provider"></a></li> 
                                <li class="myspace"><a href="#" class="provider"></a></li> 
                                <li class="windowslive"><a href="#" class="provider"></a></li> 
                                <li class="yahoo"><a href="#" class="provider"></a></li> 
                            </ul> 
                        </div>
						
                        <div id="register-page" style="clear: left" class="phase-0 clearfix"> 
                            <div class="phase-0"> 
                                <form method="post" id="phase-0-form"> 
                                    <div id="error-messages-container"><?php if(isset($template->form->error)) { echo '<div class="error-messages-holder"><ul><li><p class="error-message">'.$template->form->error.'</p></li></ul></div>'; } ?></div> 
                                    <div id="name-field-container"> 
                                        <div class="field field-habbo-name"> 
                                            <label for="habbo-name"><b>Username:</b></label><p>Usernames such as(-MOD,-STAFF,-ADMIN,etc)will be banned.  
                                            <input type="text" id="habbo-name" size="35" value="<?php echo $template->form->reg_username; ?>" name="reg_username" class="text-field" maxlength="32"> 
                                        </div> 
                                    </div> 
                                    <div class="field field-password"> 
                                        <label for="password"><b>Password:</b></label><p>Choose a password that is at least 6 characters long.Your password is the password you use to login to the main website. 
                                        <input type="password" id="password" size="35" name="reg_password" value="" class="password-field" maxlength="32"> 
                                    </div>
                                    <div class="field field-password2"> 
                                        <label for="password2"><b>Confirm Password:</b></label><p>Re-type your password to make sure you got it right. 
                                        <input type="password" id="password2" size="35" name="reg_rep_password" value="" class="password-field" maxlength="32"> 
                                    </div> 
                                    <div class="field field-email"> 
                                        <label for="email"><b>Email Address:</b></label>
                                            <p>Your email address is what you may need to reset your password incase you forget it. 
                                        <input type="text" id="email" size="35" name="reg_email" value="<?php echo $template->form->reg_email; ?>" class="text-field" maxlength="48"> </p>
                                    </div> 
                                   
																<div class="field field-birthday"> 



			  <label><b>Date of Birth</b></label> 



			  <span id="bday-selects">  



<select name="bean.day" id="bean_day" class="dateselector"><option value="">Day</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option></select> <select name="bean.month" id="bean_month" class="dateselector"><option value="">Month</option><option value="1">January</option><option value="2">February</option><option value="3">March</option><option value="4">April</option><option value="5">May</option><option value="6">June</option><option value="7">July</option><option value="8">August</option><option value="9">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option></select> <select name="bean.year" id="bean_year" class="dateselector"><option value="">Year</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><option value="2007">2007</option><option value="2006">2006</option><option value="2005">2005</option><option value="2004">2004</option><option value="2003">2003</option><option value="2002">2002</option><option value="2001">2001</option><option value="2000">2000</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option><option value="1939">1939</option><option value="1938">1938</option><option value="1937">1937</option><option value="1936">1936</option><option value="1935">1935</option><option value="1934">1934</option><option value="1933">1933</option><option value="1932">1932</option><option value="1931">1931</option><option value="1930">1930</option><option value="1929">1929</option><option value="1928">1928</option><option value="1927">1927</option><option value="1926">1926</option><option value="1925">1925</option><option value="1924">1924</option><option value="1923">1923</option><option value="1922">1922</option><option value="1921">1921</option><option value="1920">1920</option><option value="1919">1919</option><option value="1918">1918</option><option value="1917">1917</option><option value="1916">1916</option><option value="1915">1915</option><option value="1914">1914</option><option value="1913">1913</option><option value="1912">1912</option><option value="1911">1911</option><option value="1910">1910</option><option value="1909">1909</option><option value="1908">1908</option><option value="1907">1907</option><option value="1906">1906</option><option value="1905">1905</option><option value="1904">1904</option><option value="1903">1903</option><option value="1902">1902</option><option value="1901">1901</option><option value="1900">1900</option></select> 			  </span>  



			  <p class="help">Birthday is needed for security purposes.</p>			  



			</div> 



                                    </div> 
                                    <div class="field field-seckey">
                                        <label for="seckey"><b>Security Key:</b></label><p>Security key is really important in regaining password or accaunt process,make sure you don't forget it.
                                        <input type="password" id="seckey" size="35" name="reg_seckey" value="" class="text-field" maxlength="4">
										<input tabindex="5" type="checkbox" name="_login_remember_me" id="credentials-remember-me">
            <label for="credentials-remember-me" class="sub-label">I agree to the Terms of Use listed below.<p><a href="./TOS" target="_self">Habview Hote Terms of Use</a>
                                    </div>
                                    <input type="submit" value="Register" name="register">
                                    <input type="button" value="Cancel" onclick="location.href='{url}/'" style="float:right;margin-right:12px;">
                                </form> 
                            </div> 
                        </div> 
                    </div> 
                </div> 
                <div class="register-container-bottom"></div> 
                <!--[if lt IE 7]>
                    <script type="text/javascript">
                        Pngfix.doPngImageFix();
                    </script>
                <![endif]--> 
            </div>
        </div>
        <script type="text/javascript"> 
            HabboView.run();
        </script> 
    
    </body>
</html>
<footer>
    <div id="age-recommendation"></div>

    <div id="footer">
	<p><a href="index.php" target="_self">Homepage</a> | <a href="./TOS" target="_self">Terms of Service</a> | <a href="./privacy" target="_self">Privacy Policy</a>| <a href="./Norefundpolicy" target="_self">Refund Policy</a> |</a><a href="./dip" target="_self">Disclaimer</a> |
	<?php /*@@* DO NOT EDIT OR REMOVE THE LINE BELOW WHATSOEVER! *@@ You ARE allowed to remove the link to the HoloCMS site though*/ ?>
	<p>Powered by <a href="http://www.holocms.com/">HabboCMS</a> &copy 2013 Kredits to Kryptos,Meth0d & Parts by Yifan, sisija<br><?php echo $locale['copyright_Habbo']; ?><p>&copy; Copyright 2012-2013 <a href="{url}" target="_New"><b>Habview Hotel�</b></a>. All rights reserved.<br>

	<?php /*@@* DO NOT EDIT OR REMOVE THE LINE ABOVE WHATSOEVER! *@@ You ARE allowed to remove the link to the HoloCMS site though*/ ?> 

 </body>
</html>
</div></div></div>
<div id="footer">

<p>Powered by Habbocms.All rights reserved
</a></div>
    </body>




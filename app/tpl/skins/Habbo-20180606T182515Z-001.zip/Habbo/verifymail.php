<?php 
/*================================================================+\
|| # © 2012 Robby Duke. All rights reserved. This material may not be reproduced, displayed, modified or distributed without the express prior written permission of the copyright holder. 
|| # For permission, contact Robby@fallout-hotel.com
\+================================================================*/

$a = mysql_query("SELECT * FROM users WHERE id = ". $_SESSION['user']['id']) or die(mysql_error());
$b = mysql_fetch_array($a);
$c = mysql_query("SELECT * FROM cms_mail_sessions WHERE active = 1 AND uid = ". $_SESSION['user']['id']) or die(mysql_error());
$d = mysql_num_rows($c);
$e = mysql_fetch_array($c);

if($b['mail_verified'] == 1) {
	echo '
	<div id="disconnectedbox"> <a href="index.php"><img src="app/tpl/skins/Mango/images/logo.png" border="0" id="logo"/></a>
	<span id="stats">{online} Users Online!</span>
	<div id="clear"></div>
	<hr />
	<p><br />
	<center>
  	It appears you\'re email address is already verfied? <a href="/me">Click Here</a> to go back to the home page! </p><br />
  	</center>
  	<hr />
  	<center>Powered by <b></b><a href="http://devbest.com/threads/0-9-revcms-php-mysql.8746/">RevCMS</a></b> coded by <b>Kryptos</b> | Design by <b>dannyy94</b> | Copyright &copy
  	{hotelName} Hotel</center>
	</div><br />
	';
}

if($b['mail_verified'] == 0 && $d < 1) {
	function generateRandomString($length = 50) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
	}
	
	$sessionKey = generateRandomString();
	$key = $sessionKey;
	mysql_query("INSERT INTO cms_mail_sessions (session, uid, timestamp) VALUES ('$key', '". $_SESSION['user']['id'] ."', '". time() ."')") or die(mysql_error());	
	$to      = $b['mail'];
	$subject = 'Verify Your Hebbo Email';
	$message = 'Copy and Paste this link to receive your badge and 2500 credits - http://hebbo.info/index.php?url=verifymail&key='. $key;
	$headers = 'From: noreply@hebbohotel2013@gmail.com' . "\r\n" .
    		   'Reply-To: noreply@fallout-hotel.com' . "\r\n" .
    		   'X-Mailer: PHP/' . phpversion();
	mail($to, $subject, $message, $headers);
	echo '
	<div id="disconnectedbox"> <a href="index.php"><img src="app/tpl/skins/habbo/images/logo.gif" border="0" id="logo"/></a>
	<span id="stats">{online} Users Online!</span>
	<div id="clear"></div>
	<hr />
	<p><br />
	<center>
  	An email has been disbatched! After you click the link you\'ll be redirected to a verfication page, you will then receive your credits and badge!</p><br />
  	</center>
  	<hr />
  	<center>Powered by <b></b><a href="http://devbest.com/threads/0-9-revcms-php-mysql.8746/">RevCMS</a></b> coded by <b>Kryptos</b> | Design by <b>dannyy94</b> | Copyright &copy
  	{hotelName} Hotel</center>
	</div><br />
	';
}
if($_GET['key'] == $e['session'] && $b['mail_verified'] == 0 && isset($_GET['key'])) {
	$f = mysql_query("UPDATE users SET credits = credits + 2500, mail_verified = 1 WHERE id = '". $_SESSION['user']['id'] ."'") or die(mysql_error());
	$g = mysql_query("UPDATE cms_mail_sessions SET active = '0' WHERE uid = '". $_SESSION['user']['id'] ."'") or die(mysql_error());
	$h = mysql_query("INSERT INTO user_badges (user_id, badge_id) VALUES ('". $_SESSION['user']['id'] ."', 'ACH_EmailVerification1')") or die(mysql_error());
	function sendMUS($header, $data){
        $ip = "64.31.15.19";
        $port = 30001;
        $musData = $header . chr(1) . $data;
        $sock = @socket_create(AF_INET, SOCK_STREAM, getprotobyname('tcp'));
        @socket_connect($sock, $ip, $port);
        @socket_send($sock, $musData, strlen($musData), MSG_DONTROUTE);
        @socket_close($sock);
	}
	sendMUS('updatecredits', $_SESSION['user']['id']);
	echo '
	<div id="disconnectedbox"> <a href="index.php"><img src="app/tpl/skins/Mango/images/logo.png" border="0" id="logo"/></a>
	<span id="stats">{online} Users Online!</span>
	<div id="clear"></div>
	<hr />
	<p><br />
	<center>
  	Thanks for verifying you\'re email! You\'re credit balance has been updated, and a badge has been given to you to show off to your friends! Reload the hotel to get your badge!</p><br />
  	</center>
  	<hr />
  	<center>Powered by <b></b><a href="http://devbest.com/threads/0-9-revcms-php-mysql.8746/">RevCMS</a></b> coded by <b>Kryptos</b> | Design by <b>dannyy94</b> | Copyright &copy
  	{hotelName} Hotel</center>
	</div><br />
	';
}
?>
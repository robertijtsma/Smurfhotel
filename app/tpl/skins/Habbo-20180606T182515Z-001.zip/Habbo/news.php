<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - News </title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>
	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "ac96433fa782a85a4d9d1724e256d10df092be19";
		HabboClient.maximizeWindow = true;
	}


	</script>

	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
	
	<style type="text/css">
	input[type="text"], input[type="password"] {
		background-color: #F1F1F1;
		border: 1px solid #999999;
		width: 175px;
		padding: 5px;
		font-family: verdana;
		font-size: 10px;
		color: #666666;
	}
	
	input[type="submit"] {
		background-color: #F1F1F1;
		border: 1px solid #999999;
		padding: 5px;
		font-family: verdana;
		font-size: 10px;
		color: #666666;
	}
	
	textarea {
		background-color: #F1F1F1;
		border: 1px solid #999999;
		padding: 5px;
		width: 517px;
		height: 70px;
		font-family: verdana;
		font-size: 10px;
		color: #666666;
	}
	
	select {
		background-color: #F1F1F1;
		border: 1px solid #999999;
		padding: 5px;
		font-family: verdana;
		font-size: 10px;
		color: #666666;
	}
	</style>
</head>
<?php
if (isset($_GET['delete']) && $_GET['delete'] != null) {
	if ($_SESSION['user']['rank'] >= 5) {

		$getRank = mysql_fetch_array(mysql_query("SELECT `rank` FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
		if ($getRank >= 5) {
			mysql_query("DELETE FROM `site_news_comments` WHERE `id` = '".filter($_GET['delete'])."'");
			//mysql_query("INSERT INTO `stafflogs` (`type`,`userid`,`action`,`timestamp`) VALUES ('CMS','".$_SESSION['user']['id']."','Deleted a news comment','".time()."')");
		}
	}
} else if (isset($_GET['ban']) && $_GET['ban'] != null) {
	if ($_SESSION['user']['rank'] >= 5) {

		$getRank = mysql_fetch_array(mysql_query("SELECT `rank` FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
		if ($getRank >= 5) { 
			$getComments = mysql_query("SELECT * FROM `site_news_comments` WHERE `id` = '".filter($_GET['ban'])."'")  or die(mysql_error());
			if (mysql_num_rows($getComments) > 0) {
				$commentData = mysql_fetch_array($getComments);
				mysql_query("DELETE FROM `site_news_comments` WHERE `userid` = '".$commentData['userid']."'") or die(mysql_error());
				mysql_query("UPDATE `users` SET `cms_comment_banned` = '1' WHERE `id` = '".$commentData['userid']."'");
			}
			//mysql_query("INSERT INTO `stafflogs` (`type`,`userid`,`action`,`timestamp`) VALUES ('CMS','".$_SESSION['user']['id']."','Banned a user from posting news comments.','Banned user ID: ('".filter($_GET['ban'])."')','".time()."')");
		}
	}
}
?>
<body id="news" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 2;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 2;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
		<div id="column1" class="column">
			<div class="habblet-container ">		
				<div class="cbb clearfix default ">
					<h2 class="title">News</h2>
					<div id="article-archive">{newslist}</div>
				</div>
			</div>
			<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
		</div>
		
		<div id="column2" class="column">
			<div class="habblet-container ">		
				<div class="cbb clearfix notitle ">
					<div id="article-wrapper">
						<h2>{newsTitle}</h2>
						<div class="article-meta">{newsDate}</div>
						<p class="summary">{newsSummary}</p>

						<div class="article-body">
							<p>{newsContent}</p>	
						</div>
					</div>
				</div>
			</div>
			<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			
			<?php
			$checkBan = mysql_query("SELECT `cms_comment_banned` FROM `users` WHERE `cms_comment_banned` = '1' AND `id` = '".$_SESSION['user']['id']."'");
			if (mysql_num_rows($checkBan) == 1)
			{ ?>
			<div class="habblet-container ">		
				<div class="cbb clearfix default ">
					<h2 class="title">Banned from posting or seeing news comments!</h2>
					<div style="padding: 5px;">
						<p align="center">You're banned from posting news comments, due to this you cannot post or see comments.</p>
					</div>
				</div>
			</div>
			<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			<?php
			}
			else {
				$getArticle = mysql_query("SELECT * FROM `site_news` WHERE `id` = '".filter($_GET['id'])."'") or die(mysql_error());
				if (mysql_num_rows($getArticle) > 0)
				{
					$articleInfo = mysql_fetch_array($getArticle) or die(mysql_error());
					if(isset($_POST['post_comment']) && $_SESSION['user']['id'] != null)
					{
						$checkBan = mysql_query("SELECT `cms_comment_banned` FROM `users` WHERE `cms_comment_banned` = '1' AND `id` = '".$_SESSION['user']['id']."'");
						if (mysql_num_rows($checkBan) == 0)
						{
							if($_POST['comment'] == NULL)
								$errorMessage = 'You have left a field empty.';
							else
							{
								$checkInfo = mysql_query("SELECT * FROM `site_news_comments` WHERE `article` = '".filter($_GET['id'])."' ORDER BY `id` DESC LIMIT 1") or die(mysql_error());
								$newsInfo = mysql_fetch_array($checkInfo);
								if($newsInfo['userid'] == $_SESSION['user']['id'])
									$errorMessage = 'Hey! The last comment was from you, let somebody else comment first!';
								else
								{
									mysql_query("INSERT INTO `site_news_comments` (`article`, `userid`, `comment`, `posted_on`) VALUES ('".filter($_GET['id'])."', '".$_SESSION['user']['id']."', '".filter($_POST['comment'])."', '".date("M j, Y g:i A")."')") or die(mysql_error());
									$successMessage = 'You have successfully left a comment.';
								}
							}
						}
					}
				?>
				<div class="habblet-container ">		
					<div class="cbb clearfix notitle ">
						<div id="article-wrapper">
							<h2>Post Comment</h2>
							<div class="article-meta"></div>
							<div style="padding:5px">
								<?php if (isset($errorMessage)) { ?>
								<div class="action-error flash-message">
									<div class="rounded">
										<div class="rounded-done"><?php echo $errorMessage; ?></div>
									</div>
								</div>
								<?php } else if (isset($successMessage)) { ?>
								<div class="action-confirmation flash-message">
									<div class="rounded">
										<div class="rounded-done"><?php echo $successMessage; ?></div>
									</div>
								</div>
								<?php } ?>

								<form action="" method="post">
									<textarea name="comment" maxlength="500"></textarea><br /><br />
									<input type="submit" name="post_comment" value="Post Comment" />
								</form>
							</div>
						</div>
					</div>
				</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>

				<div class="habblet-container ">		
				<div class="cbb clearfix notitle ">
				<div id="article-wrapper">
				<?php $getComments = mysql_query("SELECT * FROM `site_news_comments` WHERE `article` = '".filter($_GET['id'])."' ORDER BY `id` DESC"); ?>
				<h2>Comments (<?php echo mysql_num_rows($getComments); ?>)</h2>
				<div class="article-meta"></div>
				<div style="padding:5px">
				<?php
				if(mysql_num_rows($getComments) == 0)
					echo 'Sorry, but no one has posted a comment yet.';									
				else
				{
				echo '<table width="528px">';
				while($commentInfo = mysql_fetch_array($getComments))
				{
				$userInfo = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$commentInfo['userid']."'"));

				echo '
				<tr>
				<td width="90px" valign="top">
				<div style="height: 80px; width: 50px; float: left; overflow: hidden;"><img src="{habboImagerPath}'.$userInfo['look'].'"></div>';
				if($userInfo['rank'] > 5)
					echo '<div style="position: absolute; z-index:1"><img src="{badgeImagePath}/ADM.gif"></div>';

				else if($userInfo['vip'] == 1 || $userInfo['rank'] == 2)
				echo '<div style="position: absolute; z-index:1"><img src="{badgeImagePath}/VIP.gif"></div>';

				if ($_SESSION['user']['rank'] >= 5)
					echo '<br/><br/><br/><br/><br/><br/><br/><a href="{url}/news/'.$_GET['id'].'/delete/'.$commentInfo['id'].'">Delete</a> | <a href="{url}/news/'.$_GET['id'].'/ban/'.$commentInfo['id'].'">Ban</a>';
				echo '</td>

				<td width="427px" valign="top">
				<strong>RE: {newsTitle}</strong><br /><br />'.$commentInfo['comment'].'
				</td>
				</tr>
				<tr>
				<td width="90px" valign="top">
				</td>
				<td width="427px" align="right">';
				if ($_SESSION['user']['rank'] >= 5)
					echo '<div align="right" style="margin-top: -16px;"><i>Posted by <strong><a href="#">'.$userInfo['username'].'</a></strong> on '.$commentInfo['posted_on'].'</i></div>';
				else
					echo '<div align="right"><i>Posted by <strong><a href="#">'.$userInfo['username'].'</a></strong> on '.$commentInfo['posted_on'].'</i></div>';
				echo '<br /><br /><div style="width:125%; height:1px; background-color:#ccc; margin-top:-17px;"></div>

				</td>

				</tr>';
				}
				echo '</table>';
				}
				?>
				</div>
				</div>
				</div>
	</div>
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
<?php } }?>
		
		</div>

<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>

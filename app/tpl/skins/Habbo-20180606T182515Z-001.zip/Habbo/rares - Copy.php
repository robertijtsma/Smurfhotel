<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - Store - Rares</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>
	
	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
	
	<style type="text/css">
		hr {background-color:#CCC;border:0;height:1px;margin:10px 0;}
	</style>
	
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 4;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 2;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
		<div id="column1" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix orange ">  
					<h2 class="title"><span style="float: left;">Why buy a rare?</span></h2>
					<div style="padding: 5px" align='left'><p><img src="{url}/app/tpl/skins/Habbo/images/catalogue/rares.gif" align="right" vspace="5" hspace="5"
						<p><img src="{url}/app/tpl/skins/Habbo/images/trito_friends1.png" align="right" vspace="5" hspace="5"
							
							
							<b>
							Thanks for showing an interest in purchasing a {hotelname} Rare packages, we currently have four packages for sale. Each package will be delivered within 6 hours of purchase.
						</p>
						
						<b>What the money is spent on?</b><img src="{url}/app/tpl/skins/Habbo/images/new_limited_released.png" alt="" border="0" align="right">
						<p>
							We require solely on donations from our users to keep {hotelname} online 24/7, 365 days a year for you. These donations are spent on our server bills only, and we do not make any profit from donations whatsoever. 
						</p>
						
						<b>Terms and Conditions</b><a href="/legalforms/tos"> Click here</a> to read more!
						<p style="font-style: italic;">
							Purchasing a Rare is classed as a donation, meaning that under no circumstances can we refund you. The rares are given as a 'thank you' for donating to us. 
							<br /><br />
							By purchasing a Rare, you are agreeing to abide by these terms and conditions. If you file a chargeback, or create a dispute in PayPal then your account will be permanently banned until the issue has been resolved. 
						</p>				
					</div> 
					
				</div> 
			</div>
		</div>

		<div id="column2" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix blue ">  
					<h2 class="title"><span style="float: left;">Pay with PayPal</span></h2>
					<div style="padding: 5px" align="center">
						<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="KKEN36BYMFYVA">
							<table>
								<tr><td><input type="hidden" name="on0" value="Choose package">Choose package</td></tr><tr><td><select name="os0">
								<option value="100 Thrones">100 Thrones $20.00 AUD</option>
								<option value="100 Dinos">100 Dinos $20.00 AUD</option>
								<option value="100 DJ Decks">100 DJ Decks $20.00 AUD</option>
								<option value="20 Dragons">20 Dragons $25.00 AUD</option>
								<option value="20 ICM's">20 ICM's $25.00 AUD</option>
								<option value="All of the above">All of the above $100.00 AUD</option>
								</select></td></tr>								
								<tr><td><input type="hidden" name="on1" value="{hotelname} Username">{hotelname} Username</td></tr>								
								<tr><td><input type="text" name="os1" value="<?php echo $_SESSION['user']['username']; ?>" maxlength="200"></td></tr>
							</table>
							
							<input type="hidden" name="currency_code" value="AUD">
							<input type="image" src="https://www.paypalobjects.com/en_AU/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal — The safer, easier way to pay online.">
							<img alt="" border="0" src="https://www.paypalobjects.com/en_AU/i/scr/pixel.gif" width="1" height="1">
						</form>	
					</div> 
				</div> 
			</div>	

			<div class="habblet-container ">
				<div class="cbb clearfix green ">  
					<h2 class="title"><span style="float: left;">Pay with PayGol</span></h2>
					<div style="padding: 5px" align="center">
						<form name="pg_frm" method="post" action="http://www.paygol.com/micropayment/paynow" >
							{hotelName} username:<p>
							<input type="text" name="pg_custom" value="<?php echo $_SESSION['user']['username']; ?>"><p>
							<input type="hidden" name="pg_serviceid" value="65215">
							<input type="hidden" name="pg_currency" value="USD">
							<input type="hidden" name="pg_name" value="rarez">

							<select name="pg_price"> 
							<option value="1" selected>100 Thrones 20</option>
							<option value="2">100 Dinos 20</option>
							<option value="3">100 Djs 20</option>
							<option value="4">20 Dragons 25</option>
							<option value="5">20 ICMS 25</option>
							<option value="6">500,000 Credits 15</option>
							<option value="7">500,000 Pixels 15</option>
							</select>
							
							<br/><br/>
							
							<input type="hidden" name="pg_return_url" value="{url}/store/rares">
							<input type="hidden" name="pg_cancel_url" value="{url}/store/rares">
							<input type="image" name="pg_button" class="paygol" src="http://www.paygol.com/micropayment/img/buttons/125/black_en_pbm.png" border="0" alt="Make payments with PayGol: the easiest way!" title="Make payments with PayGol: the easiest way!" >     
						</form>
						
					</div> 
				</div> 
			</div>				
		</div>
		

<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
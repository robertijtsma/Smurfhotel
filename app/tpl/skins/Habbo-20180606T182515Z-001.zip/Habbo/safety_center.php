
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelname} - Group Home: The Safety Centre </title>

<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>
	





<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/static/styles/home.css" type="text/css" />
	<link href="/myhabbo/styles/assets/other.css?v=e2207783f42ccfe7310b7e4858fb5d7b" type="text/css" rel="stylesheet" />
    <link href="/myhabbo/styles/assets/backgrounds.css?v=8fedfcb85e3bc4a24a782f94044cefce" type="text/css" rel="stylesheet" />
    <link href="/myhabbo/styles/assets/stickers.css?v=73d0e4e4e2d5183848be8661fa19d689" type="text/css" rel="stylesheet" />

<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/static/js/homeview.js" type="text/javascript"></script>
<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/static/styles/lightwindow.css" type="text/css" />
<script src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/static/js/homeauth.js" type="text/javascript"></script>
<link rel="stylesheet" href="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/static/styles/group.css" type="text/css" />
<style type="text/css">

    #playground, #playground-outer {
	    width: 922px;
	    height: 1360px;
    }

</style>	<script type="text/javascript" src="https://www.google.com/recaptcha/api/js/recaptcha_ajax.js"></script>
    	
		<meta name="description" content="Habbo Groups" />
		<meta name="keywords" content="Habbo Groups" />


<script src="//cdn.optimizely.com/js/13389159.js"></script>

<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo//web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo//web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo//web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo//web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<meta name="build" content="63-BUILD2361 - 08.08.2013 12:56 - com" />
</head>

<body id="viewmode" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 3;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 5;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>


<div id="container">
	<div id="content" style="position: relative" class="clearfix">
    <script type="text/javascript">
document.observe("dom:loaded", function() { initView(229591, 53812272); });
</script>





<div id="mypage-wrapper" class="cbb blue staff">
<div class="box-tabs-container box-tabs-left clearfix">
	<div class="myhabbo-view-tools">
					<a href="/groups/actions/join?groupId=229591" id="join-group-button">Join Group</a>
			<a href="#" id="reporting-button" style="display: none;">Report</a>
			<a href="#" id="stop-reporting-button" style="display: none;">Cancel Report!</a>
	</div>
    <h2 class="page-owner">
    	The Safety Centre
    </h2>
</div>
	<div id="mypage-content">
			<div id="mypage-bg" class="b_bg_hotel">
				<div id="playground">




<div class="movable stickie n_skin_defaultskin-c" style=" left: 322px; top: 1173px; z-index: 12;" id="stickie-8145479">
	<div class="n_skin_defaultskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145479-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><span style="color: #d80000;"><b><span style="font-size: 14px;">BE A SAFE SURFER</span></b></span><br />    <br />Learn to avoid the dangers of the digital deep <br>with our <a class="bbcode-url-link" href="https://help.habbo.com/entries/272453-All-about-Safety"><b>Safe Surfing</b></a> tips.</div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 313px; top: 776px; z-index: 14;" id="stickie-8145490">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145490-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><a href="http://www.childline.org.uk/"><img src="http://images.habbo.com/c_images/Hotel-Managers-Images/images.jpg" style="border:5px solid black"><br><b><span style="color: #d80000;"><p align="center">If you're in the UK</p></span></b> </a></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 692px; top: 785px; z-index: 8;" id="stickie-8145473">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145473-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><img src="http://images.habbo.com/c_images/album1989/Saftey_Page_details.gif"></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 54px; top: 647px; z-index: 6;" id="stickie-8145478">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145478-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><a href="http://www.whatsup.co.nz/"><img src="http://images.habbo.com/c_images/Hotel-Managers-Images/index.jpg" style="border:5px solid black"><br><span style="color: #d80000;"><b><p align="center">If you're in the New Zealand</p></b></span></a></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 761px; top: 10px; z-index: 1;" id="stickie-8145481">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145481-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><a href="http://www.ceop.police.uk/safety-centre/"><img src="http://images.habbo.com/c_images/Hotel-Managers-Images/blue_large_final.gif" /></a></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_defaultskin-c" style=" left: 659px; top: 478px; z-index: 4;" id="stickie-8145485">
	<div class="n_skin_defaultskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145485-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><span style="color: #d80000;"><b><span style="font-size: 14px;">The PII (Personal Identifying Information) Rule</span></b></span><br /><b><br />If you're not sure how much of your personal info <br>is safe to give out online, apply The PII Rule:<br /><br /><span style="color: #0070d7;">Would I be happy to hand out this information <br>to total strangers on the street?</span><br /><br />If the answer is "No!", don't give it out online either.</b></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 673px; top: 965px; z-index: 10;" id="stickie-8145488">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145488-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><a href="http://www.kidshelpline.com.au/"><img src="http://images.habbo.com/c_images/Hotel-Managers-Images/kids_help.jpg" style="border:5px solid black"><p align="center"><span style="color: #d80000;"><b>If you're in Australia</b></span></p></a></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 373px; top: 975px; z-index: 13;" id="stickie-8145474">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145474-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><a href="http://www.kidshelpphone.ca"><img src="http://images.habbo.com/c_images/Hotel-Managers-Images/kidshelpphone.jpg" style="border:5px solid black"><p align="center"><span style="color: #d80000;"><b>If you're in Canada</b></span></p></a></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 539px; top: 792px; z-index: 9;" id="stickie-8145475">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145475-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><p align="center"><a href="http://nineline.org/"><img src="http://images.habbo.com/c_images/Hotel-Managers-Images/nineline.jpg"><br /><span style="color: #d80000;"><b>If you're in the US</p></b></span></a></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 326px; top: 419px; z-index: 16;" id="stickie-8145476">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145476-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><a href="http://www.childrensociety.org.sg/index.php?option=com_k2&view=item&layout=item&id=30&Itemid=26" target="blank"><img src="http://images.habbo.com/c_images/Hotel-Managers-Images/tinklefriend.jpg"  style="border:5px solid black"/><p align="center"><b><span style="color: #d80000;">If you're in Singapore</span></b></p></a></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_defaultskin-c" style=" left: 30px; top: 315px; z-index: 17;" id="stickie-8145477">
	<div class="n_skin_defaultskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145477-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><span style="color: #d80000;"><b><span style="font-size: 14px;">Safe Snaps</span></b></span><br /><br />Before you post that pic of yourself,<br />ask yourself one question:<br /><br /><b>Would I be happy for my Mum  <br> to see this photo or would I want to  <br> hide it from her?</b><br /><br />If the answer is that you'd hide  <br> it from your Mum, don't post it online!  <br> Remember; once you've <br>posted a pic you can <i>never </i>get it back <br>and you have <b>no</b> control over what  <br> happens to it or who sees it!</div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_defaultskin-c" style=" left: 16px; top: 819px; z-index: 7;" id="stickie-8145487">
	<div class="n_skin_defaultskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145487-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><span style="color: #d80000;"><b><span style="font-size: 14px;">Think Before You Web�am!</span></b></span><br /><br />* Web�am images can be saved and used to bully <br>or blackmail you.<br />* Web�am images can be posted and keep <br> being reposted to websites to humiliate you.<br />* Web�am creeps can use software to stream <i>fake</i> <br>images to you - that 16yr old hottie on web�am <br>may be an older predator!<br />* Provocative web�am sessions with your online gf/bf <br>may come back to haunt you years later.<br />* If someone is asking you for <br> webcam contact, click the "help" button  <br>in the top right corner of your screen to alert a moderator. <br> If you live in the UK, you can also report incidents directly to CEOP.<br /><br /><a href="http://www.ceop.police.uk/safety-centre/"><img src="http://images.habbo.com/c_images/Hotel-Managers-Images/blue_large_final.gif" /></a></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_defaultskin-c" style=" left: 331px; top: 279px; z-index: 5;" id="stickie-8145484">
	<div class="n_skin_defaultskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145484-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><span style="color: #d80000;"><b><span style="font-size: 14px;">Helplines</span></b></span><br /><b>If you feel sad, are being bullied, self-harm or just want<br />to talk to someone for advice and help, please contact these<br />helplines. </b></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 759px; top: 69px; z-index: 3;" id="stickie-8145486">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145486-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><div style="width: 145px; background-color:#ffffff ; border-color: #; border-width: px; border-style: ;-moz-border-radius: 5px; -webkit-border-radius: 5px; padding: 5px;"><b>CEOP is here to help if you are a young person who has been approached about sex online, or forced or tricked into taking part in sexual activity with anyone online or in the real world. Visit our Safety Centre by clicking the button above for advice and to report directly to CEOP.</b><br /><br />For player assistance, Habbo bans, and other Habbo-related questions, you can email <a href="http://help.habbo.com" target="_blank">Habbo Player Support</a>. A Player Support agent will answer your query as soon as possible.</div></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 642px; top: 1163px; z-index: 11;" id="stickie-8145483">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145483-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><img src="http://images.habbo.com/c_images/album1989/nowebcam.png"></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_defaultskin-c" style=" left: 29px; top: 272px; z-index: 18;" id="stickie-8145482">
	<div class="n_skin_defaultskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145482-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><a href="https://help.habbo.com/entries/20908796-Wise-up-to-website-scams" target="blank"><span style="color: #d80000;"><b><span style="font-size: 14px;">Scared of Scammers?</span></b></span></a></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>




<div class="movable stickie n_skin_nakedskin-c" style=" left: 132px; top: 17px; z-index: 19;" id="stickie-8145480">
	<div class="n_skin_nakedskin" >
		<div class="stickie-header">
			<h3>					<img id="stickie-8145480-report" class="report-button report-s"
						alt="report"
						src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
						style="display: none" />
			</h3>
			<div class="clear"></div>
		</div>
		<div class="stickie-body">
			<div class="stickie-content">
                <div class="stickie-markup"><iframe width="440" height="248" src="//www.youtube.com/embed/8eUv5XJicJE" frameborder="0" allowfullscreen></iframe></div>
				<div class="stickie-footer">
				</div>
			</div>
		</div>
	</div>
</div>
    <div class="movable sticker s_sticker_arrow_up" style="left: 813px; top: 69px; z-index: 2" id="sticker-30748659">
    </div>


<div class="movable widget GroupInfoWidget" id="widget-12017941" style=" left: 332px; top: 483px; z-index: 15;">
<div class="w_skin_defaultskin">
	<div class="widget-corner" id="widget-12017941-handle">
		<div class="widget-headline"><h3><span class="header-left">&nbsp;</span><span class="header-middle">Group info</span><span class="header-right">&nbsp;</span></h3>
		</div>	
	</div>
	<div class="widget-body">
		<div class="widget-content">

<div class="group-info-icon"><img src="http://www.habbo.com/habbo-imaging/badge/b2116Xs06117s22084s22082s220802787ed2c92b14f9513caeab13a3713d3.gif" /></div>
	    <img id="groupname-229591-report" class="report-button report-gn"
			alt="report"
			src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
			style="display: none;" />
<h4>The Safety Centre</h4>

<p>Group created: <b>Aug 25, 2010</b></p>
<p>13,097 members</p>
<div class="group-info-description">Habbo's official Safety Centre with all the information you need to keep yourself safe and avoid scams.</div>



<div id="profile-tags-panel">
<div id="profile-tag-list">
<div id="profile-tags-container">
    <span class="tag-search-rowholder">
        <a href="http://www.habbo.com/tag/cyberbullying" class="tag"
        >cyberbullying</a><div class="tag-id" style="display:none">1989042</div><img border="0" class="tag-add-link" onMouseOver="this.src='http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_add_hi.gif'" onMouseOut="this.src='http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_add.gif'" src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_add.gif"
        />
    </span>
    <span class="tag-search-rowholder">
        <a href="http://www.habbo.com/tag/safety" class="tag"
        >safety</a><div class="tag-id" style="display:none">76</div><img border="0" class="tag-add-link" onMouseOver="this.src='http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_add_hi.gif'" onMouseOut="this.src='http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_add.gif'" src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_add.gif"
        />
    </span>
    <span class="tag-search-rowholder">
        <a href="http://www.habbo.com/tag/security" class="tag"
        >security</a><div class="tag-id" style="display:none">8453</div><img border="0" class="tag-add-link" onMouseOver="this.src='http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_add_hi.gif'" onMouseOut="this.src='http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_add.gif'" src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_add.gif"
        />
    </span>
    <img id="tag-img-added" border="0" class="tag-none-link" src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/buttons/tags/tag_button_added.gif" style="display:none"/>    
</div>

<script type="text/javascript">
    document.observe("dom:loaded", function() {
        TagHelper.setTexts({
            buttonText: "OK",
            tagLimitText: "The limit is 20 tags!"
        });
    });
</script>
</div>

</div>
<script type="text/javascript">
    document.observe("dom:loaded", function() {
        new GroupInfoWidget('229591', '53812272');
    });
</script>



	<img id="groupdesc-229591-report" class="report-button report-gd"
	    alt="report"
	    src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2391/web-gallery/images/myhabbo/buttons/report_button.gif"
        style="display: none;" />

		<div class="clear"></div>
		</div>
	</div>
</div>
</div>
					
				</div>
				<div id="mypage-ad">
				</div>
			</div>
	</div>
</div>

<script type="text/javascript">
	Event.observe(window, "load", observeAnim);
	document.observe("dom:loaded", function() {
		initDraggableDialogs();
        repositionInvalidItems();
	});
</script>
    </div>
</div>
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			 

</div>
<!--[if lt IE 7]>
<script type="text/javascript">
Pngfix.doPngImageFix();
</script>
<![endif]-->
    </div>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>


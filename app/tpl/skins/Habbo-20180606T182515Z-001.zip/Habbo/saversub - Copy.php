<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>{hotelName} - Saver Subscription!</title>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs2.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/visual.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/common.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/fullcontent.js"></script>
        
        <script type="text/javascript">
            document.HabboLoggedIn = true;
            var HabboName = "{username}";
            var HabboId = {userid};
            var HabboReqPath = "";
            var HabboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var HabboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var HabboPartner = "";
            var HabboHabboClientPopupUrl = "{url}/client";
            window.name = "HabboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/personal.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/Habboclub.js"></script>
        
        <!--[if IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie8.css" type="text/css">
        <![endif]-->
        <!--[if lt IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie.css" type="text/css" />
        <![endif]-->
        <!--[if lt IE 7]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie6.css" type="text/css" />
            <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/pngfix.js"></script>
            <script type="text/javascript">
                try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
            </script>
            <style type="text/css">
                body { behavior: url({url}/app/tpl/skins/Habbo/js/csshover.htc); }
            </style>
        <![endif]-->
    </head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 4;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 4;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
               </div>
</div> 
 <div id='alert'></div>

<div id="container">
<div id="content" style="position: relative" class="clearfix"><div>

<div class="habblet-container" style="float:left;width:841px;">
<div class="cb green">
<div class="bt"><div></div></div><div class="i1"><div class="i2"><div class="i3">
<div class="box-tabs-container box-tabs-left clearfix">
<h2 class="page-owner">Are you a subscriber?</h2><img src="{url}/app/tpl/skins/Habbo/images/group_UI_identity.png" alt="" border="0" align="right">
<ul class="box-tabs"></ul>
</div>

<div class="box-content" style="background-image:url('{url}/app/tpl/skins/Habbo/images/com_staff006?1'); width:692px; height:1000px; padding-left:45px;">
<div style="display:block;">
</div>
<div align="center">
  <img src="{url}/app/tpl/skins/Habbo/images/catalogue/catalog_madmoney_header_en.gif" alt="" border="0" align="left"></p>
  <p><font size="5"><img src="{url}/app/tpl/skins/Habbo/images/catalogue/madmoney_header.gif" alt="" border="0" align="left">Saver Subscribtion</font>
</div>
<p align="center">                 <em></em></p>
<p align="center"></p>
<p align="center"><br>
   <br><font size="2"><img src="{url}/app/tpl/skins/Habbo/images/catalogue/puzzlebox_teaser1.gif" alt="" border="0" align="left"><h3><font color='green'>Why donate?</h3><font color='black'>
						{hotelname} Hotel runs on donations from users like you! Without users constantly donating and supporting us, we would not be able to stay online. In addition to knowing that {hotelname} Hotel will be able to live on even longer, you can also get some pretty cool rewards for donating! Look at the list to the right to see those rewards.<img src="{url}/app/tpl/skins/Habbo/images/island.gif" alt="" border="0" align="right">
						<h3><font color='darkred'>How do I donate?</h3><font color='black'>
						Donating is similar to purchasing VIP. The only payment method that is available for donating is Paypal. Simply scroll to the bottom of the page, select the donation amount, enter in your {hotelname} Hotel username, and click pay now! Paypal is the leading and most widely-used payment system on the internet.<img src="{url}/app/tpl/skins/Habbo/images/catalogue/catalog_madmoney_teaser_en.gif" alt="" border="0" align="right"> After donating through Paypal, you can expect to have your credits, pixels, badge, and rares delivered to you instantly, or at most a few minutes. The rares will be sent to you in Red Presents. You can simply place these presents down and open them to receive your rares.
						<h3><font color='darkred'>Can I donate more than once?</h3><font color='black'>
						You can donate as many times as you like! Donate whenever you can -- we can always use more funds to help pay for our multiple servers, domains, and various other services which we provide free of charge.
						<h3><font color='darkred'>Refunds?</h3><font color='black'>
						Refunds are not allowed.<img src="{url}/app/tpl/skins/Habbo/images/article_bigWave_1.gif" alt="" border="0" align="left"> <b>All payments are final.</b> By donating to {hotelname} Hotel, you agree that you will not attempt to refund your donation at any time. This causes a huge hassle for us, and we <b>will</b> ban your account if you attempt to get your money back.<p>
						<h3><font color='darkred'>What color rares are available?</h3><font color='black'>
						<b>Ice Cream Machines</b> - <i>Aqua, Blue, Choco, Fucsia, Gold, Ochre, Pink, Purple, Red, Shamrock</i><br>
						<b>Dragons</b> - <i>Gold, Silver, Blue, Sky, Purple, Bronze, Black, Jade, Forest, Red</i><br>

						All rare colors will be randomly selected. You have an equal chance to receive all colors of rares!
						<br><br><p>So why wait?! Donate now, and get some really cool rewards!</p>	
   <br>
  <br>
   <br>
  <br>
  </p>
<p align="center"><br>
  <br>
   <br>
  
  <br>
  c</p>
<p align="center"><br>
   <br>
  
  <br>
 
  <br>
  </p>


</div></div></div><div class="bb"><div></div></div>
</div>
</div>

</div>
</div>

</div></div></div><div class="bb"><div></div></div></div>
</div> 
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
				</div>
		</div>
	</div>



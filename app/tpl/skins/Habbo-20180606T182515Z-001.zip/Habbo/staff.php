<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName}: Staff</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>

	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<style type="text/css">background-position:-4px -115px;}#navi{clear:both;font-size:12px;}.title{color:white;text-shadow:black 0.1em 0.1em 0.2em}#navi li{float:left;height:28px;margin:0 5px 0 0;white-space:nowrap;}#navi li strong,#navi li a{float:left;height:22px;padding:px 16px 0 </style>
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
	
	<style type="text/css">
		hr {background-color:#CCC;border:0;height:1px;margin:10px 0;}
	</style>
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 2;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container"> 
 
<div id="navi2-container" class="pngbg"> 
    <div id="navi2" class="pngbg clearfix"> 
	<ul> 
	<?php 

		$subNavigatorID = 3;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?></ul> 
    </div> 
</div> 

<div id="container">
<div id="content" style="position: relative" class="clearfix">
<span style='font-size:10px'><div id="column2" class="column"><div class="habblet-container ">		
<div class="cbb clearfix blue "> 
<h2 class="title"><span style="float: left;">Supervisors</span> <span style="float: right; font-weight: normal; font-size: 75%;"></span></h2><div class="box-content"><table width="111%" style="padding: 5px; margin-left: -15px; background-color: #fff;">
			<tbody>
				<tr>
					<td valign="middle" width="25">
							<img data-cfstyle="margin-top: -10px;" style="display:none;visibility:hidden;" data-cfsrc="http://www.habbo.com/habbo-imaging/avatarimage?figure={figure}.gif"><noscript><img style="margin-top: -10px;" src="http://www.habbo.com/habbo-imaging/avatarimage?figure={figure}.gif"></noscript>
					</td>
					<td valign="top">
						<b style="font-size: 110%;"><a href="">BlackJesus</a></b><br />
						Last Online: {LASTSIGNEDIN}<br />
						Motto: <i>WickdCMS</i>
						<hr>
						Role: <b>Supervisor</b><br>
						Age: N/A<br>
						Registered: {registered}<br>
						Bans: <b>0</b><br>
						Tickets <b>0</b>
						
						</font><br /><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/adm.png'><noscript><img src='https://images.fresh-hotel.org/adm.png'></noscript><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/flags/UK.png'><noscript><img src='#'></noscript>					</td>
					<td valign="top" style="float: right;">
											<b style="color: darkgreen;"><marquee>On Duty</marquee></b>
						 <br /><br />
					</td>
				</tr>
			</tbody>
			</table>
			<table width="111%" style="padding: 5px; margin-left: -15px; background-color: #E6E6E6;">
			<tbody>
				<tr>
					<td valign="middle" width="25">
							<img data-cfstyle="margin-top: -10px;" style="display:none;visibility:hidden;" data-cfsrc="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ch-255-92.hd-190-8.sh-3016-110.ha-3144-92-96.lg-280-96.hr-802-1399&size=b&direction=2&head_direction=3&gesture=sml&size=m"><noscript><img style="margin-top: -10px;" src="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ch-255-92.hd-190-8.sh-3016-110.ha-3144-92-96.lg-280-96.hr-802-1399&size=b&direction=2&head_direction=3&gesture=sml&size=m"></noscript>
					</td>
					<td valign="top">
						<b style="font-size: 110%;"><a href="https://fresh-hotel.org/home/PoundLand"></a></b><br />
						<br />
						
						
						</font><br /><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/adm.png'><noscript><img src='https://images.fresh-hotel.org/adm.png'></noscript><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/flags/UK.png'><noscript><img src='https://images.fresh-hotel.org/flags/UK.png'></noscript>					</td>
					<td valign="top" style="float: right;">
											<b style="color: darkred;"><marquee></marquee></b>
						  <br /><br />
					</td>
				</tr>
			</tbody>
			</table>
			<table width="111%" style="padding: 5px; margin-left: -15px; background-color: #fff;">
			<tbody>
				<tr>
					<td valign="middle" width="25">
							<img data-cfstyle="margin-top: -10px;" style="display:none;visibility:hidden;" data-cfsrc="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ea-3168-62.lg-710-64.ch-655-104.hr-3012-45.hd-600-2&size=b&direction=2&head_direction=3&gesture=sml&size=m"><noscript><img style="margin-top: -10px;" src="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ea-3168-62.lg-710-64.ch-655-104.hr-3012-45.hd-600-2&size=b&direction=2&head_direction=3&gesture=sml&size=m"></noscript>
					</td>
					<td valign="top">
						<b style="font-size: 110%;"><a href="https://fresh-hotel.org/home/Resolve"></a></b><br />
						
						
						</font><br /><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/adm.png'><noscript><img src='https://images.fresh-hotel.org/adm.png'></noscript><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/flags/UK.png'><noscript><img src='https://images.fresh-hotel.org/flags/UK.png'></noscript>					</td>
					<td valign="top" style="float: right;">
											<b style="color: darkred;"><marquee></marquee></b>
						  <br /><br />
					</td>
				</tr>
			</tbody>
			</table>
			</div>
	</div> 
</div> 
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script> </div><div id="column2" class="column">	<style type="text/css">
		hr {background-color:#CCC;border:0;height:1px;margin:10px 0;}
	</style>
<div class="habblet-container ">		
<div class="cbb clearfix orange "> 
<h2 class="title"><span style="float: left;">Moderators</span> <span style="float: right; font-weight: normal; font-size: 85%;"></span></h2><div class="box-content"><table width="111%" style="padding: 5px; margin-left: -15px; background-color: #fff;">
			<tbody>
				<tr>
					<td valign="middle" width="25">
							<img data-cfstyle="margin-top: -10px;" style="display:none;visibility:hidden;" data-cfsrc="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ha-3145-96-1408.hd-180-8.lg-3202-110-62.ch-255-96.he-1601-62.hr-839-61&size=b&direction=2&head_direction=3&gesture=sml&size=m"><noscript><img style="margin-top: -10px;" src="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ha-3145-96-1408.hd-180-8.lg-3202-110-62.ch-255-96.he-1601-62.hr-839-61&size=b&direction=2&head_direction=3&gesture=sml&size=m"></noscript>
					</td>
					<td valign="top">
						<b style="font-size: 110%;"><a href="https://fresh-hotel.org/home/Sam"></a></b><br />
						
						
						</font><br /><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/adm.png'><noscript><img src='https://images.fresh-hotel.org/adm.png'></noscript><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/flags/UK.png'><noscript><img src='https://images.fresh-hotel.org/flags/UK.png'></noscript>					</td>
					<td valign="top" style="float: right;">
											<b style="color: darkred;"><marquee></marquee></b>
						  <br /><br />
					</td>
				</tr>
			</tbody>
			</table>
		
			<table width="111%" style="padding: 5px; margin-left: -15px; background-color: #E6E6E6;">
			<tbody>
				<tr>
					<td valign="middle" width="25">
							<img data-cfstyle="margin-top: -10px;" style="display:none;visibility:hidden;" data-cfsrc="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ea-1402-62.hd-3095-8.fa-1209-110.cc-3007-110-110.lg-3058-110.ch-3001-92-110.wa-3073-92.he-3218-62.hr-3163-59.ca-3292-92&size=b&direction=2&head_direction=3&gesture=sml&size=m"><noscript><img style="margin-top: -10px;" src="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ea-1402-62.hd-3095-8.fa-1209-110.cc-3007-110-110.lg-3058-110.ch-3001-92-110.wa-3073-92.he-3218-62.hr-3163-59.ca-3292-92&size=b&direction=2&head_direction=3&gesture=sml&size=m"></noscript>
					</td>
					<td valign="top">
						<b style="font-size: 110%;"><a href="https://fresh-hotel.org/home/arunchahal"></a></b><br />
						
						
						</font><br /><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/adm.png'><noscript><img src='https://images.fresh-hotel.org/adm.png'></noscript><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/flags/UK.png'><noscript><img src='https://images.fresh-hotel.org/flags/UK.png'></noscript>					</td>
					<td valign="top" style="float: right;">
											<b style="color: darkred;"><marquee></marquee></b>
						  <br /><br />
					</td>
				</tr>
			</tbody>
			</table>
		
			<table width="111%" style="padding: 5px; margin-left: -15px; background-color: #fff;">
			<tbody>
				<tr>
					<td valign="middle" width="25">
							<img data-cfstyle="margin-top: -10px;" style="display:none;visibility:hidden;" data-cfsrc="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=lg-280-110.hr-828-38.hd-190-7.ha-1012-62.ch-225-1341.ca-3187-62.sh-290-1408&size=b&direction=2&head_direction=3&gesture=sml&size=m"><noscript><img style="margin-top: -10px;" src="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=lg-280-110.hr-828-38.hd-190-7.ha-1012-62.ch-225-1341.ca-3187-62.sh-290-1408&size=b&direction=2&head_direction=3&gesture=sml&size=m"></noscript>
					</td>
					<td valign="top">
						<b style="font-size: 110%;"><a href="https://fresh-hotel.org/home/Transitions"></a></b><br />
						
						
						</font><br /><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/adm.png'><noscript><img src='https://images.fresh-hotel.org/adm.png'></noscript><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/flags/UK.png'><noscript><img src='https://images.fresh-hotel.org/flags/UK.png'></noscript>					</td>
					<td valign="top" style="float: right;">
											<b style="color: darkred;"><marquee></marquee></b>
						  <br /><br />
					</td>
				</tr>
			</tbody>
			</table>
		
			</div>
	</div> 
</div> 
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script> </div><div id="column2" class="column"><div class="habblet-container ">		
<div class="cbb clearfix green "> 
<h2 class="title"><span style="float: left;">Super Moderators</span> <span style="float: right; font-weight: normal; font-size: 75%;"></span></h2><div class="box-content"><table width="111%" style="padding: 5px; margin-left: -15px; background-color: #fff;">
			<tbody>
				<tr>
					<td valign="middle" width="25">
							<img data-cfstyle="margin-top: -10px;" style="display:none;visibility:hidden;" data-cfsrc="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ha-1023-63.ca-1816-1408.hd-190-18.ea-1404-63.lg-3017-100-1336.ch-3001-92-1334.hr-170-61.sh-908-64&size=b&direction=2&head_direction=3&gesture=sml&size=m"><noscript><img style="margin-top: -10px;" src="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ha-1023-63.ca-1816-1408.hd-190-18.ea-1404-63.lg-3017-100-1336.ch-3001-92-1334.hr-170-61.sh-908-64&size=b&direction=2&head_direction=3&gesture=sml&size=m"></noscript>
					</td>
					<td valign="top">
						<b style="font-size: 110%;"><a href="https://fresh-hotel.org/home/Kenzie"></a></b><br />
					</font><br /><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/adm.png'><noscript><img src='https://images.fresh-hotel.org/adm.png'></noscript><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/flags/UK.png'><noscript><img src='https://images.fresh-hotel.org/flags/UK.png'></noscript>					</td>
					<td valign="top" style="float: right;">
											<b style="color: darkred;"><marquee></marquee></b>
						  <br /><br />
					</td>
				</tr>
			</tbody>
			</table>
			<table width="111%" style="padding: 5px; margin-left: -15px; background-color: #E6E6E6;">
			<tbody>
				<tr>
					<td valign="middle" width="25">
							<img data-cfstyle="margin-top: -10px;" style="display:none;visibility:hidden;" data-cfsrc="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ca-1816-1408.hd-600-1.ea-3168-63.lg-3174-96-96.ch-655-110.he-3274-88.hr-515-1352.sh-3016-1321&size=b&direction=2&head_direction=3&gesture=sml&size=m"><noscript><img style="margin-top: -10px;" src="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=ca-1816-1408.hd-600-1.ea-3168-63.lg-3174-96-96.ch-655-110.he-3274-88.hr-515-1352.sh-3016-1321&size=b&direction=2&head_direction=3&gesture=sml&size=m"></noscript>
					</td>
					<td valign="top">
						<b style="font-size: 110%;"><a href="https://fresh-hotel.org/home/Amy"></a></b><br />
					</font><br /><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/adm.png'><noscript><img src='https://images.fresh-hotel.org/adm.png'></noscript><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/flags/UK.png'><noscript><img src='https://images.fresh-hotel.org/flags/UK.png'></noscript>					</td>
					<td valign="top" style="float: right;">
											<b style="color: darkred;"><marquee></marquee></b>
						  <br /><br />
					</td>
				</tr>
			</tbody>
			</table>
			<table width="111%" style="padding: 5px; margin-left: -15px; background-color: #fff;">
			<tbody>
				<tr>
					<td valign="middle" width="25">
							<img data-cfstyle="margin-top: -10px;" style="display:none;visibility:hidden;" data-cfsrc="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=hr-115-61.hd-3092-1.lg-3202-1320-110.ch-225-110.ca-3187-92.sh-3016-110&size=b&direction=2&head_direction=3&gesture=sml&size=m"><noscript><img style="margin-top: -10px;" src="https://www.habbo.com.tr/habbo-imaging/avatarimage?figure=hr-115-61.hd-3092-1.lg-3202-1320-110.ch-225-110.ca-3187-92.sh-3016-110&size=b&direction=2&head_direction=3&gesture=sml&size=m"></noscript>
					</td>
					<td valign="top">
						<b style="font-size: 110%;"><a href="https://fresh-hotel.org/home/Zane"></a></b><br />
					</font><br /><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/adm.png'><noscript><img src='https://images.fresh-hotel.org/adm.png'></noscript><img style="display:none;visibility:hidden;" data-cfsrc='https://images.fresh-hotel.org/flags/UK.png'><noscript><img src='https://images.fresh-hotel.org/flags/UK.png'></noscript>					</td>
					<td valign="top" style="float: right;">
											<b style="color: darkred;"><marquee></marquee></b>
						  <br /><br />
					</td>
				</tr>
			</tbody>
			</table>
			</div>
	</div> 
</div> 
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script> </div><center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Footer -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-6470479095487876"
     data-ad-slot="8764460942"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<center>
<!--[if lt IE 7]>
<script type="text/javascript">
Pngfix.doPngImageFix();
</script>
<![endif]--> 
<div id="footer"> 
<!-- Start Alexa Certify Javascript -->
<script type="text/javascript">
_atrk_opts = { atrk_acct:"e/+Ri1a4ZP002x", domain:"fresh-hotel.org",dynamic: true};
(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
</script>
<noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=e/+Ri1a4ZP002x" style="display:none" height="1" width="1" alt="" /></noscript>
<!-- End Alexa Certify Javascript -->


<script type="text/javascript"> 
HabboView.run();
</script> 
 
<script type="text/javascript" src="//ajax.cloudflare.com/cdn-cgi/nexp/dok9v=73806ac11c/apps1.min.js"></script><script type="text/javascript">__CF.AJS.init1();</script></body> 
</html> 





</html>
</div></div></div>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
<?php
require_once "global.php";

$tpl->Init();
$tpl->AddGeneric('head-init');
$tpl->AddIncludeSet('process-template');
$tpl->WriteIncludeFiles();
$tpl->AddGeneric('head-overrides-process');
$tpl->AddGeneric('head-bottom');
$tpl->AddGeneric('process-template-top');
$tpl->Write("<html><body background = '/images/bg.png'></body></html>");

$tpl->Write("<center><b><h2>HABBO HOTEL PRIVACY POLICY</b></h2><br></center>");
$tpl->Write("Are you kidding Meh? You actually want to read this? Basically, we aint gonna give your info away geez.");
$tpl->AddGeneric('process-template-bottom');
$tpl->AddGeneric('footer');

$tpl->SetParam('page_title', 'Privacy Policy');

$tpl->Output();
?>


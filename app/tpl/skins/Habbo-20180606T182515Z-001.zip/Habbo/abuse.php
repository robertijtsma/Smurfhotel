<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>Habbot - Community</title>
        
        <link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>
		

        <script type="text/javascript">
            document.habboLoggedIn = true;
            var habboName = "{username}";
            var habboId = {userid};
            var habboReqPath = "";
            var habboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var habboPartner = "";
            var habboDefaultClientPopupUrl = "{url}/client";
            window.name = "habboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
        <link rel="stylesheet" href="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/styles/cbs2credits.css" type="text/css" />
<link rel="stylesheet" href="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/styles/newcredits.css" type="text/css" />
<script src="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/js/cbs2credits.js" type="text/javascript"></script>	
							
								<script src="http://images.habbo.com/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/947/web-gallery/static/js/newcredits.js" type="text/javascript"></script>
        <!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<meta name="build" content="63-BUILD2780 - 23.01.2014 11:22 - com" />
</head>

<body id="embedpage">
<div id="overlay"></div>

<div id="change-password-form" class="overlay-dialog" style="display: none;">
    <div id="change-password-form-container" class="clearfix form-container">
        <h2 id="change-password-form-title" class="bottom-border">Forgot Password?</h2>
        <div id="change-password-form-content" style="display: none;">
            <form method="post" action="https://www.habbo.com/account/password/identityResetForm" id="forgotten-pw-form">
                <input type="hidden" name="page" value="/identity/settings?changePwd=true" />
                <span>Type in your Habbo account email address:</span>
                <div id="email" class="center bottom-border">
                    <input type="text" id="change-password-email-address" name="emailAddress" value="" class="email-address" maxlength="48"/>
                    <div id="change-password-error-container" class="error" style="display: none;">Please enter a correct email address</div>
                </div>
            </form>
            <div class="change-password-buttons">
                <a href="#" id="change-password-cancel-link">Cancel</a>
                <a href="#" id="change-password-submit-button" class="new-button"><b>Send Email</b><i></i></a>
            </div>
        </div>
        <div id="change-password-email-sent-notice" style="display: none;">
            <div class="bottom-border">
                <span>Hey, we just sent you an email with a link that lets you reset your password.<br>
<br>

NOTE! Remember to check your "junk" folder too!</span>
                <div id="email-sent-container"></div>
            </div>
            <div class="change-password-buttons">
                <a href="#" id="change-password-change-link">Back</a>
                <a href="#" id="change-password-success-button" class="new-button"><b>OK</b><i></i></a>
            </div>
        </div>
    </div>
    <div id="change-password-form-container-bottom" class="form-container-bottom"></div>
</div>

<script type="text/javascript">
    function initChangePasswordForm() {
        ChangePassword.init();
    }
    if (window.HabboView) {
        HabboView.add(initChangePasswordForm);
    } else if (window.habboPageInitQueue) {
        habboPageInitQueue.push(initChangePasswordForm);
    }
</script><div id="container">

    <div class="settings-container clearfix">
        <h1>Manage account-This page being worked on!</h1>It doesn't work
        <div id="back-link">
        <a href="/identity/avatars">My characters</a> &raquo; Manage account      
        </div>
        
        <div style="padding: 0 10px">

        <h3>Email:</h3>
        <div class="opt-email">
            <span>{email}</span>
            <a id="manage-email" class="new-button " onclick="" href="https://www.habbo.com/identity/email"><b>Manage email addresses</b><i></i></a>
        </div>
        <br clear="all"/>
            <h3>Protecting Your Account</h3>
            <div class="opt-email">
                <a id="manage-safety-questions" class="new-button " onclick="" href="https://www.habbo.com/identity/safetyquestions"><b>Edit your security questions</b><i></i></a>
            </div><br/>
        <h3>Log in using:</h3>
        <p>Here's a list of web services you are using to log in</p>
        <div class="opt-auth-providers clearfix settings-auth" style="float: none; width: auto">        
                <p>
                	<img src="http://habboo-a.akamaihd.net/habboweb/63_1dc60c6d6ea6e089c6893ab4e0541ee0/2315/web-gallery/v2/images/rpx/icon_habbo_big.png" style="vertical-align: middle" title="habbo"/>
                	{email}
		 			<span class="last-access-time" isotime="2014-01-25T16:26:42" title="Jan 25, 2014 11:26:42 AM">
					    Last used just now
					</span>
                </p>
        <p>
        </p>
        </div>
        <a id="manage-auth-providers" class="new-button " onclick="" href="https://www.habbo.com/identity/auth"><b>Manage signing in options</b><i></i></a>
        <br clear="all"/>
                
        <h3>Password:</h3>
        <div class="opt-password">
            <span>**************</span>
            <a id="manage-password" class="new-button" href="https://www.habbo.com/identity/password"><b>Change</b><i></i></a>
        </div>
        <div class="opt-email">

        </div>
        </div>
    </div>
    <div class="settings-container-bottom">
  </div>
    <script type="text/javascript">
        document.observe("dom:loaded", function() {
            $(document.body).addClassName("js");
        });

        if (window.opener && window.opener.Avatars) {
            $("back-link").down("a").update("Close settings window");
            if (!!$("manage-password")) {
                $("manage-password").href = $("manage-password").href + "?fromClient=true";
            }
            Event.observe($("back-link"), "click", function(e) {
                Event.stop(e);
                window.opener.focus();
                window.close();
            });
        }


    </script>
<ddiv id="footer">
<p><a href="index.php" target="_self">Homepage</a> | <a href="./TOS" target="_self">Terms of Service</a> | <a href="./privacy" target="_self">Privacy Policy</a>| <a href="./Norefundpolicy" target="_self">Refund Policy</a> |</a><a href="./dip" target="_self">Disclaimer</a>| <a href="./client" target="_self">Launch Client
	<?php /*@@* DO NOT EDIT OR REMOVE THE LINE BELOW WHATSOEVER! *@@ You ARE allowed to remove the link to the HoloCMS site though*/ ?>
	<p>Powered by <a href="http://www.holocms.com/"><b>RevProCMS<b></a> &copy 2013 Kredits to Kryptos,Wicked,Meth0d & Parts by Yifan, sisija<br><?php echo $locale['copyright_Habbo']; ?><p>&copy; Copyright 2012-2013 <a href="{url}" target="_New"><b>Habview Hotel&#8482;</b></a>. All rights reserved.<br>

	<?php /*@@* DO NOT EDIT OR REMOVE THE LINE ABOVE WHATSOEVER! *@@ You ARE allowed to remove the link to the HoloCMS site though*/ ?> 

 </body>
</html>
</div></div></div>
<div id="footer">

<p>
</a></div>
    </body>





</div>



<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-448325-2']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>    
    <!-- Start Quantcast tag -->
<script type="text/javascript">
_qoptions={
qacct:"p-b5UDx6EsiRfMI"
};
</script>
<script type="text/javascript" src="http://edge.quantserve.com/quant.js"></script>
<noscript>
<img src="http://pixel.quantserve.com/pixel/p-b5UDx6EsiRfMI.gif" style="display: none;" border="0" height="1" width="1" alt="Quantcast"/>
</noscript>
<!-- End Quantcast tag -->

<!-- HELP-25840 -->
<!-- Google Code for US Visits -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 1065925576;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "666666";
var google_conversion_label = "Gcy4CLjMkwIQyPei_AM";
var google_conversion_value = 0;
/* ]]> */
</script>
<script type="text/javascript" src="http://www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://www.googleadservices.com/pagead/conversion/1065925576/?label=Gcy4CLjMkwIQyPei_AM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<!-- End Google Code for US Visits -->

<!-- BEGIN EFFECTIVE MEASURE CODE -->
<!-- COPYRIGHT EFFECTIVE MEASURE -->
<script type="text/javascript">
	(function() {
		var em = document.createElement('script'); em.type = 'text/javascript'; em.async = true;
		em.src = ('https:' == document.location.protocol ? 'https://au-ssl' : 'http://au-cdn') + '.effectivemeasure.net/em.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(em, s);
	})();
</script>
<noscript>
	<img src="//au.effectivemeasure.net/em_image" alt="" style="position:absolute; left:-5px;" />
</noscript>
<!--END EFFECTIVE MEASURE CODE -->
    
    
        


</body>
</html>

<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright © 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - Store - VIP</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	
	
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>

	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<style type="text/css">background-position:-4px -115px;}#navi{clear:both;font-size:12px;}.title{color:white;text-shadow:black 0.1em 0.1em 0.2em}#navi li{float:left;height:28px;margin:0 5px 0 0;white-space:nowrap;}#navi li strong,#navi li a{float:left;height:22px;padding:px 16px 0 </style>
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
	
	<style type="text/css">
		hr {background-color:#CCC;border:0;height:1px;margin:10px 0;}
	</style>
	
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 4;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 1;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
		<div id="column1" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix orange ">  
					<h2 class="title"><span style="float: left;">What is VIP?</span></h2><img src="{url}/app/tpl/skins/Habbo/images/group_UI_identity.png" alt="" border="0" align="right">
					<div style="padding: 5px" align='left'> <img src="{url}/app/tpl/skins/Habbo/images/catalogue/ctlg_buy_vip_header.gif" align="right" vspace="5" hspace="5">
						<p>
							Thanks for showing an interest in purchasing a {hotelname} VIP subscription, we currently have two subsciptions on offer, these are <u>VIP</u> and <u>Event Staff</u>. Each subscriptions come with various advantages and extras, which have been outlined below for you.
						</p><img src="{url}/app/tpl/skins/Habbo/images/catalogue_xd_vip.gif" align="right" vspace="5" hspace="5">
						
						<b>What the money is spent on</b>
						<p>
							We require solely on donations from vip subscriptions to keep {hotelname} Hotel online 24/7, 365 days a year for you. These donations are spent on our server bills only, and we do not make any profit from donations whatsoever. 
						</p>
						
						<b>Event Staff $20</b>
						<p>
							By purchasing Event Staff, you will get the following:<br /> 
								<div style="padding: 0 0 0 10px; margin: 0;">
								&raquo; :push command<br />
								&raquo; :pull command<br />
								&raquo; :setspeed command<br />
								&raquo; :spull command<br /><img src="{url}/app/tpl/skins/Habbo/images/ctlg_gift_vip_teaser.gif" align="right" vspace="5" hspace="5"
								&raquo; Enter full rooms and locked rooms<br />
								&raquo; 5 second flood time<br />
								&raquo; Send/Receive staff alerts!<br />
								&raquo; Exclusive Event Rare Catalogue<br />
								&raquo; 25,000 Coins<br />
								&raquo; 15,000 Pixels<br />
								&raquo; Better chance of becoming staff!<br />
								</div>
						</p>
						<b>Platinum VIP $40</b>
						<p>
							By purchasing Platinum, you will get the following:<br /> 
								<div style="padding: 0 0 0 10px; margin: 0;">
								&raquo; :push command<br />
								&raquo; :pull command<br />
								&raquo; :setspeed command<br />
								&raquo; :spull command<br />
								&raquo; Enter full rooms and locked rooms<br />
								&raquo; Can't get banned out of other rooms<br />
								&raquo; 0 second flood time<br />
								&raquo; Send/Receive staff alerts!<br />
								&raquo; Exclusive VIP catalogue (Unreleased rares)<br />
								&raquo; 75,000 Coins<br />
								&raquo; 50,000 Pixels<br />
								&raquo; The best chance of becoming staff.<br />
								</div>
						</p>
						
						<b>Terms and Conditions.</b><a href="/legalforms/tos"> Click here</a> to read more!
						<p style="font-style: italic;">
							Purchasing a VIP Subscription is classed as a donation, meaning that under no circumstances can we refund you. The rewards you gain from purchasing VIP, are given as a 'thank you' for donating to us. 
							<br /><br />
							By purchasing a VIP Subscription, you are agreeing to abide by these terms and conditions. If you file a chargeback, or create a dispute in PayPal then your account will be permanently banned until the issue has been resolved. 
						</p>					
					</div> 
				</div> 
			</div>
		</div>

		<div id="column2" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix blue ">  
					<h2 class="title"><span style="float: left;">Pay with PayPal</span></h2>
					<div style="padding: 5px" align="center">
						<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
						<input type="hidden" name="cmd" value="_s-xclick">
						<input type="hidden" name="hosted_button_id" value="547Y4FHBAEXJE">
						<table>
						<tr><td><input type="hidden" name="on0" value="plat/event">VIP</td></tr><tr><td><select name="os0">
							<option value="Platinum VIP">Platinum VIP $40.00 USD</option>
							<option value="Event Staff">Event Staff $20.00 USD</option>
						</select> </td></tr>
						<tr><td><input type="hidden" name="on1" value="{hotelname} username">{hotelname} username:</td></tr><tr><td><input type="text" name="os1" value="<?php echo $_SESSION['user']['username']; ?>" maxlength="200"></td></tr>
						</table>
						<input type="hidden" name="currency_code" value="USD">
						<input type="image" src="https://www.paypalobjects.com/en_AU/i/btn/btn_buynow_SM.gif" border="0" name="submit" alt="PayPal — The safer, easier way to pay online.">
						<img alt="" border="0" src="https://www.paypalobjects.com/en_AU/i/scr/pixel.gif" width="1" height="1">
						</form>	
					</div> 
				</div> 
			</div>	

			<div class="habblet-container ">
				<div class="cbb clearfix green ">  
					<h2 class="title"><span style="float: left;">Pay with PayGol</span></h2>
					<div style="padding: 5px" align="center">
						<form name="pg_frm" method="post" action="http://www.paygol.com/micropayment/paynow" >
							{hotelName} username:<p>
							<input type="text" name="pg_custom" value="<?php echo $_SESSION['user']['username']; ?>"><p>
							<input type="hidden" name="pg_serviceid" value="65211">
							<input type="hidden" name="pg_currency" value="USD">
							<input type="hidden" name="pg_name" value="Event and PLAT">

							<select name="pg_price"> 
								<option value="1" selected>Event Staff $20</option>
								<option value="2">Platinum VIP $40</option>
							</select>
							
							<br/><br/>
							
							<input type="hidden" name="pg_return_url" value="{url}/store/vip">
							<input type="hidden" name="pg_cancel_url" value="{url}/store/vip">
							<input type="image" name="pg_button" class="paygol" src="http://www.paygol.com/micropayment/img/buttons/125/black_en_pbm.png" border="0" alt="Make payments with PayGol: the easiest way!" title="Make payments with PayGol: the easiest way!" >     
						</form>				
					</div> 
				</div> 
			</div>				
		</div>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
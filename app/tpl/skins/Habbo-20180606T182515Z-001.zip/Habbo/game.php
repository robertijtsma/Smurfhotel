<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - Community</title>
	<link rel="stylesheet" href="{url}/web-gallery/styles/rooms.css" type="text/css">
 
<script type="text/javascript" src="{url}/web-gallery/js/rooms.js"></script>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>
	
	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<style type="text/css">background-position:-4px -115px;}#navi{clear:both;font-size:12px;}.title{color:white;text-shadow:black 0.1em 0.1em 0.2em}#navi li{float:left;height:28px;margin:0 5px 0 0;white-space:nowrap;}#navi li strong,#navi li a{float:left;height:22px;padding:px 16px 0 </style>
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 2;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 1;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
		<div id="column1" class="column">
			<div class="habblet-container ">		
				<div class="cbb clearfix activehomes ">
					<h2 class="title">Random online {hotelName}s!</h2>
					<div id="homes-habblet-list-container" class="habblet-list-container">
						<img class="active-habbo-imagemap" src="{url}/app/tpl/skins/Habbo/web-gallery/v2/images/activehomes/transparent_area.gif" width="435px" height="230px" usemap="#habbomap" />
						<?php
							$i = 0;
							$getRandom = mysql_query("SELECT `id`,`username`,`look`,`motto`,`account_created` FROM `users` WHERE `online` = '1' ORDER BY RAND() LIMIT 18");
							while ($randomHabbo = mysql_fetch_assoc($getRandom))
							{		 
								echo '<div id="active-habbo-data-' . $i . '" class="active-habbo-data"> 
										<div class="active-habbo-data-container"> 
										<div class="active-name ' . (($randomHabbo['online'] == "1") ? 'online' : 'offline') . '">' . $randomHabbo['username'] . '</div> 
										Habbo created on: ' . date('d M, Y', $randomHabbo['account_created']) . '
										<p class="moto">' . filter($randomHabbo['motto']) . '</p> 
										</div> 
										</div>                
										<input type="hidden" id="active-habbo-url-' . $i . '"> 
										<input type="hidden" id="active-habbo-image-' . $i . '" class="active-habbo-image" value="{habboImagerPath}' . $randomHabbo['look'] . '&direction=4&head_direction=4" />';

								$i++;
							}
						?>
						<div id="placeholder-container">
							<div id="active-habbo-image-placeholder-0" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-1" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-2" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-3" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-4" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-5" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-6" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-7" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-8" class="active-habbo-image-placeholder"></div>

							<div id="active-habbo-image-placeholder-9" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-10" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-11" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-12" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-13" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-14" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-15" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-16" class="active-habbo-image-placeholder"></div>
							<div id="active-habbo-image-placeholder-17" class="active-habbo-image-placeholder"></div>
						</div>
					</div>
					<map id="habbomap" name="habbomap">
						<area id="imagemap-area-0" shape="rect" coords="55,53,95,103" href="#" alt=""/>
						<area id="imagemap-area-1" shape="rect" coords="120,53,160,103" href="#" alt=""/>
						<area id="imagemap-area-2" shape="rect" coords="185,53,225,103" href="#" alt=""/>
						<area id="imagemap-area-3" shape="rect" coords="250,53,290,103" href="#" alt=""/>
						<area id="imagemap-area-4" shape="rect" coords="315,53,355,103" href="#" alt=""/>
						<area id="imagemap-area-5" shape="rect" coords="380,53,420,103" href="#" alt=""/>
						<area id="imagemap-area-6" shape="rect" coords="28,103,68,153" href="#" alt=""/>
						<area id="imagemap-area-7" shape="rect" coords="93,103,133,153" href="#" alt=""/>
						<area id="imagemap-area-8" shape="rect" coords="158,103,198,153" href="#" alt=""/>
						<area id="imagemap-area-9" shape="rect" coords="223,103,263,153" href="#" alt=""/>
						<area id="imagemap-area-10" shape="rect" coords="288,103,328,153" href="#" alt=""/>
						<area id="imagemap-area-11" shape="rect" coords="353,103,393,153" href="#" alt=""/>
						<area id="imagemap-area-12" shape="rect" coords="55,153,95,203" href="#" alt=""/>
						<area id="imagemap-area-13" shape="rect" coords="120,153,160,203" href="#" alt=""/>
						<area id="imagemap-area-14" shape="rect" coords="185,153,225,203" href="#" alt=""/>
						<area id="imagemap-area-15" shape="rect" coords="250,153,290,203" href="#" alt=""/>
						<area id="imagemap-area-16" shape="rect" coords="315,153,355,203" href="#" alt=""/>
						<area id="imagemap-area-17" shape="rect" coords="380,153,420,203" href="#" alt=""/>
					</map>
					<script type="text/javascript">
						var activeHabbosHabblet = new ActiveHabbosHabblet();
						document.observe("dom:loaded", function() { activeHabbosHabblet.generateRandomImages(); });
					</script>
				</div>
				<?php
///////////////////////////////////////////////////////////////////
// #Credits to Wicked and Fresh-hotel.org                          //
// #                                      //
/////////////////////////////////////////////////////////////////
$eo = 'even';
 
function GenerateRoomOccupancy($usersNow, $usersMax)
{
    $num = 1;
    $percentage = intval(($usersNow / $usersMax) * 100);
 
    if ($percentage <= 0)
    {
        $num = 1;
    }
    else if ($percentage < 35)
    {
        $num = 2;
    }
    else if ($percentage < 75)
    {
        $num = 3;
    }
    else if ($percentage < 100)
    {
        $num = 4;
    }
    else if ($percentage >= 100)
    {
        $num = 5;
    }
 
    return 'room-occupancy-' . $num;
}
 
?>
<div class="habblet-container "> 
<div class="cbb clearfix red ">
 
<h2 class="title">Hot Rooms</h2>
 
<style type="text/css">
.room-occupancy-1 { background-image: url('{{url}/app/tpl/skins/Habbo/web-gallery/web-gallery/images/rooms/room_icon_1.gif') !important; }
.room-occupancy-2 { background-image: url('{web-gallery}/images/rooms/room_icon_2.gif') !important; }
.room-occupancy-3 { background-image: url('{web-gallery}/images/rooms/room_icon_3.gif') !important; }
.room-occupancy-4 { background-image: url('{web-gallery}/images/rooms/room_icon_4.gif') !important; }
.room-occupancy-5 { background-image: url('{web-gallery}/images/rooms/room_icon_5.gif') !important; }
</style>
 
<div id="rooms-habblet-list-container-h124" class="recommendedrooms-lite-habblet-list-container">
<ul class="habblet-list">
 
<?php
 
$get = mysql_query("SELECT * FROM rooms WHERE roomtype = 'private' ORDER BY users_now DESC LIMIT 5")or die(mysql_error());
 
while ($room = mysql_fetch_assoc($get))
{
    if ($eo == 'even')
    {
        $eo = 'odd';
    }
    else
    {
        $eo = 'even';
    }
 
    echo '<li class="' . $eo . '">
    <span class="clearfix enter-room-link ' . GenerateRoomOccupancy($room['users_now'], $room['users_max']) . '" title="Go There" roomid="' . $room['id'] . '">
    <span class="room-enter">Enter room</span>
    <span class="room-name">' . ($room['caption']) . '</span>
    <span class="room-description">' . ($room['description']) . '</span>       
    <span class="room-owner">Owner: <a href="/home/' . ($room['owner']) . '">' . ($room['owner']) . '</a></span>
    </span>
    </li>';
}
 
?>
 
<div id="room-more-data-h124" style="display: none">
<ul class="habblet-list room-more-data">
 
<?php
 
$get = mysql_query("SELECT * FROM rooms WHERE roomtype = 'private' ORDER BY users_now DESC LIMIT 6,10")or die(mysql_error());
 
while ($room = mysql_fetch_assoc($get))
{
    if ($eo == 'even')
    {
        $eo = 'odd';
    }
    else
    {
        $eo = 'even';
    }
 
    echo '<li class="' . $eo . '">
    <span class="clearfix enter-room-link ' . GenerateRoomOccupancy($room['users_now'], $room['users_max']) . '" title="Go There" roomid="' . $room['id'] . '">
    <span class="room-enter">Enter room</span> <br>
    <span class="room-name">' . ($room['caption']) . '</span> <br>
    <span class="room-description">' . ($room['description']) . '</span>       
    <span class="room-owner">Owner: <a href="/home/' . ($room['owner']) . '">' . ($room['owner']) . '</a></span>
    </span>
    </li>';
}
 
?>
 
</ul>
</div>
 
<div class="clearfix">
<a href="#" class="room-toggle-more-data" id="room-toggle-more-data-h124">More Rooms!</a>
</div>
 
</div>
 
<script type="text/javascript">
L10N.put("show.more", "Show more rooms");
L10N.put("show.less", "Show less rooms");
var roomListHabblet_h124 = new RoomListHabblet("rooms-habblet-list-container-h124", "room-toggle-more-data-h124", "room-more-data-h124");
</script>
 
</div>
</div>
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
 
   
<br /><br>
			</div>
			<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>
			
</div><div id="column2" class="column"><div class="habblet-container news-promo">		
	<div class="cbb clearfix notitle "> 				
		<div id="newspromo">
                                    <div id="topstories">
                                        <div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-1})">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-1}">{newsTitle-1}</a></h3>
                                            <p class="summary">
                                                {newsCaption-1}
                                            </p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-1}">Read more &raquo;</a>
                                            </p>
                                        </div>
                                        <div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-2}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-2}">{newsTitle-2}</a></h3>
                                            <p class="summary">
                                                {newsCaption-2}
                                            </p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-2}">Read more &raquo;</a>
                                            </p>
                                        </div>
                                        <div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-3}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-3}">{newsTitle-3}</a></h3>
                                            <p class="summary">
                                                {newsCaption-3}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-3}">Read more &raquo;</a>
                                               </p>
											</div>
                                        <div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-4}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-4}">{newsTitle-4}</a></h3>
											<p class="summary">
                                                {newsCaption-4}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-4}">Read more &raquo;</a>
                                            </p>
                                        </div>
										<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-5}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-5}">{newsTitle-5}</a></h3>
                                            <p class="summary">
                                                {newsCaption-5}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-5}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-6}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-6}">{newsTitle-6}</a></h3>
                                            <p class="summary">
                                                {newsCaption-6}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-6}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-7}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-7}">{newsTitle-7}</a></h3>
                                            <p class="summary">
                                                {newsCaption-7}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-7}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-8}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-8}">{newsTitle-8}</a></h3>
                                            <p class="summary">
                                                {newsCaption-8}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-8}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-9}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-9}">{newsTitle-9}</a></h3>
                                            <p class="summary">
                                                {newsCaption-9}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-9}">Read more &raquo;</a>
                                               </p>
											</div>
											<div class="topstory" style="background-image: url({url}/swfs/c_images/Top_Story_Images/{newsIMG-10}); display: none">
                                            <h4>Latest news</h4>
                                            <h3><a href="{url}/index.php?url=news&id={newsID-10}">{newsTitle-10}</a></h3>
                                            <p class="summary">
                                                {newsCaption-10}
												</p>
                                            <p>
                                                <a href="{url}/index.php?url=news&id={newsID-10}">Read more &raquo;</a>
                                               </p>
											</div>
                                        
                                        <div id="topstories-nav" style="display: none"><a href="#" class="prev">&laquo; Previous</a><span>1</span> / 10<a href="#" class="next">Next &raquo;</a></div>
                                    </div>
                                    <ul class="widelist">
                                        <li class="even"><a href="{url}/index.php?url=news&id={newsID-1}">{newsTitle-1} &raquo;</a><div class="newsitem-date">{newsDate-1}</div></li>            
                                        <li class="odd"><a href="{url}/index.php?url=news&id={newsID-2}">{newsTitle-2} &raquo;</a><div class="newsitem-date">{newsDate-2}</div></li> 
										    
                                        <li class="last"><a href="/news">More news &raquo;</a></li>            
                                    </ul>
                                </div>

<script type="text/javascript"> 
	document.observe("dom:loaded", function() { NewsPromo.init(); });
</script> 
	
						
					</div>
				</div> 
				<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script> 
<div class="habblet-container ">		
<div class="cbb clearfix settings "> 

<h2 class="title">Recent Updates</h2>

<div style="padding:5px">
- The site CMS has been updated,credits to'Wicked'.<br>
- You can use this are to post updates.<br>


</p>
</div>
	
</div>
</div>
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script>


				</div>
		</div>
	</div>
	
	


</div> 
 
<script type="text/javascript">if (!$(document.body).hasClassName('process-template')) { Rounder.init(); }</script> 
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
				</div>
		</div>
	</div>



<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright © 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - Store - Donations</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>

	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<style type="text/css">background-position:-4px -115px;}#navi{clear:both;font-size:12px;}.title{color:white;text-shadow:black 0.1em 0.1em 0.2em}#navi li{float:left;height:28px;margin:0 5px 0 0;white-space:nowrap;}#navi li strong,#navi li a{float:left;height:22px;padding:px 16px 0 </style>
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
	
	<style type="text/css">
		hr {background-color:#CCC;border:0;height:1px;margin:10px 0;}
	</style>
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 4;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 3;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
		<div id="column1" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix blue ">  
					<h2 class="title"><span style="float: left;">Donation Information</span></h2>
					<div style="padding: 5px" align="left"> 
						<img src="{url}/app/tpl/skins/Habbo/web-gallery/habboon/donations/geschenke.gif" align="right" vspace="5" hspace="5">
						<h3><font color='darkred'>Why donate?</h3><font color='black'>
						{hotelname} Hotel runs on donations from users like you! Without users constantly donating and supporting us, we would not be able to stay online. In addition to knowing that {hotelname} Hotel will be able to live on even longer, you can also get some pretty cool rewards for donating! Look at the list to the right to see those rewards.
						<h3><font color='darkred'>How do I donate?</h3><font color='black'>
						Donating is similar to purchasing VIP. The only payment method that is available for donating is Paypal. Simply scroll to the bottom of the page, select the donation amount, enter in your {hotelname} Hotel username, and click pay now! Paypal is the leading and most widely-used payment system on the internet. After donating through Paypal, you can expect to have your credits, pixels, badge, and rares delivered to you instantly, or at most a few minutes. The rares will be sent to you in Red Presents. You can simply place these presents down and open them to receive your rares.
						<h3><font color='darkred'>Can I donate more than once?</h3><font color='black'>
						You can donate as many times as you like! Donate whenever you can -- we can always use more funds to help pay for our multiple servers, domains, and various other services which we provide free of charge.
						<h3><font color='darkred'>Refunds?</h3><font color='black'>
						Refunds are not allowed. <b>All payments are final.</b> By donating to {hotelname} Hotel, you agree that you will not attempt to refund your donation at any time. This causes a huge hassle for us, and we <b>will</b> ban your account if you attempt to get your money back.<p>
						<h3><font color='darkred'>What color rares are available?</h3><font color='black'>
						<b>Ice Cream Machines</b> - <i>Aqua, Blue, Choco, Fucsia, Gold, Ochre, Pink, Purple, Red, Shamrock</i><br>
						<b>Dragons</b> - <i>Gold, Silver, Blue, Sky, Purple, Bronze, Black, Jade, Forest, Red</i><br>

						All rare colors will be randomly selected. You have an equal chance to receive all colors of rares!
						<br><br><p>So why wait?! Donate now, and get some really cool rewards!</p>	
					</div> 
				</div> 
			</div>
		</div>

		<div id="column2" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix settings  ">  
					<h2 class="title"><span style="float: left;">Donation Benefits</span></h2>
					<div style="padding: 5px" align="l">
						<p><strong><img align="middle" src="{url}/app/tpl/skins/Habbo/web-gallery/habboon/donations/PX00.gif" alt="" width="40" height="40"/>Level 1 (<em>$10.00) </em></strong><br>Donator's Badge (Level 1), 10,000 Credits & 10,000 pixels, 5 Thrones, 5 Golden dice, 5 Cheetos, 2 Dragons, 2 ICMS, ULTRA (unreleased) green calippo ICM </p>
						<p><strong><span style="font-weight: normal;"><strong><img align="middle" src="{url}/app/tpl/skins/Habbo/web-gallery/habboon/donations/PX01.gif" alt="" width="40" height="40"/>Level 2 (<em>$25.00) &nbsp;</em></strong><br>Donator's Badge (Level 2), , 30,000 credits & 30,000 pixels, 10 Thrones, 12 Gold dice, 5 Dragons, 1 Typo Statue, 10 Cheetos, 5 ICMS, Event Staff</span></strong></p>
						<p><strong><span style="font-weight: normal;"><strong><img align="middle" src="{url}/app/tpl/skins/Habbo/web-gallery/habboon/donations/PX02.gif" alt="" width="40" height="40"/>Level 3 (<em>$50.00) &nbsp;</em></strong><br>Donator's Badge (Level 3), , 70,000 credits, 70,000 pixels, 20 Thrones, 20 Gold dice, 1 Dino Statue, 16 Cheetos, 7 Dragons, 7 ICMS, 1 ULTRA white ICM, 1 Super Silver MTV award, Event staff</span></strong></p>
						<p><strong><span style="font-weight: normal;"><strong><img align="middle" src="{url}/app/tpl/skins/Habbo/web-gallery/habboon/donations/PX03.gif" alt="" width="40" height="40"/>Level 4 (<em>$100.00) &nbsp;</em></strong><br>Donator's Badge (Level 4), , 200000 credits, 200000 pixels, 40 Thrones, 40 Gold dice, 1 Throne Statue, 24 Cheetos, 10 ICMS (Set), 10 Dragons (set),1 unreleased Holo Dino, 1 Super gold MTV award, Platinum VIP </span></strong></p>
					</div> 
				</div> 
			</div>	

			<div class="habblet-container ">
				<div class="cbb clearfix red ">  
					<h2 class="title"><span style="float: left;">Casino Pack</span></h2>
					<div style="padding: 5px" align="center">
						<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="BNWRBWJAZRBCE">
							
							<table>
								<tr><td><input type="hidden" name="on0" value="{hotelname} username">{hotelName} username:</td></tr><tr><td><input type="text" name="os0" value="<?php echo $_SESSION['user']['username']; ?>" maxlength="200"></td></tr>
							</table>
							
							<input type="image" src="https://www.paypalobjects.com/en_AU/i/btn/btn_buynow_SM.gif" border="0" name="submit" alt="PayPal — The safer, easier way to pay online.">
							<img alt="" border="0" src="https://www.paypalobjects.com/en_AU/i/scr/pixel.gif" width="1" height="1">
						</form>

						<p style="padding-top: 15px;"><a href="{url}/news/185">What comes with the Casino Pack? Click here!</a></p>			
					</div> 
				</div> 
			</div>	

			<div class="habblet-container ">
				<div class="cbb clearfix green ">  
					<h2 class="title"><span style="float: left;">Pay with PayPal</span></h2>
					<div style="padding: 5px" align="center">
						<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
						<input type="hidden" name="cmd" value="_s-xclick">
						<input type="hidden" name="hosted_button_id" value="QDJ34LGA79LYJ">
						<table>
						<tr><td><input type="hidden" name="on0" value="Choose package">Choose package:</td></tr><tr><td><select name="os0">
							<option value="Level 1">Level 1 $10.00 AUD</option>
							<option value="Level 2">Level 2 $25.00 AUD</option>
							<option value="Level 3">Level 3 $50.00 AUD</option>
							<option value="Level 4">Level 4 $100.00 AUD</option>
						</select> </td></tr>
						<tr><td><input type="hidden" name="on1" value="{hotelname} Username">{hotelName} Username:</td></tr><tr><td><input type="text" name="os1" value="<?php echo $_SESSION['user']['username']; ?>" maxlength="200"></td></tr>
						</table>
						<input type="hidden" name="currency_code" value="AUD">
						<input type="image" src="https://www.paypalobjects.com/en_AU/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal — The safer, easier way to pay online.">
						<img alt="" border="0" src="https://www.paypalobjects.com/en_AU/i/scr/pixel.gif" width="1" height="1">
						</form>
					</div> 
				</div> 
			</div>		

			<div class="habblet-container ">
				<div class="cbb clearfix blue ">  
					<h2 class="title"><span style="float: left;">Pay with PayGol</span></h2>
					<div style="padding: 5px" align="center">
						<form name="pg_frm" method="post" action="http://www.paygol.com/micropayment/paynow" >
							{hotelName} username:<p>
							<input type="text" name="pg_custom" value="<?php echo $_SESSION['user']['username']; ?>"><p>
							<input type="hidden" name="pg_serviceid" value="65216">
							<input type="hidden" name="pg_currency" value="USD">
							<input type="hidden" name="pg_name" value="Donations">

							<select name="pg_price"> 
								<option value="1" selected>Rare Package 1 25</option>
								<option value="2">Rare Package 2 50</option>
							</select>
							
							<br/><br/>
							
							<input type="hidden" name="pg_return_url" value="{url}/store/donations">
							<input type="hidden" name="pg_cancel_url" value="{url}/store/donations">
							<input type="image" name="pg_button" class="paygol" src="http://www.paygol.com/micropayment/img/buttons/125/black_en_pbm.png" border="0" alt="Make payments with PayGol: the easiest way!" title="Make payments with PayGol: the easiest way!" >     
						</form>
					</div> 
				</div> 
			</div>				
		</div>

<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - Top Stats</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>
	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "ac96433fa782a85a4d9d1724e256d10df092be19";
		HabboClient.maximizeWindow = true;
	}


	</script>

	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<style type="text/css">background-position:-4px -115px;}#navi{clear:both;font-size:12px;}.title{color:white;text-shadow:black 0.1em 0.1em 0.2em}#navi li{float:left;height:28px;margin:0 5px 0 0;white-space:nowrap;}#navi li strong,#navi li a{float:left;height:22px;padding:px 16px 0 </style>
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
</head>
<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 2;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 5;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
		<div id="column" class="column" style="width:256px;">
			<div class="habblet-container ">
				<div class="cbb clearfix orange ">  
					<h2 class="title"><span style="float: left;">Credits</span></h2>
					<div align='left'> 
						<table width='100%'>
						<?php
						$getCredits = mysql_query("SELECT `look`,`username`,`credits` FROM `users` WHERE `rank` <= '3' ORDER BY `credits` DESC LIMIT 10");
						while($creditsStats = mysql_fetch_array($getCredits)) {
							echo '
							<tr>
								<td width="25%"><img src="{habboImagerPath}' . $creditsStats['look'] . '&size=s&direction=2&head_direction=2&gesture=sml&size=s" align="left"></td> 
								<td width="75%"><a href="{url}/home/'.$creditsStats['username'].'"><b>'.$creditsStats['username'].'</b></a><br />'.$creditsStats['credits'].' Credits</td>
							</tr>';
						}
						?>
						</table>
					</div> 
				</div> 
			</div>
		</div>
		
		<div id="column" class="column" style="width:256px;">
			<div class="habblet-container ">
				<div class="cbb clearfix blue ">  
					<h2 class="title"><span style="float: left;">Pixels</span></h2>
					<div align='left'> 
						<table width='100%'>
						<?php
						$getCredits = mysql_query("SELECT `look`,`username`,`activity_points` FROM `users` WHERE `rank` <= '3' ORDER BY `activity_points` DESC LIMIT 10");
						while($creditsStats = mysql_fetch_array($getCredits)) {
							echo '
							<tr>
								<td width="25%"><img src="{habboImagerPath}' . $creditsStats['look'] . '&size=s&direction=2&head_direction=2&gesture=sml&size=s" align="left"></td> 
								<td width="75%"><a href="{url}/home/'.$creditsStats['username'].'"><b>'.$creditsStats['username'].'</b></a><br />'.$creditsStats['activity_points'].' Pixels</td>
							</tr>';
						}
						?>
						</table>
					</div> 
				</div> 
			</div>
		</div>
		
		<div id="column" class="column" style="width:256px;">
			<div class="habblet-container ">
				<div class="cbb clearfix green ">  
					<h2 class="title"><span style="float: left;">Online Time</span></h2>
					<div align='left'> 
						<table width='100%'>
						<?php
						$getOnline = mysql_query("SELECT `id`,`OnlineTime` FROM `user_stats` ORDER BY `OnlineTime` DESC LIMIT 10") or die(mysql_error());
						while($onlineInfo = mysql_fetch_array($getOnline))
						{
							$days = floor($onlineInfo['OnlineTime'] / (60*60*24));
							$userInfo = mysql_fetch_array(mysql_query("SELECT `username`,`look` FROM users WHERE `id` = '".$onlineInfo['id']."'"));

							echo '
							<tr>
								<td width="25%"><img src="{habboImagerPath}' . $userInfo['look'] . '&size=s&direction=2&head_direction=2&gesture=sml&size=s" align="left"></td> 
								<td width="75%"><a href="{url}/home/'.$userInfo['username'].'"<b>'.$userInfo['username'].'</b></a><br />Spent '. $days . ' day(s) online.</td>
							</tr>';
						}		
						?>
						</table>
					</div> 
				</div> 
			</div>
		</div>




<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>

<?php
if (isset($_GET['id']) && $_GET['id']!= null && is_numeric($_GET['id'])) {
	$getBadges = mysql_query("SELECT * FROM `badgeshop` WHERE `id` = '".filter($_GET['id'])."'");
	if (mysql_num_rows($getBadges) == 0) {
		$badgeMessage = '<div class="rounded rounded-red">This badge wasn\'t found!<br /></div>';
	} else {
		global $engine;
		
		$badgeData = mysql_fetch_array($getBadges);
		
		if (mysql_num_rows(mysql_query("SELECT `badge_id` FROM `user_badges` WHERE `user_id` = '".$_SESSION['user']['id']."' AND `badge_id` = '".$badgeData['badgecode']."'")) != 0) {
			$badgeMessage = '<div class="rounded rounded-red">You already have this badge!<br /></div>';
		} else {
			$userData = mysql_fetch_array(mysql_query("SELECT `credits`,`online` FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));			
			if ($userData['online'] == 1)
				$badgeMessage = '<div class="rounded rounded-red">Please close the client whilst purchasing badges!<br /></div>';
			else {
				if ($badgeData['price'] > $userData['credits']) {
					$badgeMessage = '<div class="rounded rounded-red">You do not have enough credits to purchase this badge!<br /></div>';
				} else {
					mysql_query("INSERT INTO `user_badges` (`user_id`,`badge_id`,`badge_slot`) VALUES ('".$_SESSION['user']['id']."', '".$badgeData['badgecode']."', '0') ");
					mysql_query("UPDATE `users` SET `credits` = `credits` - '".$badgeData['price']."' WHERE `id` = '".$_SESSION['user']['id']."'");
					//$_SESSION['user']['credits'] -= $badgeData['price'];
					$badgeMessage = '<div class="rounded rounded-green">Badge successfully bought, you have been charged '.$badgeData['price'].' credits.<br /></div>';
				}
			}
		}
	}
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>{hotelName} - Badge Shop</title>

	<script type="text/javascript">
		var andSoItBegins = (new Date()).getTime();
	</script>

	<link rel="shortcut icon" href="{url}/app/tpl/skins/Habbo/web-gallery/v2/favicon.ico" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css" />
	
	
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs2.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/visual.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/libs.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/common.js" type="text/javascript"></script>
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/fullcontent.js" type="text/javascript"></script>

	<script type="text/javascript">
	document.habboLoggedIn = true;
	var habboName = "{username}";
	var habboId = {userid};
	var facebookUser = false;
	var habboReqPath = "";
	var habboStaticFilePath = "{url}/app/tpl/skins/Habbo/web-gallery";
	var habboImagerUrl = "http://www.habbo.com/habbo-imaging/";
	var habboPartner = "";
	var habboDefaultClientPopupUrl = "{url}/client";
	window.name = "habboMain";
	if (typeof HabboClient != "undefined") {
		HabboClient.windowName = "26530fff566f9e67da99560b7fe8da6d71d46391";
		HabboClient.maximizeWindow = true;
	}
	</script>

	<meta name="description" content="{meta_description}" />
	<meta name="keywords" content="{meta_keywords}" />

	<!--[if IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie8.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 8]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie.css" type="text/css" />
	<![endif]-->
	<!--[if lt IE 7]>
	<link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/ie6.css" type="text/css" />
	<script src="{url}/app/tpl/skins/Habbo/web-gallery/static/js/pngfix.js" type="text/javascript"></script>
	<script type="text/javascript">
	try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
	</script>

	<style type="text/css">
	body { behavior: url(/js/csshover.htc); }
	</style>
	<![endif]-->
	<meta name="build" content="63-BUILD2470 - 30.09.2013 11:10 - com" />
	
	<style type="text/css">
		hr {background-color:#CCC;border:0;height:1px;margin:10px 0;}
	</style>
	
</head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 3;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 1;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
</div>

<div id="container">
	<div id="content" style="position: relative" class="clearfix">
		<div id="column1" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix green ">  
					<h2 class="title"><span style="float: left;">Available Badges</span></h2>
					<div style="padding: 5px" align='left'> 
						<?php
						echo $badgeMessage;
						
						$count = 0;
						$getBadges = mysql_query("SELECT * FROM `badgeshop` ORDER BY `price` ASC LIMIT 20");
						if (mysql_num_rows($getBadges) == 0)
							echo 'No badges are currently in the shop!';
						else 
						{
							while ($badgeInfo = mysql_fetch_array($getBadges)) 
							{
								$ownBadge = false;
								$getUserBadges = mysql_query("SELECT * FROM `user_badges` WHERE `user_id` = '".$_SESSION['user']['id']."' AND `badge_id` = '".$badgeInfo['badgecode']."'");
								if (mysql_num_rows($getUserBadges) == 1)
									$ownBadge = true;
									
								if ($ownBadge == true)
									$lineString = '<td width="80%">'.filter($badgeInfo['badgename']).'<br />Price: '.$badgeInfo['price'].'c<br/><a href="{url}/badgeshop">You own this badge!</td>';									
								else
									$lineString = '<td width="80%">'.filter($badgeInfo['badgename']).'<br />Price: '.$badgeInfo['price'].'c<br/><a href="{url}/badgeshop/'.$badgeInfo['id'].'">Purchase</a></td>';									
															
								echo '<table style="width: 50%; float:left">
									<tr>
										<td width="20%"><img src="{badgeImagePath}'.$badgeInfo['badgecode'].'.gif"></td>
										'.$lineString.'							
									</tr>
								</table>';
							}
						}						
						?>
					</div> 
				</div> 
			</div>
		</div>

		<div id="column2" class="column">
			<div class="habblet-container ">
				<div class="cbb clearfix blue ">  
					<h2 class="title"><span style="float: left;">My Badges</span></h2>
					<div style="padding: 5px" align="left">
						<?php
						$getBadges = mysql_query("SELECT * FROM `user_badges` WHERE `user_id` = '".$_SESSION['user']['id']."'");
						if (mysql_num_rows($getBadges) == 0)
							echo 'You do not have any badges!';
						else 
						{
							while ($badgeInfo = mysql_fetch_array($getBadges)) 
							{		
								echo '<img src="{badgeImagePath}'.$badgeInfo['badge_id'].'.gif" style="padding: 3px;">';	
							}
						}						
						?>
					</div> 
				</div> 
			</div>			
		</div>
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
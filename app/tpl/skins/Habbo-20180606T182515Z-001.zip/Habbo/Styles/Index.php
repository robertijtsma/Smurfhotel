        <title>{hotelName} - The best hotel around!</title>
<link rel="stylesheet" href="{url}/app/tpl/skins/{skin}/styles/habboextreme.css" type="text/css"/>
    	<div class="index_container_border">
		  	<div class="index_container">

		  		<div class="logo_index">

		  			<a href="#" class="logo"></a>

		 	 	</div>

		 	 	<div class="index_box">

		 	 		<div class="content_padding smaller">
		 	 			<div class="content_title blue">Welcome to {hotelName}!</div>
			 	 		<div class="content_padding">
			 	 			<form action="index" method="post">
<?php if(isset($template->form->error)) { echo '<div id="message">'.$template->form->error.'</div>'; } ?><br>
				 	 			<div class="input_div">

				 	 				<label>Username</label><br>
					 	 			<input type="text" class="input_form" name="log_username" value="">

					 	 		</div>		 	 			
					 	 		<div class="input_div" style="position:relative;">

				 	 				<label>Password</label><br>
					 	 			<input type="password" class="input_form" name="log_password" value="">
					 	 			<input type="submit" class="button black index" name="login" value="Sign In">

					 	 		</div>

				 	 		</form>

				 	 		<a href="register" style="text-decoration:none;">
				 	 			<div class="content_title green index">Join {hotelName} now for FREE!</div>
				 	 		</a>

				 	 	</div>
			 		</div>

		 	 	</div>

				<div class="people_inside" style="top:355px;">
				    <b><span><span class="online_count user_count_refresh">{online}</span> {hotelName}'s online</span></b>
				    <i></i>
				</div>

		  	</div>
	 	</div>
<?php
 	/*
	    _____
	  |
	  |
	  |
	  |
	  |
	  |
	  |       |
	  |       |
	  |       |
	    _____ |
/*---------------------------------------------------+
| RevProCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2013 Wicked 'Adam' and Proof 'Dan'
+----------------------------------------------------+
| RevProCMS is provided "as is" and comes without
| warrenty of any kind.
+---------------------------------------------------*/


/*

	Please do not remove or edit the line defined below. If you do, you don't show much respect towards me.
	I have worked on RevPro for countless hours, I did this for free, without any personal gain for me at all.

	Please respect me and my work, and do not edit or remove the line defined below.

	If I do find people editing that line RevPro may go underground or I will simply stop developing, I'm
	prepared to go to the extreme.

	(Also, you're breaking the license if you do, and with that, copyright law)

	If you have any questions regarding this, feel free to e-mail me:
	meth0d at meth0d dot org,habview.co.uk,habview.com

	Thanks in advance.

*/

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <title>{hotelName} - Privacy Policy</title>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/web-gallery/static/styles/common.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs2.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/visual.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/libs.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/common.js"></script>
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/fullcontent.js"></script>
        
        <script type="text/javascript">
            document.HabboLoggedIn = true;
            var HabboName = "{username}";
            var HabboId = {userid};
            var HabboReqPath = "";
            var HabboStaticFilePath = "{url}/app/tpl/skins/Habbo";
            var HabboImagerUrl = "http://www.habbo.com/habbo-imaging/";
            var HabboPartner = "";
            var HabboHabboClientPopupUrl = "{url}/client";
            window.name = "HabboMain";
            if (typeof HabboClient != "undefined") {
                HabboClient.windowName = "eac955c8dbc88172421193892a3e98fc7402021a";
                HabboClient.maximizeWindow = true;
            }
        </script>
        
        <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/personal.css" type="text/css">
        <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/Habboclub.js"></script>
        
        <!--[if IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie8.css" type="text/css">
        <![endif]-->
        <!--[if lt IE 8]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie.css" type="text/css" />
        <![endif]-->
        <!--[if lt IE 7]>
            <link rel="stylesheet" href="{url}/app/tpl/skins/Habbo/styles/ie6.css" type="text/css" />
            <script type="text/javascript" src="{url}/app/tpl/skins/Habbo/js/pngfix.js"></script>
            <script type="text/javascript">
                try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {}
            </script>
            <style type="text/css">
                body { behavior: url({url}/app/tpl/skins/Habbo/js/csshover.htc); }
            </style>
        <![endif]-->
    </head>

<body id="home" class=" ">
<div id="overlay"></div>

<?php 

$navigatorID = 3;
require_once ('app/tpl/skins/Habbo/template/header.php'); 

?>


<div id="content-container">

<div id="navi2-container" class="pngbg">
    <div id="navi2" class="pngbg clearfix">
		<ul>
		<?php 

		$subNavigatorID = 3;
		require_once ('app/tpl/skins/Habbo/template/sub_header.php'); 

		?>
		</ul>
    </div>
               </div>
</div> 
 <div id='alert'></div>

<div id="container">
<div id="content" style="position: relative" class="clearfix"><div>

<div class="habblet-container" style="float:left;width:790px;">
<div class="cb red">
<div class="bt"><div></div></div><div class="i1"><div class="i2"><div class="i3">
<div class="box-tabs-container box-tabs-left clearfix">
<h2 class="page-owner">{hotelname} Privacy Policy</h2>
<ul class="box-tabs"></ul>
</div>

<div class="box-content" style="background-image:url('{url}/app/tpl/skins/Habbo/images/com_staff006?1'); width:692px; height:1758px; padding-left:71px;">
<div style="display:block;">
</div>
<div align="center">
<div align="center">
  <p><img src="{url}/app/tpl/skins/Habbo/images/sorry.gif" alt="" border="0" align="right"></p>
  <p><font size="11"><img src="{url}/app/tpl/skins/Habbo/images/habrox2.gif" alt="" border="0" align="left"></font></p>
</div>
<p align="center"><font size="6">Privacy Policy</font></p>
<p align="center"><img src="{url}/app/tpl/skins/Habbo/images/page_0.png" alt="Photobucket" border="0" align="left"><img src="{url}/app/tpl/skins/Habbo/images/games_illustration.png" alt="Photobucket" border="0" align="right">
<p align="center"> <font size="4">What information do we collect? </font></p>
<p align="center">We collect information from you when you register on our site 
  or place an order. </p>
<p align="center">When ordering or registering on our site, as appropriate, you 
  may be asked to enter your: name or e-mail address. You may, however, visit 
  our site anonymously.</p>
<p align="center"><font size="4">What do we use your information for? </font></p>
<p align="center">Any of the information we collect from you may be used in one 
  of the following ways: </p>
<p align="center">; To personalize your experience<br>
  (your information helps us to better respond to your individual needs)</p>
<p align="center">; To improve our website<br>
  (we continually strive to improve our website offerings based on the information 
  and feedback we receive from you)</p>
<p align="center">; To improve customer service<br>
  (your information helps us to more effectively respond to your customer service 
  requests and support needs)</p>
<p align="center">; To process transactions<br>
  Your information, whether public or private, will not be sold, exchanged, transferred, 
  or given to any other company for any reason whatsoever,<br>
  without your consent, other than for the express purpose of delivering the purchased 
  product or service requested.</p>
<p align="center">; To administer a contest, promotion, survey or other site feature</p>
<p align="center"><br>
  ; To send periodic emails</p>
<p align="center">The email address you provide may be used to send you information, 
  respond to inquiries, and/or other requests or questions.</p>
<p align="center"><font size="4">How do we protect your information? </font></p>
<p align="center">We implement a variety of security measures to maintain the 
  safety of your personal information when you place an order or enter, submit, 
  or access your personal information. </p>
<p align="center">We offer the use of a secure server. All supplied sensitive/credit 
  information is transmitted via Secure Socket Layer (SSL) technology and then 
  encrypted into our Database <br>
  to be only accessed by those authorized with special access rights to our systems, 
  and are required to?keep the information confidential. </p>
<p align="center">After a transaction, your private information (credit cards, 
  social security numbers, financials, etc.) will not be stored on our servers.</p>
<p align="center"><font size="4">Do we use cookies? </font></p>
<p align="center">Yes (Cookies are small files that a site or its service provider 
  transfers to your computers hard drive through your Web browser (if you allow) 
  that enables the<br>
  sites or service providers systems to recognize your browser and capture and 
  remember certain information</p>
<p align="center">We use cookies to understand and save your preferences for future 
  visits.</p>
<p align="center"><font size="4">Do we disclose any information to outside parties? 
  </font></p>
<p align="center">We do not sell, trade, or otherwise transfer to outside parties 
  your personally identifiable information. This does not include trusted third 
  parties who assist us <br>
  in operating our website, conducting our business, or servicing you, so long 
  as those parties agree to keep this information confidential. We may also release 
  your <br>
  information when we believe release is appropriate to comply with the law, enforce 
  our site policies, or protect ours or others rights, property, or safety. However, 
  <br>
  non-personally identifiable visitor information may be provided to other parties 
  for marketing, advertising, or other uses.</p>
<p align="center"><font size="4">Third party links </font></p>
<p align="center">Occasionally, at our discretion, we may include or offer third 
  party products or services on our website. These third party sites have separate 
  and independent privacy <br>
  policies. We therefore have no responsibility or liability for the content and 
  activities of these linked sites. Nonetheless, we seek to protect the integrity 
  of our <br>
  site and welcome any feedback about these sites.</p>
<p align="center"><font size="4">California Online Privacy Protection Act Compliance</font></p>
<p align="center">Because we value your privacy we have taken the necessary precautions 
  to be in compliance with the California Online Privacy Protection Act. We therefore 
  will not <br>
  distribute your personal information to outside parties without your consent.</p>
<p align="center">As part of the California Online Privacy Protection Act, all 
  users of our site may make any changes to their information at anytime by logging 
  into their control panel <br>
  and going to the 'Edit Profile' page.</p>
<p align="center"><font size="4">Childrens Online Privacy Protection Act Compliance 
  </font></p>
<p align="center">We are in compliance with the requirements of COPPA (Childrens 
  Online Privacy Protection Act), we do not collect any information from anyone 
  under 13 years of age. Our <br>
  website, products and services are all directed to people who are at least 13 
  years old or older.</p>
<p align="center"><font size="4">Online Privacy Policy Only </font></p>
<p align="center">This online privacy policy applies only to information collected 
  through our website and not to information collected offline.</p>
<p align="center"><font size="4">Your Consent </font></p>
<p align="center">By using our site, you consent to our privacy policy.</p>
<p align="center"><font size="4">Changes to our Privacy Policy</font> </p>
<p align="center">If we decide to change our privacy policy, we will update the 
  Privacy Policy modification date below. </p>
<p align="center">This policy was last modified on June 9th 2012</p>
<p align="center">http://habview.co.uk</p>

</div></div></div><div class="bb"><div></div></div>
</div>
</div>

</div>
</div>

</div></div></div><div class="bb"><div></div></div></div>
</div> 
<?php require_once ('app/tpl/skins/Habbo/template/footer.php'); ?>
				</div>
		</div>
	</div>




